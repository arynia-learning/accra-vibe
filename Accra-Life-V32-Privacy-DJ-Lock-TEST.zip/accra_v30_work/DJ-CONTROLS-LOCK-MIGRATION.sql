-- Accra Life DJ safety patch — review and apply in Supabase SQL Editor.
-- This intentionally locks DJ queue updates for ALL authenticated clients until
-- a server-verified venue-staff/admin authorization system is implemented.
-- Song requests (INSERT as the signed-in requester) and queue reads remain available.

begin;

-- Remove the broad policy that currently allows any signed-in player to update queue rows.
drop policy if exists "Signed-in players can operate demo venue queues" on public.club_song_requests;
drop policy if exists "Signed-in Enzo visitors can operate demo DJ queue" on public.club_song_requests;

-- Remove direct client UPDATE privilege as defense in depth.
revoke update on table public.club_song_requests from authenticated;
revoke update on table public.club_song_requests from anon;

commit;

-- Verify: this should return no policy with cmd = UPDATE for club_song_requests.
select policyname, cmd, roles
from pg_policies
where schemaname = 'public'
  and tablename = 'club_song_requests'
  and cmd = 'UPDATE';

-- Verify authenticated no longer has UPDATE table privilege.
select has_table_privilege('authenticated', 'public.club_song_requests', 'UPDATE') as authenticated_can_update_queue;
