-- Accra Life V31 economy update — REVIEW FIRST; NOT APPLIED TO LIVE DATABASE.
-- Run in a staging Supabase project first. This changes job/property catalogue rows
-- and replaces the salary-claim function, so test before production deployment.

begin;

-- Make the starter home price match the agreed economy design.
update public.properties
set price = 2500
where id = '31e1b9d0-85ac-4cb2-a237-dbadb1c9ebc3'
  and name = 'Starter Studio';

-- Add a clearly defined entry-level role. Existing career tiers remain in place.
insert into public.jobs (name, category, salary, description)
select 'Starter Worker', 'Entry Level', 150,
       'Your first job in Accra. Complete a six-minute shift to earn GH₵150 in virtual game money.'
where not exists (
  select 1 from public.jobs where lower(name) = lower('Starter Worker')
);

-- Enforce the six-minute cooldown on the server, not just in the browser.
-- The cooldown begins at hire time for the first claim and at the last claim thereafter.
create or replace function public.claim_job_salary()
returns public.wallets
language plpgsql
security definer
set search_path = public
as $function$
declare
  v_uid uuid := auth.uid();
  v_salary numeric(14,2);
  v_anchor timestamptz;
  v_result public.wallets;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;

  select j.salary, coalesce(pj.last_salary_at, pj.hired_at)
    into v_salary, v_anchor
  from public.player_jobs pj
  join public.jobs j on j.id = pj.job_id
  where pj.player_id = v_uid
  for update of pj;

  if v_salary is null then raise exception 'No active job'; end if;
  if v_anchor is not null and v_anchor > now() - interval '6 minutes' then
    raise exception 'Your work shift is still in progress. Wait six minutes between salary claims.';
  end if;

  update public.wallets
  set balance = balance + v_salary, updated_at = now()
  where player_id = v_uid
  returning * into v_result;
  if not found then raise exception 'Wallet not found'; end if;

  update public.player_jobs set last_salary_at = now() where player_id = v_uid;
  insert into public.wallet_transactions(player_id, amount, transaction_type, description)
  values(v_uid, v_salary, 'job_salary', 'Completed six-minute work shift');
  return v_result;
end;
$function$;

-- Do not let unauthenticated visitors call the salary function.
revoke all on function public.claim_job_salary() from public, anon;
grant execute on function public.claim_job_salary() to authenticated;

commit;

-- Verification queries to run after applying in STAGING:
-- select name, salary from public.jobs order by salary;
-- select name, price from public.properties where name = 'Starter Studio';
-- select pg_get_functiondef('public.claim_job_salary()'::regprocedure);
