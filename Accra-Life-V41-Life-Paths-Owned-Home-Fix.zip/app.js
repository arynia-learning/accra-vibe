(() => {
  'use strict';
  const cfg = window.ACCRA_LIFE_CONFIG || {};
  if (!window.supabase || typeof window.supabase.createClient !== 'function') { const m=document.getElementById('loadFallback'); if(m)m.style.display='block'; return; }
  if (!cfg.supabaseUrl || !cfg.supabaseKey) { const m=document.getElementById('loadFallback'); if(m)m.style.display='block'; return; }
  const sb = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseKey);
  // Privacy-conscious basic page analytics. Session ID is stored only for this browser tab session.
  try {
    let visitId = sessionStorage.getItem('accraLifeVisitId');
    if (!visitId) {
      visitId = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => { const r=Math.random()*16|0; return (c==='x'?r:(r&3|8)).toString(16); });
      sessionStorage.setItem('accraLifeVisitId', visitId);
    }
    sb.rpc('record_site_visit', { p_visitor_id: visitId, p_page_path: location.pathname || '/' }).then(({error}) => { if (error) console.warn('Accra Life analytics was not recorded:', error.message); });
  } catch (e) { console.warn('Accra Life analytics unavailable in this browser session.'); }
  const $ = id => document.getElementById(id);
  let mode = 'signup', user = null, profile = null, activeTab = 'home', selectedRecipient = null, notificationPoll = null, lastNotificationId = null, selectedLifePath = 'semi-rich';
  let venueChannel = null, venueActivePlaceId = null, venuePeopleRefreshBusy = false, activityTimer = null, activitySession = null, workCountdownTimer = null;
  let clubMusicPoll = null, clubMusicVideoId = null, clubMusicRequestId = null, clubAudioEnabled = false;
  let worldPosition = { x: 94, y: 4, action: 'standing', seated: false }, worldSaveTimer = null, worldActionTimer = null, worldMotionTimer = null;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const money = value => Number(value || 0).toLocaleString('en-GH', {minimumFractionDigits:2, maximumFractionDigits:2});
  const toast = message => { const t=$('toast'); t.textContent=message; t.classList.add('show'); clearTimeout(toast.timer); toast.timer=setTimeout(()=>t.classList.remove('show'),3200); };
  const errorText = error => error?.message || 'Something went wrong. Please try again.';
  const setBusy = (button, busy, label) => { if (!button) return; button.disabled=busy; if (busy) {button.dataset.oldLabel=button.textContent;button.textContent=label||'Please wait…';} else if(button.dataset.oldLabel){button.textContent=button.dataset.oldLabel;delete button.dataset.oldLabel;} };
  function showAuth(next='login') { document.getElementById('lifePathOverlay')?.remove(); mode=next; $('landing').classList.add('hidden'); $('game').classList.add('hidden'); $('auth').classList.remove('hidden'); const signup=mode==='signup'; $('usernameWrap').classList.toggle('hidden',!signup); $('confirmPasswordWrap').classList.toggle('hidden',!signup); $('confirmPassword').toggleAttribute('required',signup); $('authEmailNote').classList.toggle('hidden',!signup); $('forgotPassword').classList.toggle('hidden',signup); $('password').autocomplete=signup?'new-password':'current-password'; $('authSubmit').textContent=signup?'Create Account':'Sign In'; $('signInTab').classList.toggle('active',!signup); $('createAccountTab').classList.toggle('active',signup); $('signInTab').setAttribute('aria-selected',String(!signup)); $('createAccountTab').setAttribute('aria-selected',String(signup)); $('switchPrompt').textContent=signup?'Already have an account?':'New to Accra Life?'; $('switchAuth').textContent=signup?'Sign In':'Create Account'; $('authMsg').textContent=''; $('authMsg').className='msg'; }
  function showLanding(){ $('auth').classList.add('hidden'); $('game').classList.add('hidden'); $('landing').classList.remove('hidden'); }
  async function renderLandingPreview(u){
    const nameEl=$('landingPlayerName'),summaryEl=$('landingPlayerSummary'),securityEl=$('landingSecurityLine');
    if(!u){if(nameEl)nameEl.textContent='Guest';if(summaryEl)summaryEl.textContent='New life starts with GH₵ 1,000 · Level 1';if(securityEl)securityEl.textContent='Semi-rich is the default path · Virtual GH₵ wallet';return;}
    try{
      const [p,w]=await Promise.all([
        sb.from('players').select('display_name,username,level').eq('id',u.id).maybeSingle(),
        sb.from('wallets').select('balance').eq('player_id',u.id).maybeSingle()
      ]);
      if(p.error)throw p.error;
      if(nameEl)nameEl.textContent=p.data?.display_name||p.data?.username||u.email?.split('@')[0]||'Player';
      if(summaryEl)summaryEl.textContent=`Balance GH₵ ${money(w.data?.balance)} · Level ${p.data?.level||1}`;
      if(securityEl)securityEl.textContent=`${new Date().toLocaleDateString('en-GH',{weekday:'short',day:'numeric',month:'short'})} · Your saved account · Progress synced`;
    }catch(err){console.warn('Could not load landing account summary:',err);if(nameEl)nameEl.textContent='Your Accra Life';if(summaryEl)summaryEl.textContent='Sign in to load your saved wallet and level';}
  }
  async function loadProfile(u){
    const result=await sb.from('players').select('*').eq('id',u.id).maybeSingle();
    if(result.error) throw result.error;
    if(result.data){profile=result.data;return profile;}
    const raw=(u.user_metadata?.display_name||u.user_metadata?.username||u.email?.split('@')[0]||'New Player').trim();
    const username=raw.toLowerCase().replace(/[^a-z0-9_]/g,'').slice(0,24)||('player_'+u.id.slice(0,8));
    const inserted=await sb.from('players').insert({id:u.id,username,display_name:raw.slice(0,80)}).select('*').single();
    if(inserted.error){const retry=await sb.from('players').select('*').eq('id',u.id).maybeSingle();if(retry.error||!retry.data)throw inserted.error;profile=retry.data;}else profile=inserted.data;
    return profile;
  }
  async function enterGame(u){
    user=u;
    try { await loadProfile(u); $('landing').classList.add('hidden');$('auth').classList.add('hidden');$('game').classList.remove('hidden');$('welcome').textContent=`Welcome, ${profile.display_name||'Player'}`; $('level').textContent=profile.level||1; $('xp').textContent=`${profile.experience||0} XP`; $('footerStatus').textContent='CONNECTED'; const loc=await sb.from('player_locations').select('zone').eq('player_id',u.id).maybeSingle(); const savedZone=loc.data?.zone||localStorage.getItem('accraLifeLocation')||'Osu, Accra'; localStorage.setItem('accraLifeLocation',savedZone); $('locationText').textContent=savedZone.toUpperCase(); $('sceneZone').textContent=savedZone.toUpperCase(); await refreshWallet(); await openTab('home'); startNotificationPolling(); }
    catch(e){console.error(e);$('game').classList.add('hidden');$('auth').classList.remove('hidden');$('authMsg').textContent=`We couldn't load your player profile: ${errorText(e)}`;$('authMsg').className='msg';}
  }
  async function refreshWallet(){ if(!user)return; const r=await sb.from('wallets').select('balance').eq('player_id',user.id).maybeSingle(); if(r.error){$('balance').textContent='—';console.warn(r.error);return;} $('balance').textContent=money(r.data?.balance); }
  async function refreshProfile(){ if(!user)return; const r=await sb.from('players').select('*').eq('id',user.id).maybeSingle();if(r.data){profile=r.data;$('welcome').textContent=`Welcome, ${profile.display_name||'Player'}`;$('level').textContent=profile.level||1;$('xp').textContent=`${profile.experience||0} XP`;} }
  function panel(html){$('panel').innerHTML=html;}
  function header(kicker,title,subtitle,side=''){return `<div class="panel-head"><div><div class="section-label">${esc(kicker)}</div><h2>${esc(title)}</h2><p class="sub">${esc(subtitle)}</p></div>${side}</div>`;}
  function empty(text){return `<div class="empty">${esc(text)}</div>`;}
  async function openTab(tab){
    if(tab!=='map'&&(venueChannel||clubMusicPoll))await leaveVenuePresence();
    activeTab=tab;document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));panel('<div class="loading">Loading your Accra story…</div>');
    try {
      if(tab==='home') return await renderHome();
      if(tab==='map') return await renderMap();
      if(tab==='work') return await renderWork();
      if(tab==='travel') return await renderTravel();
      if(tab==='assets') return await renderAssets();
      if(tab==='social') return await renderSocial();
      if(tab==='phone') return await renderPhone();
      if(tab==='sendmoney') return await renderSendMoney();
      if(tab==='wallet') return await renderWallet();
      if(tab==='business') return await renderBusiness();
      if(tab==='notifications') return await renderNotifications();
      if(tab==='settings') return await renderSettings();
    } catch(e){console.error(e);panel(`${header('A LITTLE SETBACK','Could not load this section',errorText(e))}<button class="action-btn" data-reload="${esc(tab)}">Try again</button>`);}
  }
  async function renderHome(){
    const [wallet,job,home,car,travel]=await Promise.all([
      sb.from('wallets').select('balance').eq('player_id',user.id).maybeSingle(),
      sb.from('player_jobs').select('job_id,jobs(name,salary)').eq('player_id',user.id).maybeSingle(),
      sb.from('player_properties').select('property_id').eq('player_id',user.id),
      sb.from('player_cars').select('car_id').eq('player_id',user.id),
      sb.from('travel_bookings').select('id').eq('player_id',user.id)
    ]);
    const hasLifePath=Object.prototype.hasOwnProperty.call(profile||{},'life_path');
    const path=profile?.life_path||'semi-rich';
    const pathLabels={lapo:'Lapo · Hard mode', 'semi-rich':'Semi-rich · Normal mode', nepo:'Nepo Baby · Easy mode'};
    const allowanceCard=!hasLifePath?'<div class="family-allowance-card"><b>Life paths are ready for setup</b><p>Apply the V41 Supabase migration to activate path-specific wallets, homes, jobs and allowances. Existing balances will not be changed.</p></div>':path==='lapo'?'<div class="family-allowance-card"><b>🥲 Lapo life</b><p>No family allowance on hard mode. Every cedi comes from your hustle.</p></div>':`<div class="family-allowance-card"><div><b>👨‍👩‍👧 Weekly family allowance</b><p>${path==='nepo'?'Your family can send GH₵ 1,000 every 7 days.':'Your family can send GH₵ 200 every 7 days.'}</p></div><button class="primary" id="claimFamilyAllowance">Claim allowance</button><small id="allowanceStatus" aria-live="polite"></small></div>`;
    panel(`${header('YOUR LIFE IN ACCRA','Your Accra, your rules',`Start small, build your reputation, and make your next move. · ${pathLabels[path]}`)}${allowanceCard}<div class="grid"><div class="feature-card" data-tab="work"><div class="feature-icon">💼</div><h3>Build a career</h3><p>${job.data?.jobs?.name?`Current role: ${esc(job.data.jobs.name)}`:'Find your first job and earn a salary.'}</p><span class="card-link">EXPLORE WORK ↗</span></div><div class="feature-card" data-tab="assets"><div class="feature-icon">🏡</div><h3>Own your space</h3><p>${home.data?.length||0} home(s) · ${car.data?.length||0} car(s). Work toward the life you want.</p><span class="card-link">HOMES & CARS ↗</span></div><div class="feature-card" data-tab="travel"><div class="feature-icon">🌍</div><h3>See the world</h3><p>${travel.data?.length||0} trip(s) booked. Explore Ghana and destinations beyond.</p><span class="card-link">PLAN A TRIP ↗</span></div><div class="feature-card" data-tab="social"><div class="feature-icon">🤝</div><h3>Meet your people</h3><p>Discover other players and grow your circle.</p><span class="card-link">GO SOCIAL ↗</span></div><div class="feature-card" data-tab="wallet"><div class="feature-icon">₵</div><h3>Manage your money</h3><p>Your current game balance is GH₵ ${money(wallet.data?.balance)}.</p><span class="card-link">OPEN WALLET ↗</span></div><div class="feature-card" data-tab="business"><div class="feature-icon">📈</div><h3>Think bigger</h3><p>Start a business or explore in-game investments.</p><span class="card-link">BUILD WEALTH ↗</span></div></div>`);
    const claimButton=$('claimFamilyAllowance');
    if(claimButton)claimButton.onclick=async()=>{setBusy(claimButton,true,'Checking allowance…');const status=$('allowanceStatus');try{const result=await sb.rpc('claim_family_allowance');if(result.error)throw result.error;if(status)status.textContent=`Received GH₵ ${money(result.data?.amount)}. New balance: GH₵ ${money(result.data?.balance)}.`;await refreshWallet();await renderHome();toast('Family allowance added to your wallet.');}catch(err){if(status)status.textContent=errorText(err);else toast(errorText(err));setBusy(claimButton,false);}};
  }
  const PHONE_APPS = [
    ['💼','Jobs','work'],['💬','Messages','social'],['🎮','Games','games'],['🤝','MeetGhana','social'],['🎟️','Events','map'],['🧰','HANDY','business'],['🎵','Blacko','map'],['🩺','Health','business'],['🎬','GhMovies','map'],['⚽','Bet','map'],['🚌','Trotro','travel'],['👥','Contacts','social'],['📘','Help & guide','settings'],['🎓','Courses','work'],['🚗','Ride','travel'],['🍲','Chow','map'],['🏦','Bank','wallet'],['💸','Send Money','sendmoney'],['🛍️','Boutique','assets'],['📰','Forbes Ghana','map'],
    ['🏡','Houses','assets'],['🚘','Cars','assets'],['🎁','Invite','social'],['📈','Invest','business'],['🛡️','Insurance','business'],['👨‍👩‍👧','Family','social'],['🧑‍💼','Staff','business'],['💸','Hustle','work'],['🚐','Trotro Co.','business'],['🏢','Company','business'],['🏪','Shops','map'],['🗞️','Accra Gist','map'],['🏛️','Accra Gov','map'],['💚','Give','social'],['🚓','Police','map'],['⚖️','Court','map'],['📣','My Ads','business'],['⚙️','Settings','settings']
  ];
  async function renderPhone(){
    const apps=PHONE_APPS.map(([icon,name,tab],i)=>`<button class="phone-app" data-phone-tab="${esc(tab)}" data-phone-name="${esc(name)}" aria-label="Open ${esc(name)}"><span class="phone-app-icon phone-app-icon-${i%8}">${icon}</span><span>${esc(name)}</span></button>`).join('');
    panel(`${header('YOUR GHANAIAN SMARTPHONE','Accra Phone','Monday · Accra, Ghana · Your apps, your life')}<div class="phone-shell"><div class="phone-status"><b>9:41</b><span>●●●  ▰</span></div><div class="phone-greeting"><div><small>YOUR CITY IN YOUR POCKET</small><h3>Accra Phone 🇬🇭</h3></div><span class="phone-weather">☀️ 29°</span></div><div class="phone-app-grid">${apps}</div><div class="phone-dock"><button data-phone-tab="home">⌂<small>Home</small></button><button data-phone-tab="assets">🛍️<small>Buy</small></button><button data-phone-tab="map">🗺️<small>Map</small></button><button data-phone-tab="phone">📱<small>Phone</small></button></div></div><p class="sub" style="margin-top:12px">Apps open available Accra Life sections. New services will appear here as they are built.</p>`);
  }
  async function renderSendMoney(){
    const bal=await sb.from('wallets').select('balance').eq('player_id',user.id).maybeSingle();
    const level=Number(profile?.level||1),fee=amount=>Math.round(Number(amount||0)*15)/100;
    panel(`${header('PLAYER TRANSFERS','Send Game Money','Send virtual GH₵ to another player. Level 3 required; 15% game fee applies.',`<div class="asset-wallet-pill">₵ <span>Wallet</span><b>GH₵ ${money(bal.data?.balance)}</b></div>`)}<div class="send-money-card"><div class="send-money-note"><b>🔐 Safe virtual transfers</b><span>Max GH₵500 per transfer · GH₵1,000 sent per day</span></div>${level<3?`<div class="empty" style="margin:14px 0">You are Level ${level}. Reach Level 3 to unlock Send Money.</div>`:''}<form id="accraSendMoneyForm"><div class="field"><label for="sendRecipient">Recipient username</label><input class="control" id="sendRecipient" maxlength="25" placeholder="e.g. @hassan" ${level<3?'disabled':''} required></div><div class="field"><label for="sendAmount">Amount they receive (GH₵)</label><input class="control" id="sendAmount" type="number" min="1" max="500" step="1" value="100" ${level<3?'disabled':''} required></div><div class="send-quick-amounts">${[20,50,100,200,500].map(n=>`<button type="button" data-send-amount="${n}" ${level<3?'disabled':''}>GH₵ ${n}</button>`).join('')}</div><div class="send-money-breakdown"><div><span>Recipient receives</span><b id="sendReceive">GH₵ 100.00</b></div><div><span>15% game fee</span><b id="sendFee">GH₵ 15.00</b></div><div class="send-total"><span>You pay in total</span><b id="sendTotal">GH₵ 115.00</b></div></div><div class="field"><label for="sendMessage">Optional message</label><input class="control" id="sendMessage" maxlength="240" placeholder="What is this transfer for?"></div><button class="primary full" type="submit" ${level<3?'disabled':''}>Send GH₵ 100 · fee GH₵ 15.00</button><p class="sub" id="sendMoneyStatus" aria-live="polite" style="margin-top:10px">Virtual game currency only. This is not a real-money payment.</p></form></div>`);
    const input=$('sendAmount');
    function updateBreakdown(){const a=Math.max(0,Math.min(500,Number(input?.value||0)));const f=Math.round(a*15)/100;if($('sendReceive'))$('sendReceive').textContent=`GH₵ ${money(a)}`;if($('sendFee'))$('sendFee').textContent=`GH₵ ${money(f)}`;if($('sendTotal'))$('sendTotal').textContent=`GH₵ ${money(a+f)}`;const submit=$('accraSendMoneyForm')?.querySelector('button[type="submit"]');if(submit)submit.textContent=`Send GH₵ ${money(a)} · fee GH₵ ${money(f)}`;}
    input?.addEventListener('input',updateBreakdown);document.querySelectorAll('[data-send-amount]').forEach(b=>b.addEventListener('click',()=>{if(input){input.value=b.dataset.sendAmount;updateBreakdown();}}));updateBreakdown();
  }
  const ACCRA_PLACES = [
    {id:'church',name:'Church',area:'Accra',kind:'Worship',icon:'⛪',x:51,y:29,image:'https://images.unsplash.com/photo-1438032005730-c779502df39b?auto=format&fit=crop&w=900&q=82',description:'Visit a church, take part in a service, and meet other people in the community.',activities:['Attend a service','Meet the congregation','Join a community event']},
    {id:'gym',name:'Fitness Centre',area:'East Legon',kind:'Fitness',icon:'🏋️',x:88,y:49,image:'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=900&q=82',description:'Work out, improve your fitness, and meet other players.',activities:['Work out','Join a class','Meet gym members']},
    {id:'cinema',name:'Cinema',area:'Accra Mall',kind:'Entertainment',icon:'🎬',x:60,y:50,image:'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=900&q=82',description:'Catch a movie, relax, and meet people before or after the show.',activities:['Watch a movie','Buy snacks','Meet movie fans']},
    {id:'upsa',name:'UPSA',area:'Legon–Madina',kind:'University',icon:'🎓',x:27,y:23,image:'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=900&q=82',description:'Visit campus, meet students, and explore university life.',activities:['Explore campus','Meet students','Visit the hostel']},
    {id:'ug',name:'University of Ghana',area:'Legon',kind:'University',icon:'🏛️',x:65,y:16,image:'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&w=900&q=82',description:'A campus destination for study, friendship, and student activities.',activities:['Walk around campus','Meet friends','Find student events']},
    {id:'hostel',name:'Hostels & Student Homes',area:'Legon / Madina',kind:'Accommodation',icon:'🛏️',x:43,y:38,image:'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=900&q=82',description:'Find a place to stay and build your everyday routine.',activities:['View accommodation','Meet neighbours','Rest at home']},
    {id:'mall',name:'Accra Mall',area:'Tetteh Quarshie',kind:'Shopping',icon:'🛍️',x:72,y:43,image:'https://images.unsplash.com/photo-1519567241046-7f570eee3ce6?auto=format&fit=crop&w=900&q=82',description:'Spend time shopping, browsing stores, and hanging out.',activities:['Go shopping','Meet a friend','Visit a café']},
    {id:'osu',name:'Osu Oxford Street',area:'Osu',kind:'City Centre',icon:'🌆',x:42,y:61,image:'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=900&q=82',description:'Explore the busy city streets, restaurants, and social spots.',activities:['Explore the street','Visit a restaurant','Meet players']},
    {id:'labadi',name:'Labadi Beach',area:'La / Labadi',kind:'Beach',icon:'🏖️',x:72,y:76,image:'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=900&q=82',description:'Relax by the sea, take pictures, and hang out with friends.',activities:['Relax by the sea','Take photos','Meet beachgoers']},
    {id:'eastlegon',name:'East Legon Lounges',area:'East Legon',kind:'Nightlife',icon:'🥂',x:83,y:26,image:'https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&w=900&q=82',description:'Discover stylish lounges, restaurants, and nightlife venues.',activities:['Visit a lounge','Order food','Meet new people']},
    {id:'nightclub',name:'Enzo Lounge',area:'Osu, Accra',kind:'Nightlife',icon:'🎶',x:25,y:72,image:'https://images.unsplash.com/photo-1571266028243-d220c9c3b5c5?auto=format&fit=crop&w=900&q=82',description:'Welcome to Enzo Lounge. Request music for the DJ, dance, sit in the lounge, and meet the crowd.',activities:['Request a song from the DJ','Dance to the music','Sit in the VIP lounge','Meet new people']},
    {id:'apartments',name:'Apartments & Homes',area:'Across Accra',kind:'Homes',icon:'🏡',x:18,y:53,image:'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=900&q=82',description:'Work toward owning a home, decorate it, and host visitors.',activities:['Browse homes','Decorate your home','Invite a guest']}
  ];
  async function renderMap(){
    await leaveVenuePresence();
    const current=localStorage.getItem('accraLifeLocation')||'Osu, Accra';
    const [partyResult,ownedResult,attendeeResult]=await Promise.all([
      sb.from('house_parties').select('id,host_id,property_id,title,party_theme,starts_at,description,status,created_at,properties(name,location)').eq('status','open').gte('starts_at',new Date(Date.now()-3*60*60*1000).toISOString()).order('starts_at',{ascending:true}).limit(30),
      sb.from('player_properties').select('property_id,properties(name,location)').eq('player_id',user.id),
      sb.from('house_party_attendees').select('party_id,player_id')
    ]);
    const parties=partyResult.error?[]:(partyResult.data||[]),owned=ownedResult.error?[]:(ownedResult.data||[]),attendees=attendeeResult.error?[]:(attendeeResult.data||[]);
    const hostIds=[...new Set(parties.map(x=>x.host_id))];let hostNames={};
    if(hostIds.length){const hs=await sb.from('players').select('id,display_name,username').in('id',hostIds);(hs.data||[]).forEach(h=>hostNames[h.id]=h.display_name||h.username||'Player');}
    const pins=ACCRA_PLACES.map(p=>`<button class="map-pin ${current.toLowerCase().includes(p.name.toLowerCase())?'is-current':''}" style="left:${p.x}%;top:${p.y}%" data-place="${p.id}" aria-label="Open ${esc(p.name)}"><span>${p.icon}</span><small>${esc(p.name)}</small></button>`).join('');
    const partyCards=parties.map(p=>{const count=attendees.filter(a=>a.party_id===p.id).length;const joined=attendees.some(a=>a.party_id===p.id&&a.player_id===user.id);const mine=p.host_id===user.id;return `<article class="party-card"><div class="party-card-top"><span class="pill">🏠 ${esc(p.party_theme||'House party')}</span><span class="party-attendee-count">👥 ${count} going</span></div><h4>${esc(p.title)}</h4><p>📍 ${esc(p.properties?.name||'Private home')} · ${esc(p.properties?.location||'Accra')}<br>Hosted by ${esc(hostNames[p.host_id]||'Player')}</p><p class="party-time">🗓 ${new Date(p.starts_at).toLocaleString([], {dateStyle:'medium',timeStyle:'short'})}</p>${p.description?`<p>${esc(p.description)}</p>`:''}${mine?`<button class="action-btn" data-cancel-party="${p.id}">Cancel my party</button>`:joined?`<button class="action-btn" data-leave-party="${p.id}">Leave party</button>`:`<button class="primary" data-join-party="${p.id}" data-party-title="${esc(p.title)}">Join house party</button>`}</article>`;}).join('');
    panel(`${header('YOUR CITY, YOUR STORY','Explore Accra','Tap a place to go there. Visit public spots, meet people, and find house parties.',`<span class="map-current-pill">📍 ${esc(current)}</span>`)}
      <div class="accra-map-shell"><div class="map-top-label"><b>ACCRA</b><span>GREATER ACCRA · GHANA</span></div><div class="accra-map-art" role="group" aria-label="Interactive illustrated map of Accra"><div class="map-water"></div><div class="map-road road-a"></div><div class="map-road road-b"></div><div class="map-road road-c"></div><div class="map-road road-d"></div><div class="map-district district-one">LEGON</div><div class="map-district district-two">EAST LEGON</div><div class="map-district district-three">OSU</div><div class="map-district district-four">LA / LABADI</div>${pins}<div class="map-compass">N<br>↑</div></div><div class="map-legend"><span><i></i> Places to explore</span><span>Tap a pin to open a location</span></div></div>
      <div class="map-place-heading"><div><div class="section-label">PICK YOUR NEXT STOP</div><h3>Places in Accra</h3></div><span class="map-count">${ACCRA_PLACES.length} destinations</span></div><div class="map-place-grid">${ACCRA_PLACES.map(p=>`<article class="map-place-card"><button class="map-photo-button" data-place="${p.id}" aria-label="View ${esc(p.name)}"><img src="${p.image}" alt="Atmosphere photo for ${esc(p.name)}" loading="lazy" onerror="this.style.display='none'"><span class="map-photo-icon">${p.icon}</span><span class="map-kind">${esc(p.kind)}</span></button><div class="map-place-copy"><h4>${esc(p.name)}</h4><p>📍 ${esc(p.area)}</p><button class="action-btn" data-place="${p.id}">View place ↗</button></div></article>`).join('')}</div>
      <section class="house-party-section"><div class="section-label">SOCIAL EVENTS</div><h3>🎉 House parties in Accra</h3><p class="sub">Find a party hosted by another player, or organise one at a property you own. Public listings mean no personal invitation is needed.</p><div class="party-grid">${partyCards||'<div class="party-empty">No upcoming house parties yet. Be the first to organise one!</div>'}</div>
      <div class="party-create-box"><h4>🏡 Organise a house party</h4>${owned.length?`<div class="party-form-grid"><div class="field"><label for="partyProperty">Your property</label><select id="partyProperty" class="control">${owned.map(o=>`<option value="${o.property_id}">${esc(o.properties?.name||'My property')} · ${esc(o.properties?.location||'Accra')}</option>`).join('')}</select></div><div class="field"><label for="partyTitle">Party name</label><input id="partyTitle" class="control" maxlength="80" placeholder="e.g. Friday Night Chill"></div><div class="field"><label for="partyTheme">Party style</label><select id="partyTheme" class="control"><option>House party</option><option>Birthday party</option><option>Game night</option><option>Pool party</option><option>Movie night</option><option>Chill & music</option></select></div><div class="field"><label for="partyStarts">Date and time</label><input id="partyStarts" class="control" type="datetime-local"></div><div class="field party-description-field"><label for="partyDescription">Description (optional)</label><input id="partyDescription" class="control" maxlength="240" placeholder="Music, snacks, dress code…"></div></div><button class="primary" data-action="create-house-party">Publish house party</button>`:'<p class="sub">You need to own a property before you can host a party. Visit Homes & Cars to buy your first place.</p><button class="action-btn" data-tab="assets">Browse properties</button>'}</div></section>
      <p class="map-disclaimer">This is an in-game map, not live GPS navigation. Venue photos are illustrative. House parties are virtual game events.</p>`);
    const dateInput=document.getElementById('partyStarts');if(dateInput){const d=new Date(Date.now()+60*60*1000);d.setMinutes(Math.ceil(d.getMinutes()/15)*15,0,0);dateInput.value=new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,16);dateInput.min=new Date(Date.now()-new Date().getTimezoneOffset()*60000).toISOString().slice(0,16);}
  }
  const NPC_ROSTERS = {
    upsa: [
      {name:'Ama Mensah',role:'Student',x:16,y:14,seated:true,action:'Taking notes'},
      {name:'Kojo Asare',role:'Student',x:33,y:14,seated:true,action:'Listening'},
      {name:'Efua Owusu',role:'Student',x:67,y:14,seated:true,action:'Taking notes'},
      {name:'Yaw Boateng',role:'Student',x:84,y:14,seated:true,action:'Listening'},
      {name:'Abena Osei',role:'Student',x:25,y:56,seated:true,action:'Reading notes'},
      {name:'Kofi Addo',role:'Student',x:75,y:56,seated:true,action:'Listening'},
      {name:'Nana Akua',role:'Student',x:50,y:14,seated:true,action:'Writing in notebook'},
      {name:'Michael Tetteh',role:'Student',x:50,y:56,seated:true,action:'Reading notes'}
    ],
    ug: [
      {name:'Akua',role:'Student',x:20,y:22,seated:true,action:'Studying'}, {name:'Kwame',role:'Student',x:38,y:35,seated:true,action:'Listening'}, {name:'Nana',role:'Student',x:68,y:22,seated:true,action:'Taking notes'}, {name:'Esi',role:'Student',x:82,y:42,seated:true,action:'Reading'}
    ],
    church: [
      {name:'Auntie Mansa',role:'Congregation',x:20,y:23,seated:true,action:'Praying'}, {name:'Brother Daniel',role:'Congregation',x:38,y:28,seated:true,action:'Worshipping'}, {name:'Sister Abena',role:'Congregation',x:66,y:23,seated:true,action:'Praying'}, {name:'Brother Kofi',role:'Congregation',x:82,y:31,seated:true,action:'Worshipping'}
    ],
    nightclub: [
      {name:'Nana Yaa',role:'Clubgoer',x:19,y:9,action:'Dancing'}, {name:'Jay',role:'Clubgoer',x:38,y:18,action:'Dancing'}, {name:'Mimi',role:'Clubgoer',x:68,y:13,action:'Dancing'}, {name:'Kweku',role:'Clubgoer',x:83,y:8,action:'Dancing'}
    ],
    gym: [
      {name:'Fitness coach',role:'Coach',x:22,y:12,action:'Working out'}, {name:'Nii',role:'Gym member',x:42,y:19,action:'Working out'}, {name:'Adjoa',role:'Gym member',x:70,y:12,action:'Working out'}
    ],
    cinema: [
      {name:'Akosua',role:'Moviegoer',x:22,y:15,seated:true,action:'Watching movie'}, {name:'Kwesi',role:'Moviegoer',x:40,y:17,seated:true,action:'Watching movie'}, {name:'Mawuli',role:'Moviegoer',x:68,y:15,seated:true,action:'Watching movie'}, {name:'Efe',role:'Moviegoer',x:83,y:17,seated:true,action:'Watching movie'}
    ],
    labadi: [
      {name:'Abdul',role:'Beachgoer',x:20,y:12,action:'Relaxing'}, {name:'Sena',role:'Beachgoer',x:43,y:20,action:'Walking'}, {name:'Nana Ama',role:'Beachgoer',x:73,y:13,action:'Relaxing'}
    ]
  };
  const worldActivityLabel = action => ({standing:'Standing',walking:'Walking',sitting:'Sitting in class',studying:'Studying',worshipping:'Worshipping',dancing:'Dancing',workingout:'Working out',talking:'Talking',watching:'Watching'}[String(action||'').toLowerCase().replace(/\s+/g,'')] || action || 'Here');
  function characterSprite(person,index,isMe=false,activity='idle'){
    const name=person?.display_name||person?.username||(isMe?(profile?.display_name||'You'):(person?.name||'Player'));
    const skins=['#8d5539','#b8754d','#70432f','#d39a70','#5e382b'];
    const shirts=['#d3f36b','#7cc7d8','#e59cbd','#e9b35e','#b8a3f5','#f1eee4'];
    const skin=person?.isMe?'#8d5539':skins[index%skins.length],shirt=isMe?'#d3f36b':shirts[(index+2)%shirts.length],hair=['#211813','#35251d','#171b21','#583b2a'][index%4];
    const state=String(person?.action||activity||'idle').toLowerCase();
    const motion=state.includes('walk')?'sprite-walk':state.includes('danc')||activity==='dance'?'sprite-dance':state.includes('worship')||state.includes('pray')||activity==='worship'?'sprite-worship':state.includes('workout')||activity==='workout'?'sprite-workout':state.includes('stud')||state.includes('note')||state.includes('reading')?'sprite-study':'sprite-idle';
    const x=Number.isFinite(Number(person?.x))?Math.max(5,Math.min(95,Number(person.x))):(isMe?worldPosition.x:[18,34,66,82,27,73][index%6]);
    const y=Number.isFinite(Number(person?.y))?Math.max(1,Math.min(62,Number(person.y))):(isMe?worldPosition.y:[24,24,24,24,44,44][index%6]);
    const seated=!!person?.seated||!!(isMe&&worldPosition.seated)||state.includes('sitting')||state.includes('listening')||state.includes('taking notes')||state.includes('studying')||state.includes('watching');
    const npc=!!person?.isNpc;
    const stateText=isMe?worldActivityLabel(worldPosition.action):npc?(person.action||person.role||'Here'):person?.onlineNow===false?'Visited recently':(person.action?worldActivityLabel(person.action):'Here now');
    return `<div class="world-character ${isMe?'is-self':''} ${npc?'is-npc':''} ${seated?'is-seated':''} ${motion}" data-world-character="${esc(person?.id||person?.name||'')}" ${npc?'role="button" tabindex="0" aria-label="Talk to '+esc(name)+'"':''} style="--skin:${skin};--shirt:${shirt};--hair:${hair};--delay:${(index%5)*.17}s;left:${x}%;bottom:${y}%" title="${esc(name)}"><span class="world-nameplate">${isMe?'YOU · ':npc?'NPC · ':''}${esc(name)}</span><svg class="character-drawing" viewBox="0 0 70 116" role="img" aria-label="${esc(name)} character"><ellipse cx="35" cy="109" rx="19" ry="5" fill="#07110f" opacity=".35"/><path class="sprite-leg leg-a" d="M25 76 L23 96 L19 105 L30 106 L34 95 L36 77" fill="#293b55" stroke="#17252c" stroke-width="2"/><path class="sprite-leg leg-b" d="M37 76 L39 96 L43 105 L53 104 L48 94 L46 76" fill="#293b55" stroke="#17252c" stroke-width="2"/><path d="M18 104 Q24 100 31 104 L32 109 L17 109Z M41 104 Q47 100 53 103 L56 108 L42 108Z" fill="#f0e6d9"/><path class="sprite-arm arm-a" d="M23 42 Q14 45 13 57 L9 70 L15 73 L23 61 L29 50" fill="var(--skin)" stroke="#38251f" stroke-width="2" stroke-linejoin="round"/><path class="sprite-arm arm-b" d="M45 42 Q54 45 56 57 L61 68 L56 73 L49 61 L41 50" fill="var(--skin)" stroke="#38251f" stroke-width="2" stroke-linejoin="round"/><path d="M24 39 Q35 33 46 39 L49 73 Q35 80 21 73Z" fill="var(--shirt)" stroke="#24352d" stroke-width="2"/><path d="M29 39 L35 48 L41 39" fill="#ffffff66"/><rect x="30" y="31" width="10" height="11" rx="4" fill="var(--skin)"/><ellipse cx="35" cy="21" rx="16" ry="19" fill="var(--skin)"/><path d="M19 21 Q15 5 30 3 Q46 -1 51 15 L50 22 Q46 12 39 12 Q29 17 20 14Z" fill="var(--hair)"/><path d="M20 22 Q18 28 21 31" fill="none" stroke="var(--hair)" stroke-width="4" stroke-linecap="round"/><ellipse cx="29" cy="22" rx="1.6" ry="2" fill="#201a18"/><ellipse cx="41" cy="22" rx="1.6" ry="2" fill="#201a18"/><path d="M30 29 Q35 32 40 28" fill="none" stroke="#733f31" stroke-width="1.6" stroke-linecap="round"/><path d="M26 16 Q30 13 33 16 M38 16 Q42 13 45 16" stroke="var(--hair)" stroke-width="2" fill="none" stroke-linecap="round"/></svg><span class="world-character-state">${esc(stateText)}</span></div>`;
  }
  function sceneCharactersHtml(placeId,people){
    const current={id:user?.id,display_name:profile?.display_name||'You',username:profile?.username,level:profile?.level||1,isMe:true,x:worldPosition.x,y:worldPosition.y,action:worldPosition.action,seated:worldPosition.seated};
    const live=(people||[]).filter(person=>person.isNpc||person.onlineNow!==false);
    const roster=(NPC_ROSTERS[placeId]||[
      {name:'Ama',role:'Local resident',x:20,y:13,action:'Talking'}, {name:'Kojo',role:'Local resident',x:42,y:21,action:'Standing'}, {name:'Esi',role:'Local resident',x:70,y:14,action:'Talking'}, {name:'Nii',role:'Local resident',x:84,y:24,action:'Standing'}
    ]).map((npc,i)=>({...npc,id:`npc-${placeId}-${i}`,display_name:npc.name,isNpc:true,onlineNow:true}));
    const list=[current,...roster,...live];
    const unique=[];const seen=new Set();for(const person of list){if(!person?.id||seen.has(person.id))continue;seen.add(person.id);unique.push(person);}
    const kind=placeId==='church'?'worship':placeId==='gym'?'workout':['nightclub','eastlegon'].includes(placeId)?'dance':'idle';
    return unique.slice(0,13).map((person,i)=>characterSprite(person,i,!!person.isMe||person.id===user?.id,kind)).join('');
  }
  function liveWorldMarkup(placeId,people=[]){
    const classes=placeId==='church'?'world-church':placeId==='nightclub'?'world-club':placeId==='gym'?'world-gym':placeId==='labadi'?'world-beach':placeId==='upsa'?'world-classroom':placeId==='ug'?'world-campus':placeId==='cinema'?'world-cinema':'world-lounge';
    const props=placeId==='church'?'<div class="world-window win-a"></div><div class="world-window win-b"></div><div class="world-altar">✝<small>ALTAR</small></div><div class="world-pew pew-a"></div><div class="world-pew pew-b"></div>':placeId==='nightclub'?'<div class="club-beam beam-a"></div><div class="club-beam beam-b"></div><div class="club-dj">♫<small>DJ</small></div><div class="club-floor"></div>':placeId==='gym'?'<div class="gym-mirror"></div><div class="gym-rack">▥ ▥ ▥</div>':placeId==='labadi'?'<div class="beach-sun"></div><div class="beach-wave wave-a"></div><div class="beach-wave wave-b"></div>':placeId==='cinema'?'<div class="cinema-screen">NOW SHOWING</div><div class="cinema-seat seat-a"></div><div class="cinema-seat seat-b"></div>':placeId==='upsa'?'<div class="classroom-board"><b>UPSA</b><span>BUSINESS POLICY & STRATEGY</span><small>UPSA · LECTURE HALL</small></div><div class="classroom-teacher"><span class="teacher-head"></span><span class="teacher-body"></span><b>LECTURER</b></div><div class="classroom-desk desk-a"></div><div class="classroom-desk desk-b"></div><div class="classroom-desk desk-c"></div><div class="classroom-desk desk-d"></div><div class="classroom-desk desk-e"></div><div class="classroom-desk desk-f"></div><div class="classroom-desk desk-g"></div><div class="classroom-desk desk-h"></div><div class="classroom-door">EXIT</div><div class="classroom-room-sign">ROOM 204 · BUSINESS ADMINISTRATION</div>':'<div class="world-lamp"></div><div class="world-window win-a"></div><div class="world-sofa"></div>';
    return `<div class="live-game-world ${classes}" aria-label="Playable 2D scene at this location"><div class="world-set-dressing">${props}</div><div class="world-character-stage" id="venueCharacterStage">${sceneCharactersHtml(placeId,people)}</div><div class="world-scene-label">LIVE 2D WORLD <span>•</span> NPCs & online players</div></div>`;
  }
  function worldControlsMarkup(placeId){
    const isClass=placeId==='upsa';
    const secondAction=isClass?'study':placeId==='church'?'worship':placeId==='nightclub'?'dance':placeId==='gym'?'workout':'explore';
    const secondLabel=isClass?'📚 Attend lecture':placeId==='church'?'🙏 Worship':placeId==='nightclub'?'💃 Dance':placeId==='gym'?'🏋️ Work out':'✨ Interact';
    return `<section class="world-play-controls"><div class="world-controls-title"><div><div class="section-label">YOUR CHARACTER</div><h3>${isClass?'Walk in, find a desk and attend class':'Move around this place'}</h3><p id="worldActionStatus">${isClass?'You are by the classroom door. Walk to a desk, sit down, then attend the lecture.':'You have arrived. Move around and interact with the venue.'}</p></div><span class="world-control-hint">Use arrows / WASD</span></div><div class="world-controls-row"><div class="world-dpad" aria-label="Movement controls"><button type="button" data-world-move="0,1" aria-label="Move up">▲</button><div><button type="button" data-world-move="-1,0" aria-label="Move left">◀</button><button type="button" data-world-move="0,-1" aria-label="Move down">▼</button><button type="button" data-world-move="1,0" aria-label="Move right">▶</button></div></div><div class="world-actions"><button type="button" class="action-btn" data-world-action="${isClass?'sit':'talk'}">${isClass?'🪑 Sit at a desk':'💬 Talk to someone'}</button><button type="button" class="action-btn" data-world-action="${secondAction}">${secondLabel}</button><button type="button" class="action-btn" data-world-action="stand">Stand up</button><button type="button" class="action-btn" data-world-action="leave">🚪 Leave location</button></div></div><p class="world-control-footnote">The people marked <b>NPC</b> are computer-controlled characters. Real players are shown separately when they are online in this same place.</p></section>`;
  }
  async function updateWorldPresence(){
    if(!user||!venueChannel||!venueActivePlaceId)return;
    try{await venueChannel.track({player_id:user.id,display_name:profile?.display_name||'Player',username:profile?.username||'player',level:profile?.level||1,x:worldPosition.x,y:worldPosition.y,action:worldPosition.action,seated:worldPosition.seated,joined_at:new Date().toISOString()});}catch(e){console.warn('Could not update live character position:',e);}
    clearTimeout(worldSaveTimer);worldSaveTimer=setTimeout(async()=>{const p=ACCRA_PLACES.find(x=>x.id===venueActivePlaceId);if(!p)return;const r=await sb.from('player_locations').upsert({player_id:user.id,zone:`${p.name}, Accra`,x:worldPosition.x/100,y:worldPosition.y/100,updated_at:new Date().toISOString()},{onConflict:'player_id'});if(r.error)console.warn('Could not save character position:',r.error);},700);
  }
  function paintWorldCharacter(){
    const stage=document.getElementById('venueCharacterStage');if(!stage)return;
    const me=stage.querySelector('.world-character.is-self');if(me){me.style.left=`${worldPosition.x}%`;me.style.bottom=`${worldPosition.y}%`;me.classList.toggle('is-seated',!!worldPosition.seated);me.classList.remove('sprite-walk','sprite-dance','sprite-worship','sprite-workout','sprite-study','sprite-idle');const a=String(worldPosition.action||'').toLowerCase();const motion=a==='walking'?'sprite-walk':a==='dancing'?'sprite-dance':a==='worshipping'?'sprite-worship':a==='working out'?'sprite-workout':a==='studying'?'sprite-study':'sprite-idle';me.classList.add(motion);const state=me.querySelector('.world-character-state');if(state)state.textContent=worldActivityLabel(worldPosition.action);}
    const status=document.getElementById('worldActionStatus');if(status)status.textContent=worldPosition.seated?(worldPosition.action==='studying'?'You are seated and following the lecture.':'You are seated at your desk. Choose Attend lecture to study.') :worldPosition.action==='walking'?'Your character is walking through the room.':`Your character is ${worldActivityLabel(worldPosition.action).toLowerCase()}.`;
  }
  function animateWorldTo(targetX,targetY,finalAction='standing',finalSeated=false,doneMessage=''){
    if(!venueActivePlaceId)return Promise.resolve();
    clearInterval(worldMotionTimer);
    const startX=worldPosition.x,startY=worldPosition.y;
    const endX=Math.max(5,Math.min(95,targetX)),endY=Math.max(2,Math.min(60,targetY));
    const distance=Math.hypot(endX-startX,endY-startY);
    const duration=Math.max(260,Math.min(1050,distance*11));
    const started=performance.now();
    worldPosition.action='walking';worldPosition.seated=false;paintWorldCharacter();
    if(distance<0.5){worldPosition.x=endX;worldPosition.y=endY;worldPosition.action=finalAction;worldPosition.seated=finalSeated;paintWorldCharacter();updateWorldPresence();if(doneMessage)toast(doneMessage);return Promise.resolve();}
    return new Promise(resolve=>{
      worldMotionTimer=setInterval(()=>{
        const t=Math.min(1,(performance.now()-started)/duration),ease=t*t*(3-2*t);
        worldPosition.x=startX+(endX-startX)*ease;worldPosition.y=startY+(endY-startY)*ease;
        worldPosition.action='walking';worldPosition.seated=false;paintWorldCharacter();
        if(t>=1){clearInterval(worldMotionTimer);worldMotionTimer=null;worldPosition.x=endX;worldPosition.y=endY;worldPosition.action=finalAction;worldPosition.seated=finalSeated;paintWorldCharacter();updateWorldPresence();if(doneMessage)toast(doneMessage);resolve();}
      },30);
    });
  }
  function moveWorldCharacter(dx,dy){
    if(!venueActivePlaceId)return;
    const x=Math.max(7,Math.min(93,worldPosition.x+dx*7));
    const y=Math.max(2,Math.min(60,worldPosition.y+dy*7));
    animateWorldTo(x,y,'standing',false);
  }
  function nearestClassDesk(){
    const desks=[{x:16.5,y:14},{x:33.5,y:14},{x:50.5,y:14},{x:67.5,y:14},{x:84.5,y:14},{x:25,y:56},{x:75,y:56}];
    return desks.reduce((best,d)=>Math.hypot(d.x-worldPosition.x,d.y-worldPosition.y)<Math.hypot(best.x-worldPosition.x,best.y-worldPosition.y)?d:best,desks[0]);
  }
  async function doWorldAction(action){
    if(!venueActivePlaceId)return;
    if(action==='leave'){
      const p=ACCRA_PLACES.find(x=>x.id===venueActivePlaceId);if(!p)return;
      await animateWorldTo(94,3,'standing',false);
      const zone='Osu, Accra';localStorage.setItem('accraLifeLocation',zone);$('locationText').textContent=zone.toUpperCase();$('sceneZone').textContent=zone.toUpperCase();
      await sb.from('player_locations').upsert({player_id:user.id,zone,x:.5,y:.5,updated_at:new Date().toISOString()},{onConflict:'player_id'});
      toast(`You walked out of ${p.name}.`);openTab('map');return;
    }
    if(action==='sit'||action==='study'){
      const desk=nearestClassDesk();
      await animateWorldTo(desk.x,desk.y,action==='study'?'studying':'sitting',true,action==='study'?'You sat down and the lecture has started.':'You walked to a desk and sat down.');
      return;
    }
    if(action==='stand'){
      await animateWorldTo(worldPosition.x,Math.max(3,worldPosition.y-7),'standing',false,'You stood up from your seat.');return;
    }
    if(action==='dance'){worldPosition.seated=false;worldPosition.action='dancing';toast('You joined the dance floor.');}
    else if(action==='worship'){worldPosition.seated=false;worldPosition.action='worshipping';toast('You joined the worship service.');}
    else if(action==='workout'){worldPosition.seated=false;worldPosition.action='working out';toast('You started your workout.');}
    else if(action==='talk'){worldPosition.seated=false;worldPosition.action='talking';toast('Choose a nearby character to start a conversation.');}
    else {worldPosition.seated=false;worldPosition.action='exploring';toast('You are exploring the venue.');}
    paintWorldCharacter();updateWorldPresence();
  }
  async function renderHouseParty(partyId){
    const pr=await sb.from('house_parties').select('id,host_id,property_id,title,party_theme,starts_at,description,status,properties(name,location)').eq('id',partyId).maybeSingle();
    if(pr.error||!pr.data){toast('This house party is no longer available.');await openTab('map');return;}
    const party=pr.data;const ar=await sb.from('house_party_attendees').select('player_id,joined_at').eq('party_id',partyId).order('joined_at');
    const ids=[...new Set([party.host_id,...(ar.data||[]).map(a=>a.player_id)])];let people=[];
    if(ids.length){const players=await sb.from('players').select('id,display_name,username,level').in('id',ids);if(!players.error)people=players.data||[];}
    const byId=new Map(people.map(x=>[x.id,x]));
    const guestCards=ids.map(id=>{const person=byId.get(id);if(!person)return '';const isHost=id===party.host_id;return `<article class="venue-person"><div class="venue-avatar">${esc((person.display_name||person.username||'P').slice(0,1).toUpperCase())}</div><div class="venue-person-copy"><b>${esc(person.display_name||person.username||'Player')}</b><small>@${esc(person.username||'player')} · Level ${person.level||1}<br>${isHost?'<span class="pill">HOST</span>':'At this party'}</small></div>${id!==user.id?`<button class="action-btn" data-party-message="${id}" data-person-name="${esc(person.display_name||person.username||'Player')}">Say hi</button>`:''}</article>`;}).join('');
    const isHost=party.host_id===user.id;
    panel(`${header('SOCIAL EVENT · YOU ARE HERE',`🎉 ${party.title}`,`${party.party_theme||'House party'} · ${party.properties?.name||'Private home'} · ${party.properties?.location||'Accra'}`,`<button class="action-btn" data-tab="map">← Back to map</button>`)}<section class="venue-scene venue-party-scene"><img src="https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=1200&q=82" alt="House party atmosphere" onerror="this.style.display='none'"><div class="venue-scene-shade"></div><div class="live-game-world world-party"><div class="world-set-dressing"><div class="party-bunting">✦　✧　✦　✧　✦</div><div class="world-sofa"></div><div class="party-speaker">♫</div></div><div class="world-character-stage">${ids.map((id,i)=>{const person=byId.get(id);return person?characterSprite({...person,x:id===user.id?worldPosition.x:undefined,y:id===user.id?worldPosition.y:undefined,action:'dancing'},i,id===user.id,'dance'):'';}).join('')}${[{name:'Mimi',role:'Party guest',x:22,y:10,action:'Dancing'},{name:'Kojo',role:'Party guest',x:48,y:17,action:'Dancing'},{name:'Abena',role:'Party guest',x:77,y:11,action:'Dancing'}].map((npc,i)=>characterSprite({...npc,id:`npc-party-${i}`,display_name:npc.name,isNpc:true},ids.length+i,false,'dance')).join('')}</div><div class="world-scene-label">2D HOUSE PARTY <span>•</span> ${ids.length+3} characters in the room</div></div><div class="venue-scene-caption"><span class="venue-live-pill">🏠 HOUSE PARTY · GUEST LIST</span><h3>${esc(party.title)}</h3><p>${esc(party.description||'Meet other players, say hello, and enjoy the party.')}</p><p>🗓 ${new Date(party.starts_at).toLocaleString([], {dateStyle:'medium',timeStyle:'short'})}</p></div></section><section class="venue-crowd"><div class="venue-crowd-head"><div><div class="section-label">THE GUESTS</div><h3>Who's at the party?</h3><p class="sub">Players who joined this party appear here. Say hi to start getting to know them.</p></div><span class="venue-count">${ids.length} ${ids.length===1?'person':'people'}</span></div><div class="venue-people-list">${guestCards||'<div class="venue-empty">No guests have joined yet.</div>'}</div><button class="action-btn" style="margin-top:12px" data-refresh-party="${partyId}">Refresh guest list</button>${isHost?`<button class="action-btn" style="margin:12px 0 0;width:100%" data-cancel-party="${partyId}">Cancel my party</button>`:`<button class="action-btn" style="margin:12px 0 0;width:100%" data-leave-party="${partyId}">Leave party</button>`}</section><p class="map-disclaimer">This is a virtual social event in Accra Life.</p>`);
  }
  function openPlace(placeId){
    const p=ACCRA_PLACES.find(x=>x.id===placeId);if(!p)return;
    document.querySelector('.place-detail-overlay')?.remove();
    const overlay=document.createElement('div');overlay.className='hire-modal-overlay place-detail-overlay';
    overlay.innerHTML=`<div class="hire-modal place-detail-modal"><button class="place-close" id="closePlace" aria-label="Close">×</button><img class="place-detail-image" src="${p.image}" alt="Illustrative scene for ${esc(p.name)}" onerror="this.style.display='none'"><div class="section-label">${esc(p.kind)} · ${esc(p.area)}</div><h2>${p.icon} ${esc(p.name)}</h2><p>${esc(p.description)}</p><div class="place-activities"><b>WHAT YOU CAN DO</b>${p.activities.map(a=>`<span>✦ ${esc(a)}</span>`).join('')}</div><button class="primary full" id="visitPlace">GO TO THIS PLACE ↗</button><p class="hire-modal-sub">This updates your in-game location. Real-world travel is not involved.</p></div>`;
    document.body.appendChild(overlay);
    const close=()=>overlay.remove();overlay.querySelector('#closePlace').onclick=close;overlay.addEventListener('click',e=>{if(e.target===overlay)close();});
    overlay.querySelector('#visitPlace').onclick=async()=>{
      const zone=`${p.name}, Accra`;worldPosition={x:94,y:4,action:'standing',seated:false};localStorage.setItem('accraLifeLocation',zone);
      $('locationText').textContent=zone.toUpperCase();$('sceneZone').textContent=zone.toUpperCase();
      const coords={x:p.x/100,y:p.y/100};
      try{const saved=await sb.from('player_locations').upsert({player_id:user.id,zone,x:coords.x,y:coords.y,updated_at:new Date().toISOString()},{onConflict:'player_id'});if(saved.error)console.warn('Could not save map location:',saved.error);}catch(err){console.warn(err);}
      close();toast(`You arrived at ${p.name}!`);await renderVenue(p.id);
    };
  }
  async function leaveVenuePresence(){
    stopClubMusicPolling();
    clearInterval(activityTimer);activityTimer=null;activitySession=null;
    const old=venueChannel;venueChannel=null;venueActivePlaceId=null;
    if(old){try{await sb.removeChannel(old);}catch(err){console.warn('Could not leave venue presence:',err);}}
  }
  function venuePersonCard(person,online){
    const name=person.display_name||person.username||'Player';
    return `<article class="venue-person"><div class="venue-avatar">${esc(name.slice(0,1).toUpperCase())}</div><div class="venue-person-copy"><b>${esc(name)}</b><small>@${esc(person.username||'player')} · Level ${person.level||1}<br><span class="venue-live-dot" style="background:${online?'#d3f36b':'#9ba6a3'}"></span>${online?'Online here now':'Visited recently'}</small></div><div class="venue-person-actions"><button class="action-btn" data-friend="${person.id}">Add friend</button><button class="action-btn" data-venue-message="${person.id}" data-person-name="${esc(name)}">Say hi</button></div></article>`;
  }
  async function refreshVenueCrowd(placeId){
    if(venuePeopleRefreshBusy||venueActivePlaceId!==placeId||!user)return;
    venuePeopleRefreshBusy=true;
    try{
      const p=ACCRA_PLACES.find(x=>x.id===placeId);if(!p)return;
      const zone=`${p.name}, Accra`,cutoff=new Date(Date.now()-45*60*1000).toISOString();
      const byId=new Map(),onlineIds=new Set();
      if(venueChannel){
        const state=venueChannel.presenceState();
        Object.values(state||{}).flat().forEach(person=>{
          const id=person.player_id||person.id;
          if(!id||id===user.id)return;
          onlineIds.add(id);byId.set(id,{id,display_name:person.display_name,username:person.username,level:person.level||1,x:person.x,y:person.y,action:person.action,seated:person.seated});
        });
      }
      const locs=await sb.from('player_locations').select('player_id,updated_at').eq('zone',zone).neq('player_id',user.id).gte('updated_at',cutoff).order('updated_at',{ascending:false}).limit(40);
      if(!locs.error){
        const ids=(locs.data||[]).map(x=>x.player_id).filter(id=>!byId.has(id));
        if(ids.length){const found=await sb.from('players').select('id,display_name,username,level,experience').in('id',ids);if(!found.error)(found.data||[]).forEach(person=>byId.set(person.id,person));}
      }
      const blocked=await sb.from('blocks').select('blocked_id').eq('blocker_id',user.id);const blockedIds=new Set((blocked.data||[]).map(b=>b.blocked_id));const people=[...byId.values()].filter(person=>!blockedIds.has(person.id));
      people.sort((a,b)=>Number(onlineIds.has(b.id))-Number(onlineIds.has(a.id))||(a.display_name||a.username||'').localeCompare(b.display_name||b.username||''));
      const list=document.getElementById('venuePeopleList'),count=document.getElementById('venueCount');
      if(!list||venueActivePlaceId!==placeId)return;
      if(count)count.textContent='Recent visitors';
      const characterStage=document.getElementById('venueCharacterStage');
      people.forEach(person=>{person.onlineNow=onlineIds.has(person.id);});
      if(characterStage){characterStage.innerHTML=sceneCharactersHtml(placeId,people.filter(person=>onlineIds.has(person.id)));const worldLabel=characterStage.closest('.live-game-world')?.querySelector('.world-scene-label');if(worldLabel)worldLabel.innerHTML=`LIVE 2D WORLD <span>•</span> ${characterStage.querySelectorAll('.world-character').length} characters in scene`;}
      list.innerHTML=people.length?people.map(person=>venuePersonCard(person,onlineIds.has(person.id))).join(''):`<div class="venue-empty"><div>👋</div><b>You're one of the first here!</b><p>Stay in this venue to meet other players when they arrive. When someone else opens this same place, they can appear here live—no invitation needed.</p><button class="action-btn" data-refresh-crowd="${placeId}">Check for people again</button></div>`;
    }catch(err){console.warn('Could not refresh venue crowd:',err);}
    finally{venuePeopleRefreshBusy=false;}
  }
  const activityDetails=(place,index)=>{
    const name=place.activities[index]||'Explore this place';
    const lower=name.toLowerCase(),kind=place.kind.toLowerCase();
    let icon='✨',action='Take part in the activity',description=`Your character will spend a little time ${name.toLowerCase()} at ${place.name}.`,duration=12,xp=12;
    if(kind.includes('fitness')||place.id==='gym'){
      icon=lower.includes('weight')?'🏋️':lower.includes('bike')?'🚴':lower.includes('stretch')?'🧘':'🏃';
      action='Start workout';description='Your character begins a workout. Stay for the full session to earn fitness XP.';duration=15;xp=20;
    }else if(kind.includes('worship')||place.id==='church'){
      icon=lower.includes('service')?'🙏':lower.includes('worship')?'🎵': '🤝';action=lower.includes('meet')?'Join the fellowship':'Attend activity';description='Your character joins the church activity and spends time with the congregation.';duration=12;xp=15;
    }else if(place.id==='nightclub'||kind.includes('nightlife')){icon=lower.includes('dance')?'💃':lower.includes('music')?'🎵':'🪩';action='Join the vibe';description='Your character joins the music and social atmosphere. Stay until the activity finishes.';duration=14;xp=16;
    }else if(place.id==='labadi'){icon=lower.includes('photo')?'📸':lower.includes('game')?'🏐': '🌊';action='Start beach activity';description='Your character enjoys time by the sea. Complete the activity to earn XP.';duration=12;xp=14;
    }else if(place.id==='upsa'||place.id==='ug'){icon=lower.includes('study')?'📚':lower.includes('class')?'📝':'🎓';action='Start campus activity';description='Your character takes part in campus life and gains experience.';duration=14;xp=18;
    }else if(place.id==='cinema'){icon='🎬';action='Start movie time';description='Your character settles in for movie time.';duration=12;xp=12;
    }else if(place.id==='mall'){icon='🛍️';action='Start shopping';description='Your character explores the shops and spends time around the mall.';duration=10;xp=10;
    }else if(place.id==='osu'||place.id==='eastlegon'){icon='🍽️';action='Explore the area';description='Your character checks out the local scene and can meet other players nearby.';duration=10;xp=10;
    }else if(place.id==='hostel'||place.id==='apartments'){icon=lower.includes('rest')?'🛌':'🏡';action='Do this at home';description='Your character spends time at home and makes progress in their daily life.';duration=10;xp=10;}
    return {name,icon,action,description,duration,xp};
  };
  function showActivityStage(place,index,state){
    const root=document.getElementById('activityStage');if(!root)return;
    if(!state){const d=activityDetails(place,index);root.innerHTML=`<div class="activity-stage activity-ready"><div class="activity-avatar" aria-hidden="true">${d.icon}</div><div class="activity-copy"><div class="section-label">YOUR CHARACTER · ${esc(place.name.toUpperCase())}</div><h3>${esc(d.name)}</h3><p>${esc(d.description)}</p><div class="activity-reward"><span>⏱ ${d.duration} seconds</span><span>⭐ +${d.xp} XP on completion</span></div><div class="activity-actions"><button type="button" class="primary" data-start-activity="${place.id}:${index}">${esc(d.action)} ▶</button><span class="activity-note">Your character will animate while the activity is running.</span></div></div></div>`;return;}
    const d=activityDetails(place,index);
    if(state.status==='running')root.innerHTML=`<div class="activity-stage activity-running"><div class="activity-avatar activity-moving" aria-hidden="true">${d.icon}</div><div class="activity-copy"><div class="section-label">ACTIVITY IN PROGRESS</div><h3>${esc(d.name)}</h3><p>${esc(state.message||d.description)}</p><div class="activity-progress"><span style="width:${Math.max(0,Math.min(100,((d.duration-state.remaining)/d.duration)*100))}%"></span></div><div class="activity-reward"><span>⏱ ${state.remaining}s remaining</span><span>⭐ +${d.xp} XP</span></div><button type="button" class="action-btn" data-cancel-activity="${place.id}" data-activity-index="${index}">Stop activity</button></div></div>`;
    else root.innerHTML=`<div class="activity-stage activity-complete"><div class="activity-avatar" aria-hidden="true">✅</div><div class="activity-copy"><div class="section-label">ACTIVITY COMPLETED</div><h3>${esc(d.name)} finished!</h3><p>${esc(state.message||'Great job! Your progress has been saved.')}</p><div class="activity-reward"><span>⭐ +${d.xp} XP earned</span><span>🏆 Progress saved</span></div><button type="button" class="action-btn" data-place-activity="${index}" data-place-id="${place.id}">Do it again</button></div></div>`;
  }
  function beginActivity(key){
    const [placeId,indexRaw]=String(key||'').split(':');const place=ACCRA_PLACES.find(p=>p.id===placeId),index=Number(indexRaw);if(!place||!place.activities[index])return;
    if(venueActivePlaceId===placeId){worldPosition.seated=['upsa','ug','cinema'].includes(placeId);worldPosition.action=placeId==='upsa'||placeId==='ug'?'studying':placeId==='church'?'worshipping':placeId==='nightclub'||placeId==='eastlegon'?'dancing':placeId==='gym'?'working out':placeId==='cinema'?'watching':'exploring';paintWorldCharacter();updateWorldPresence();}
    clearInterval(activityTimer);const d=activityDetails(place,index);activitySession={placeId,index,remaining:d.duration};showActivityStage(place,index,{status:'running',remaining:d.duration,message:d.description});
    activityTimer=setInterval(async()=>{
      if(!activitySession||activitySession.placeId!==placeId){clearInterval(activityTimer);activityTimer=null;return;}
      activitySession.remaining-=1;
      if(activitySession.remaining>0){showActivityStage(place,index,{status:'running',remaining:activitySession.remaining,message:d.description});return;}
      clearInterval(activityTimer);activityTimer=null;const finished=activitySession;activitySession=null;
      try{
        const inserted=await sb.from('player_activity_log').insert({player_id:user.id,place_id:place.id,place_name:place.name,activity_name:d.name,xp_earned:d.xp,duration_seconds:d.duration});
        if(inserted.error)throw inserted.error;
        const oldXP=Number(profile?.experience||0),newXP=oldXP+d.xp,newLevel=Math.max(1,Math.floor(newXP/100)+1);
        const updated=await sb.from('players').update({experience:newXP,level:newLevel,updated_at:new Date().toISOString()}).eq('id',user.id);
        if(updated.error)console.warn('Activity was saved but XP could not be updated:',updated.error);
        await refreshProfile();showActivityStage(place,index,{status:'complete',message:`You completed ${d.name.toLowerCase()} at ${place.name}. Your activity was recorded and ${d.xp} XP ${updated.error?'could not be synced':'added'} to your progress.`});toast(`Activity completed! +${d.xp} XP`);
      }catch(err){console.error('Could not save completed activity:',err);showActivityStage(place,index,{status:'complete',message:`You finished the activity, but saving progress failed: ${errorText(err)}. Please try again.`});toast('Activity finished, but progress could not be saved.');}
    },1000);
  }
  const MUSIC_ENABLED_PLACES = new Set(['church','gym','labadi','nightclub','eastlegon','osu','mall']);
  const MUSIC_VENUE_COPY = {
    church:{label:'CHURCH MUSIC',title:'⛪ Gospel & worship',hint:'Request gospel, praise and worship music for this church.',button:'🙏 Send worship request',genre:'Gospel · Praise · Worship'},
    gym:{label:'GYM SOUND SYSTEM',title:'🏋🏽 Workout music',hint:'Request a track for the gym queue while your character works out.',button:'💪 Send gym request',genre:'Afrobeats · Hip-hop · Gospel · Workout'},
    labadi:{label:'BEACH SOUND SYSTEM',title:'🏖️ Beach music',hint:'Request relaxing tracks or beach-party music.',button:'🌊 Send beach request',genre:'Relaxing · Afrobeats · Beach party'},
    nightclub:{label:'ENZO DJ BOOTH',title:'🪩 Request a song',hint:'Request a track for Enzo’s shared DJ queue.',button:'🎵 Send DJ request',genre:'Afrobeats · Highlife · Hip-life · Drill · Amapiano'},
    eastlegon:{label:'LOUNGE MUSIC',title:'🥂 Lounge playlist',hint:'Request music for the East Legon lounge.',button:'🎶 Send lounge request',genre:'Afrobeats · R&B · Chill'},
    osu:{label:'OSU MUSIC',title:'🌆 Street & restaurant music',hint:'Request music for the Osu hangout.',button:'🎵 Send request',genre:'Afrobeats · Highlife · R&B'},
    mall:{label:'CAFÉ MUSIC',title:'🛍️ Café & hangout music',hint:'Request background music for the Accra Mall hangout.',button:'🎵 Send request',genre:'Chill · Afrobeats · Highlife'}
  };
  const venueQueueId = placeId => placeId==='nightclub' ? 'enzo' : placeId;
  function clubMusicMarkup(placeId){
    const c=MUSIC_VENUE_COPY[placeId]||MUSIC_VENUE_COPY.nightclub;
    return `<section class="club-music-panel club-music-premium ${placeId==='nightclub'?'enzo-premium':''}" id="clubMusicPanel"><div class="club-music-heading"><div><div class="section-label">${esc(c.label)}</div><h3>${esc(c.title)}</h3><p class="sub">${esc(c.hint)} Shared queue: ${esc(c.genre)}.</p></div><span class="club-live-badge">● LIVE QUEUE</span></div><form id="clubSongForm" class="club-song-form"><div class="club-song-fields"><div class="field"><label for="clubSongTitle">Song title</label><input id="clubSongTitle" class="control" maxlength="120" required placeholder="Song title" /></div><div class="field"><label for="clubSongArtist">Artist</label><input id="clubSongArtist" class="control" maxlength="120" required placeholder="Artist name" /></div></div><button class="action-btn club-request-button" type="submit">${esc(c.button)}</button><p class="club-music-note">Request by title and artist only. For Ghanaian sounds, try Black Sherif, Sarkodie, Stonebwoy, or a highlife classic. Links are handled by the owner in the private admin console.</p></form><div class="club-now-playing" id="clubNowPlaying"><div class="club-now-icon">♫</div><div><small>NOW PLAYING HERE</small><b id="clubNowTitle">Waiting for the DJ…</b><span id="clubNowArtist">The next accepted request will appear here.</span></div></div><div id="clubSongPlayer" class="club-song-player"><div class="club-player-placeholder">🎶 The accepted song appears here. Tap to play it on this device.</div></div><div class="club-queue-heading"><h4>This venue’s song queue</h4><span class="pill">Auto-refreshes</span></div><div id="clubSongQueue" class="club-song-queue"><div class="club-player-placeholder">Loading requests…</div></div><div class="personal-music-box"><div class="section-label">YOUR OWN MUSIC · PRIVATE</div><h4>🎧 Listen to your own music</h4><p class="club-music-note">Search a service and listen privately in its app or website. Personal playback does not change this venue’s shared DJ queue.</p><label for="personalMusicSearch">Song, artist or playlist</label><input id="personalMusicSearch" class="control" maxlength="160" placeholder="e.g. Kweku Smoke or gospel worship"/><div class="personal-music-buttons"><button class="action-btn" type="button" data-personal-music="youtube">YouTube</button><button class="action-btn" type="button" data-personal-music="spotify">Spotify</button><button class="action-btn" type="button" data-personal-music="apple">Apple Music</button></div></div><p class="club-music-note">Song requests are metadata-only. Listening opens the music service in a new tab. DJ queue controls are restricted to the owner console.</p></section>`;
  }
  function renderClubSongPlayer(row){
    const title=document.getElementById('clubNowTitle'),artist=document.getElementById('clubNowArtist'),box=document.getElementById('clubSongPlayer');if(!title||!artist||!box)return;
    if(!row){clubMusicVideoId=null;clubMusicRequestId=null;title.textContent='Waiting for the DJ…';artist.textContent='No song is playing yet.';box.innerHTML='<div class="club-player-placeholder">🎶 No song is playing yet.</div>';return;}
    title.textContent=row.song_title||'Untitled song';artist.textContent=`${row.artist_name||'Unknown artist'} · requested by ${row.requester_name||'a player'}`;
    if(clubMusicRequestId===row.id)return;clubMusicRequestId=row.id;clubMusicVideoId=null;
    const query=encodeURIComponent(`${row.song_title||''} ${row.artist_name||''}`.trim());const approved=/^[A-Za-z0-9_-]{11}$/.test(String(row.youtube_video_id||''));const href=approved?`https://www.youtube.com/watch?v=${encodeURIComponent(row.youtube_video_id)}`:`https://www.youtube.com/results?search_query=${query}`;const label=approved?'Open approved song in YouTube ↗':'Search song on YouTube ↗';
    box.innerHTML=approved?`<div class="club-video-card club-approved-video"><iframe title="${esc(row.song_title||'Approved song')} by ${esc(row.artist_name||'artist')}" src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(row.youtube_video_id)}?playsinline=1&enablejsapi=1&controls=1&rel=0" allow="accelerometer; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe><div class="club-audio-help">🔊 Tap the player, then tap play/sound on your iPhone. Playback starts only after you interact.</div><a class="club-open-youtube" href="${href}" target="_blank" rel="noopener noreferrer">Open official song ↗</a></div>`:`<div class="club-video-card"><div class="club-video-meta"><b>🎵 ${esc(row.song_title||'Requested song')}</b><span>Waiting for venue admin approval. User-submitted links are never embedded.</span></div><div class="club-video-footer">The DJ will attach an official upload after review.</div><a class="club-open-youtube" href="${href}" target="_blank" rel="noopener noreferrer">${label}</a></div>`;
  }
  async function refreshClubSongRoom(){
    if(!MUSIC_ENABLED_PLACES.has(venueActivePlaceId)||!user)return;
    const list=document.getElementById('clubSongQueue');if(!list)return;
    const result=await sb.from('club_song_requests').select('id,requester_id,requester_name,song_title,artist_name,youtube_video_id,status,created_at,accepted_at').eq('venue_id',venueQueueId(venueActivePlaceId)).order('created_at',{ascending:false}).limit(30);
    if(result.error){list.innerHTML=`<div class="club-player-placeholder">The shared song queue needs the V25 Supabase setup. ${esc(result.error.message||'Queue unavailable.')}</div>`;return;}
    const rows=result.data||[];const playing=rows.filter(r=>r.status==='playing').sort((a,b)=>new Date(b.accepted_at||b.created_at)-new Date(a.accepted_at||a.created_at))[0]||null;
    renderClubSongPlayer(playing);
    const pending=rows.filter(r=>r.status==='pending');
    list.innerHTML=pending.length?pending.map((r,i)=>`<article class="club-queue-row"><div class="club-queue-number">${i+1}</div><div class="club-queue-copy"><b>${esc(r.song_title)}</b><span>${esc(r.artist_name)} · requested by ${esc(r.requester_name||'Player')}</span><small>${new Date(r.created_at).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</small></div><span class="pill">In queue</span></article>`).join(''):'<div class="club-player-placeholder">No pending requests. Be the first to request a song.</div>';
  }
  function startClubMusicPolling(){clearInterval(clubMusicPoll);clubMusicPoll=setInterval(()=>{if(MUSIC_ENABLED_PLACES.has(venueActivePlaceId))refreshClubSongRoom();},3500);refreshClubSongRoom();}
  function stopClubMusicPolling(){clearInterval(clubMusicPoll);clubMusicPoll=null;clubMusicVideoId=null;clubMusicRequestId=null;clubAudioEnabled=false;}
  async function renderVenue(placeId){
    const p=ACCRA_PLACES.find(x=>x.id===placeId)||ACCRA_PLACES.find(x=>`${x.name}, Accra`===(localStorage.getItem('accraLifeLocation')||''));
    if(!p){await openTab('map');return;}
    await leaveVenuePresence();
    venueActivePlaceId=p.id;
    const activityButtons=p.activities.map((a,i)=>{const d=activityDetails(p,i);return `<button type="button" class="venue-activity" data-place-activity="${i}" data-place-id="${p.id}"><span class="venue-activity-icon">${d.icon}</span><span>${esc(a)}<small>Start activity · +${d.xp} XP</small></span><span class="venue-activity-arrow">↗</span></button>`;}).join('');
    const venueHeader=p.id==='nightclub'?`<div class="enzo-premium-header"><div><div class="section-label">OSU, ACCRA · NIGHTLIFE</div><h2>📍 Enzo Lounge, Osu</h2><p>Ghanaian Afrobeats Night · Stylish dress code · Welcome in 🇬🇭</p></div><div class="enzo-header-actions"><button class="action-btn" data-share-venue="enzo" aria-label="Share Enzo Lounge">↗</button><button class="action-btn" data-favourite-venue="enzo" aria-label="Save Enzo Lounge">♡</button></div></div>`:header(`${p.kind.toUpperCase()} · YOU ARE HERE`,`${p.icon} ${p.name}`,`You have arrived in ${p.area}. Hang out here and meet other players who come to this same place. No invitation needed.`,`<button class="action-btn" data-tab="map">← Back to map</button>`);
    const venueVisual=p.id==='nightclub'?`<section class="enzo-nightclub-scene"><img src="${p.image}" alt="Enzo Lounge nightclub atmosphere" onerror="this.style.display='none'"><div class="enzo-scene-overlay"><span class="enzo-crowd-pill">🔥 Accra nightlife · Vibes are up</span><div><span>OSU · ACCRA</span><h3>ENZO LOUNGE</h3><p>Afrobeats · Highlife · Good people</p></div></div></section>`:`<section class="venue-scene venue-live-scene"><img src="${p.image}" alt="Illustrative background at ${esc(p.name)}" onerror="this.style.display='none'"><div class="venue-scene-shade"></div>${liveWorldMarkup(p.id,[])}<div class="venue-scene-caption"><span class="venue-live-pill">📍 YOU ARE HERE · LIVE VENUE</span><h3>${esc(p.name)}</h3><p>${esc(p.description)}</p></div></section>`;
    panel(`${venueHeader}${venueVisual}${worldControlsMarkup(p.id)}${MUSIC_ENABLED_PLACES.has(p.id)?clubMusicMarkup(p.id):''}<section class="venue-activities"><div><div class="section-label">MAKE YOUR MOVE</div><h3>What do you want to do?</h3><p class="sub">Choose an activity while you hang out here. Other players at this venue can meet you too.</p></div><div class="venue-activity-grid">${activityButtons}</div><div id="activityStage" aria-live="polite"></div></section><section class="venue-crowd"><div class="venue-crowd-head"><div><div class="section-label">THE CROWD</div><h3>People at this place</h3><p class="sub">Recent visitors to this venue.</p></div><span class="venue-count" id="venueCount">Finding the crowd…</span></div><div class="venue-people-list" id="venuePeopleList"><div class="venue-empty"><div>👀</div><b>Looking around…</b><p>Checking who is here now.</p></div></div></section><p class="map-disclaimer">This is an in-game social space. The game does not use real-world location tracking.</p>`);
    // Realtime Presence lets players who are in the same venue discover one another without sending invitations.
    try{
      const channel=sb.channel(`public-venue:${p.id}`,{config:{presence:{key:user.id}}})
        .on('presence',{event:'sync'},()=>{refreshVenueCrowd(p.id);})
        .on('presence',{event:'join'},()=>{refreshVenueCrowd(p.id);})
        .on('presence',{event:'leave'},()=>{refreshVenueCrowd(p.id);});
      venueChannel=channel;
      channel.subscribe(async status=>{
          if(status==='SUBSCRIBED'&&venueChannel===channel&&venueActivePlaceId===p.id){
            const tracked=await channel.track({player_id:user.id,display_name:profile?.display_name||'Player',username:profile?.username||'player',level:profile?.level||1,x:worldPosition.x,y:worldPosition.y,action:worldPosition.action,seated:worldPosition.seated,joined_at:new Date().toISOString()});
            if(tracked?.error)console.warn('Could not join live venue presence:',tracked.error);
            await refreshVenueCrowd(p.id);
          }
        });
    }catch(err){console.warn('Live venue presence unavailable; recent visitors will still be shown:',err);}
    await refreshVenueCrowd(p.id);
    if(MUSIC_ENABLED_PLACES.has(p.id))startClubMusicPolling();else stopClubMusicPolling();
  }
  async function renderWork(){
    if(workCountdownTimer){clearInterval(workCountdownTimer);workCountdownTimer=null;}
    const [jobs,chosen]=await Promise.all([sb.from('jobs').select('*').order('salary',{ascending:false}),sb.from('player_jobs').select('job_id,hired_at,last_salary_at,jobs(name,salary,last_salary_at)').eq('player_id',user.id).maybeSingle()]);
    if(jobs.error)throw jobs.error;
    const current=chosen.data?.jobs, employment=chosen.data;
    const cooldownMs=6*60*1000;
    const getRemaining=()=>{if(!employment)return cooldownMs;const anchor=employment.last_salary_at||employment.hired_at;return Math.max(0,cooldownMs-(Date.now()-new Date(anchor||Date.now()).getTime()));};
    const fmt=ms=>{const secs=Math.ceil(ms/1000);return `${String(Math.floor(secs/60)).padStart(2,'0')}:${String(secs%60).padStart(2,'0')}`;};
    panel(`${header('CAREER & INCOME','Work in Accra','Complete a six-minute work shift before claiming your virtual salary.',`<button class="action-btn" id="claimSalaryButton" data-action="salary" ${!employment||getRemaining()>0?'disabled':''}>${employment&&getRemaining()===0?'Claim salary':`Work shift · ${fmt(getRemaining())}`}</button>`)}${current?`<div class="stat-card" style="margin-bottom:14px"><span class="label">YOUR CURRENT JOB</span><strong>${esc(current.name)}</strong><p class="sub">GH₵ ${money(current.salary)} virtual salary per completed shift</p><p class="sub">Next shift available in <strong id="workShiftCountdown">${fmt(getRemaining())}</strong>. Keep this tab open or return later; the server checks the actual time.</p></div>`:'<div class="stat-card" style="margin-bottom:14px"><strong>Choose your first job</strong><p class="sub">Your six-minute work timer starts after you are hired.</p></div>'}<div class="grid">${(jobs.data||[]).filter(j=>!j.life_path||j.life_path==='all'||j.life_path===(profile?.life_path||'semi-rich')).map(j=>`<article class="item-card"><span class="pill">${esc(j.category||'Career')}</span><h3>${esc(j.name)}</h3><p>${esc(j.description||'Work hard and grow your career in Accra.')}</p><div class="price">GH₵ ${money(j.salary)} <small style="color:var(--muted);font-size:10px">/ completed shift</small></div><button data-hire="${j.id}" ${employment?.job_id===j.id?'disabled':''}>${employment?.job_id===j.id?'Current job':'Choose this job'}</button></article>`).join('')||empty('No jobs are available yet.')}</div>`);
    if(employment){workCountdownTimer=setInterval(()=>{const left=getRemaining(),button=$('claimSalaryButton'),label=$('workShiftCountdown');if(button){button.disabled=left>0;button.textContent=left>0?`Work shift · ${fmt(left)}`:'Claim salary';}if(label)label.textContent=fmt(left);if(left<=0&&workCountdownTimer){clearInterval(workCountdownTimer);workCountdownTimer=null;}},1000);}
  }
  async function renderTravel(){
    const [destinations,bookings]=await Promise.all([sb.from('travel_destinations').select('*').order('base_fare'),sb.from('travel_bookings').select('id,travel_class,fare,status,booked_at,travel_destinations(name,country,city)').eq('player_id',user.id).order('booked_at',{ascending:false}).limit(6)]);
    if(destinations.error)throw destinations.error;
    const classes=['Economy','Premium Economy','Business','First Class'];
    panel(`${header('GET OUT THERE','Explore beyond Accra','Pick a destination and travel class. Fares are paid from your in-game wallet.')}<div class="field-inline"><label for="travelClass" class="sub">Travel class</label><select id="travelClass">${classes.map(c=>`<option>${c}</option>`).join('')}</select></div><div class="grid">${(destinations.data||[]).map(d=>`<article class="item-card"><span class="pill">${esc(d.region||'International')}</span><h3>✈ ${esc(d.city||d.name)}</h3><p>${esc(d.country||'Destination')} ${d.airport_code?`· ${esc(d.airport_code)}`:''}<br>${Number(d.distance_km||0).toLocaleString()} km from home</p><div class="price">From GH₵ ${money(d.base_fare)}</div><button data-dest="${d.id}">Book this trip</button></article>`).join('')||empty('Destinations are being prepared.')}</div><h3 style="margin:24px 0 8px;font-size:15px">Your recent trips</h3><div class="tx-list">${(bookings.data||[]).map(b=>`<div class="tx"><div><b>${esc(b.travel_destinations?.city||b.travel_destinations?.name||'Trip')}</b><small>${esc(b.travel_class)} · ${esc(b.status)} · ${b.booked_at?new Date(b.booked_at).toLocaleDateString():''}</small></div><strong class="negative">−GH₵ ${money(b.fare)}</strong></div>`).join('')||empty('Your booked trips will appear here.')}</div>`);
  }
  function propertyPhoto(x){
    const n=String(x.name||'').toLowerCase();
    if(n.includes('plot')||n.includes('land'))return 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=900&q=82';
    if(n.includes('villa')||n.includes('cantonment')||n.includes('residence')||n.includes('luxury'))return 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=900&q=82';
    if(n.includes('east legon')||n.includes('mountain view')||n.includes('sakumono'))return 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=900&q=82';
    if(n.includes('starter')||n.includes('studio')||n.includes('madina'))return 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=82';
    return 'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=900&q=82';
  }
  function vehiclePhoto(x){const n=String((x.name||'')+' '+(x.category||'')).toLowerCase();return n.includes('trailer')?'https://images.unsplash.com/photo-1519003722824-194d4455a60c?auto=format&fit=crop&w=900&q=82':'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=900&q=82';}
  async function renderAssets(){
    const [properties,cars,ownedP,ownedC,furniture,ownedFurniture,visits,players]=await Promise.all([
      sb.from('properties').select('*').order('price'),
      sb.from('cars').select('*').order('price'),
      sb.from('player_properties').select('property_id,properties(name,location,property_type)').eq('player_id',user.id),
      sb.from('player_cars').select('car_id').eq('player_id',user.id),
      sb.from('furniture_items').select('*').order('price'),
      sb.from('player_furniture').select('id,item_id,quantity,pos_x,pos_y,furniture_items(name,category,icon)').eq('player_id',user.id),
      sb.from('apartment_visits').select('*').or(`owner_id.eq.${user.id},guest_id.eq.${user.id}`).order('created_at',{ascending:false}).limit(30),
      sb.from('players').select('id,display_name,username').neq('id',user.id).order('display_name').limit(100)
    ]);
    if(properties.error)throw properties.error;if(cars.error)throw cars.error;
    const pids=new Set((ownedP.data||[]).map(x=>x.property_id)),cids=new Set((ownedC.data||[]).map(x=>x.car_id));
    const props=ownedP.data||[], guests=players.data||[], visitRows=visits.data||[];
    const hostIds=[...new Set(visitRows.map(v=>v.owner_id).filter(id=>id!==user.id))];
    const guestIds=[...new Set(visitRows.map(v=>v.guest_id).filter(id=>id!==user.id))];
    const allIds=[...new Set([...hostIds,...guestIds])];
    let nameMap={};
    if(allIds.length){const names=await sb.from('players').select('id,display_name,username').in('id',allIds);(names.data||[]).forEach(p=>nameMap[p.id]=p.display_name||p.username||'Player');}
    const propIds=[...new Set(visitRows.map(v=>v.property_id))];let propMap={};
    if(propIds.length){const names=await sb.from('properties').select('id,name,location').in('id',propIds);(names.data||[]).forEach(p=>propMap[p.id]=p);}
    const ownedRoom=props[0];
    const roomFurniture=(ownedFurniture.data||[]).map((f,i)=>`<button type="button" class="room-piece" data-drag-furniture="${f.id}" style="left:${Number(f.pos_x??(12+(i%5)*17))}%;bottom:${Number(f.pos_y??12)}%" title="Drag to arrange: ${esc(f.furniture_items?.name||'Furniture')}" aria-label="Move ${esc(f.furniture_items?.name||'Furniture')}">${esc(f.furniture_items?.icon||'🪑')}</button>`).join('');
    const incoming=visitRows.filter(v=>v.guest_id===user.id&&v.status==='pending');
    const outgoing=visitRows.filter(v=>v.owner_id===user.id&&v.status==='pending');
    const accepted=visitRows.filter(v=>(v.owner_id===user.id||v.guest_id===user.id)&&v.status==='accepted');
    const apartmentHtml=`<section class="apartment-section"><div class="section-label">YOUR PRIVATE SPACE</div><h3 style="font-size:18px;margin:0 0 7px">🏡 Apartment life</h3><p class="sub" style="margin-bottom:14px">Buy a home, furnish your room, then invite friends over. Invitations appear in their notifications.</p>
      ${ownedRoom?`<div class="apartment-room"><div class="room-window"><span></span><span></span><span></span></div><div class="room-wall-art">ACCRA<br><small>HOME</small></div><div class="room-floor"></div><div class="room-sofa">🛋️</div><div class="room-plant">🪴</div>${roomFurniture}<div class="room-label"><b>${esc(ownedRoom.properties?.name||'Your apartment')}</b><small>${esc(ownedRoom.properties?.location||'Accra')} · Your home</small></div></div>
      <div class="two-col" style="margin-top:12px"><div class="stat-card"><span class="label">INVITE SOMEONE OVER</span><div class="field"><label for="guestSelect-${ownedRoom.property_id}">Choose a player</label><select id="guestSelect-${ownedRoom.property_id}" class="control"><option value="">${guests.length?'Choose a friend':'No friends yet — add friends from Enzo Lounge first'}</option>${guests.map(g=>`<option value="${g.id}">${esc(g.display_name||g.username||'Player')}</option>`).join('')}</select></div><button class="action-btn" data-invite-property="${ownedRoom.property_id}">Send apartment invitation</button></div><div class="stat-card"><span class="label">MAKE IT YOURS</span><p class="sub" style="margin:10px 0">Furniture owned: ${(ownedFurniture.data||[]).reduce((n,f)=>n+Number(f.quantity||1),0)}. Add pieces to make your apartment feel like home.</p><div class="room-inventory">${(ownedFurniture.data||[]).map(f=>`<div class="owned-furniture-row"><span>${esc(f.furniture_items?.icon||'🪑')} ${esc(f.furniture_items?.name||'Furniture')} ×${f.quantity||1}</span><button class="mini-action" data-sell-furniture="${f.id}">Sell · 60%</button></div>`).join('')||'<span class="sub">Your room is waiting for its first furniture.</span>'}</div><p class="sub" style="margin-top:8px">Move furniture by dragging it around the room. Your arrangement saves automatically.</p></div></div>
      <h4 style="font-size:14px;margin:22px 0 10px">Furniture shop</h4><div class="grid">${(furniture.data||[]).map(f=>`<article class="item-card"><div class="feature-icon">${esc(f.icon||'🪑')}</div><h3>${esc(f.name)}</h3><p>${esc(f.category||'Home decor')}</p><div class="price">GH₵ ${money(f.price)}</div><button data-buy-furniture="${f.id}">Buy & add to room</button></article>`).join('')||empty('More furniture is coming soon.')}</div>`:`<div class="empty">You need to own an apartment before you can furnish it or invite guests.</div><p class="sub">Purchase a property above to unlock your private apartment.</p>`}
      <h4 style="font-size:14px;margin:22px 0 10px">Apartment invitations</h4>
      ${incoming.map(v=>`<div class="tx"><div><b>🏡 ${esc(nameMap[v.owner_id]||'A player')} invited you over</b><small>${esc(propMap[v.property_id]?.name||'Apartment')} · ${new Date(v.created_at).toLocaleString()}</small></div><div class="invite-actions"><button class="action-btn" data-visit-response="accepted" data-visit-id="${v.id}">Accept</button><button class="action-btn" data-visit-response="declined" data-visit-id="${v.id}">Decline</button></div></div>`).join('')||'<p class="sub">No incoming apartment invitations.</p>'}
      ${outgoing.map(v=>`<div class="tx"><div><b>Invitation sent to ${esc(nameMap[v.guest_id]||'Player')}</b><small>${esc(propMap[v.property_id]?.name||'Apartment')} · Waiting for a response</small></div><span class="pill">Pending</span></div>`).join('')}
      ${accepted.map(v=>{const other=v.owner_id===user.id?nameMap[v.guest_id]:nameMap[v.owner_id];return `<div class="tx"><div><b>🏠 ${v.owner_id===user.id?'Your guest: ':'You can visit: '}${esc(other||'Player')}</b><small>${esc(propMap[v.property_id]?.name||'Apartment')} · Invitation accepted</small></div><button class="action-btn" data-open-apartment="${v.id}">Visit apartment</button></div>`}).join('')}
      </section>`;
    panel(`${header('ACCRA PROPERTY COLLECTION','Build Your Dream Life','Premium homes & cars · Accra, Ghana · Own your next chapter.',`<div class="asset-wallet-pill">₵ <span>Wallet</span><b>GH₵ ${money((await sb.from('wallets').select('balance').eq('player_id',user.id).maybeSingle()).data?.balance)}</b></div>`)}
      <div class="asset-section-heading"><div><h3>Homes</h3><p>Find a place to call your own.</p></div><span>GHANA COLLECTION</span></div>
      <div class="premium-property-grid">${(properties.data||[]).map(x=>`<article class="premium-property-card"><div class="premium-property-photo"><img loading="lazy" src="${propertyPhoto(x)}" alt="${esc(x.name)}" onerror="this.onerror=null;this.src='https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=900&q=82'"><span class="property-type-tag">${esc(x.property_type||'Home')}</span></div><div class="premium-property-body"><h4>${esc(x.name)}</h4><div class="property-location">📍 ${esc(x.location||'Accra, Ghana')}</div><div class="property-card-bottom"><b>GH₵ ${money(x.price)}</b>${pids.has(x.id)?`<button class="owned-home-button" type="button" disabled aria-pressed="true">Owned ✓</button><button class="action-btn" data-sell-property="${x.id}">Sell · 70%</button>`:`<button class="premium-buy-button" data-buy-property="${x.id}">Buy home</button>`}</div></div></article>`).join('')||empty('Homes are being prepared.')}</div>
      <div class="asset-section-heading vehicles-heading"><div><h3>Vehicles</h3><p>Choose your next way around Accra.</p></div><span>ACCRA MOTORS</span></div>
      <div class="premium-vehicle-list">${(cars.data||[]).map(x=>`<article class="premium-vehicle-card"><img loading="lazy" src="${vehiclePhoto(x)}" alt="${esc(x.brand||'Accra Motors')} ${esc(x.name)}" onerror="this.style.display='none'"><div class="premium-vehicle-body"><span class="vehicle-availability">● AVAILABLE IN-GAME</span><h4>${esc(x.brand||'Accra Motors')} ${esc(x.name)}</h4><p>📍 Accra Motors · Ghana</p><b>GH₵ ${money(x.price)}</b></div><div class="premium-vehicle-action">${cids.has(x.id)?`<button class="action-btn" data-sell-vehicle="${x.id}">Sell · 70%</button>`:`<button class="premium-buy-button" data-buy-car="${x.id}">View / Buy</button>`}</div></article>`).join('')||empty('Vehicles are coming soon.')}</div>${apartmentHtml}`);
  }
  async function openChatWith(recipientId, fallbackName='Player'){
    if(!recipientId||recipientId===user.id){toast('Choose another Accra Life user to chat with.');return;}
    const personResult=await sb.from('players').select('id,display_name,username,level,experience').eq('id',recipientId).maybeSingle();
    if(personResult.error||!personResult.data){toast('That profile could not be found.');return;}
    const person=personResult.data, name=person.display_name||person.username||fallbackName;
    const overlay=document.querySelector('.accra-chat-overlay');if(overlay)overlay.remove();
    const modal=document.createElement('div');modal.className='hire-modal-overlay accra-chat-overlay';
    modal.innerHTML=`<div class="hire-modal" style="width:min(620px,96vw);max-height:88vh;overflow:auto"><div class="section-label">PRIVATE MESSAGE</div><h2 style="margin:6px 0">${esc(name)}</h2><p class="sub">@${esc(person.username||'player')} · Your conversation on Accra Life</p><div style="display:flex;gap:8px;flex-wrap:wrap;margin:12px 0"><button class="action-btn" data-view-profile="${person.id}">View profile</button><button class="action-btn" data-chat-close>Close chat</button></div><div id="accraChatMessages" class="tx-list" style="max-height:42vh;overflow:auto"><div class="loading">Loading conversation…</div></div><form id="accraChatForm" style="margin-top:14px"><label for="accraChatInput" class="label">Write a message</label><textarea id="accraChatInput" class="control" rows="3" maxlength="1000" placeholder="Write a message to ${esc(name)}…" required></textarea><button class="primary full" type="submit" style="margin-top:8px">Send message</button></form><p class="sub" style="margin-top:10px">Player-to-player money transfers are disabled. You can report or block a player from their profile.</p></div>`;
    document.body.appendChild(modal);modal.addEventListener('click',ev=>{if(ev.target===modal)modal.remove();});
    async function loadConversation(){
      const box=modal.querySelector('#accraChatMessages');
      const q=await sb.from('messages').select('id,sender_id,recipient_id,body,created_at,read_at').or(`and(sender_id.eq.${user.id},recipient_id.eq.${recipientId}),and(sender_id.eq.${recipientId},recipient_id.eq.${user.id})`).order('created_at',{ascending:true}).limit(100);
      if(q.error){box.innerHTML=`<div class="empty">Could not load messages: ${esc(errorText(q.error))}</div>`;return;}
      box.innerHTML=(q.data||[]).map(m=>`<div class="tx" style="margin:7px 0"><div><b>${m.sender_id===user.id?'You':esc(name)}</b><small>${esc(m.body)}<br>${m.created_at?new Date(m.created_at).toLocaleString():''}</small></div><span class="pill">${m.sender_id===user.id?'Sent':(m.read_at?'Read':'Received')}</span></div>`).join('')||'<div class="empty">No messages yet. Say hello to start the conversation.</div>';
      box.scrollTop=box.scrollHeight;
      const unread=(q.data||[]).filter(m=>m.recipient_id===user.id&&!m.read_at).map(m=>m.id);
      if(unread.length)await sb.from('messages').update({read_at:new Date().toISOString()}).in('id',unread).eq('recipient_id',user.id);
    }
    modal.querySelector('#accraChatForm').addEventListener('submit',async ev=>{ev.preventDefault();const input=modal.querySelector('#accraChatInput'),body=input.value.trim();if(!body)return;const send=await sb.from('messages').insert({sender_id:user.id,recipient_id:recipientId,body:body.slice(0,1000)});if(send.error){toast(errorText(send.error));return;}input.value='';await loadConversation();toast('Message sent.');});
    await loadConversation();
  }
  async function showPublicProfile(playerId){
    const blocked=await sb.from('blocks').select('blocked_id').eq('blocker_id',user.id).eq('blocked_id',playerId).maybeSingle();if(blocked.data){toast('You have blocked this player.');return;}
    const r=await sb.from('players').select('id,display_name,username,level,experience').eq('id',playerId).maybeSingle();
    if(r.error||!r.data){toast('Could not load that profile.');return;}
    const p=r.data, name=p.display_name||p.username||'Accra Life user';
    document.querySelector('.accra-profile-overlay')?.remove();
    const modal=document.createElement('div');modal.className='hire-modal-overlay accra-profile-overlay';
    const shareUrl=`${location.origin}${location.pathname}?find=${encodeURIComponent(p.username||'')}`;
    modal.innerHTML=`<div class="hire-modal" style="width:min(500px,96vw)"><div class="section-label">ACCRA LIFE PROFILE</div><div class="feature-icon" style="margin:14px auto">👤</div><h2 style="text-align:center;margin:4px 0">${esc(name)}</h2><p style="text-align:center;font-size:16px">@${esc(p.username||'player')}</p><p style="text-align:center" class="sub">Level ${p.level||1} · ${p.experience||0} XP</p><div style="display:grid;gap:9px;margin-top:18px">${p.id!==user.id?`<button class="primary full" data-profile-message="${p.id}" data-person-name="${esc(name)}">💬 Message</button><button class="action-btn" data-block-user="${p.id}" data-person-name="${esc(name)}">🚫 Block user</button><button class="action-btn" data-report-user="${p.id}" data-person-name="${esc(name)}">⚑ Report user</button>`:''}<button class="action-btn" data-share-profile="${esc(p.username||'')}" data-share-url="${esc(shareUrl)}">🔗 Share profile</button><button class="action-btn" data-profile-close>Close profile</button></div><p class="sub" style="margin-top:12px">Keep your interactions respectful. You can block or report another player.</p></div>`;
    document.body.appendChild(modal);modal.addEventListener('click',ev=>{if(ev.target===modal)modal.remove();});
  }
  async function sendGameMoneyTo(recipientId, recipientName='this player'){toast('Player-to-player transfers are disabled for launch. Virtual money cannot be sent to another player.');return;}
  async function renderSocial(){
    const [players,friends]=await Promise.all([sb.from('players').select('id,display_name,username,level,experience').neq('id',user.id).order('level',{ascending:false}).limit(30),sb.from('friendships').select('id,requester_id,addressee_id,status,requester:players!friendships_requester_id_fkey(display_name,username),addressee:players!friendships_addressee_id_fkey(display_name,username)').or(`requester_id.eq.${user.id},addressee_id.eq.${user.id}`).order('created_at',{ascending:false}).limit(30)]);
    const rels=friends.data||[];const acceptedFriendIds=new Set(rels.filter(f=>f.status==='accepted').map(f=>f.requester_id===user.id?f.addressee_id:f.requester_id));const blockRows=await sb.from('blocks').select('blocked_id').eq('blocker_id',user.id);const blockedIds=new Set((blockRows.data||[]).map(b=>b.blocked_id));const related=new Set(rels.map(f=>f.requester_id===user.id?f.addressee_id:f.requester_id));
    const recentMessages=await sb.from('messages').select('id,sender_id,recipient_id,body,created_at,read_at').or(`sender_id.eq.${user.id},recipient_id.eq.${user.id}`).order('created_at',{ascending:false}).limit(12);
    const rawPlayers=(players.data||[]).filter(p=>!blockedIds.has(p.id));const seenPlayerIds=new Set(),seenPlayerNames=new Set();const messagePlayers=rawPlayers.filter(p=>{const id=String(p.id||'');const uname=String(p.username||'').trim().toLowerCase();if(!id||seenPlayerIds.has(id)||(uname&&seenPlayerNames.has(uname)))return false;seenPlayerIds.add(id);if(uname)seenPlayerNames.add(uname);return true;});const friendPlayers=messagePlayers.filter(p=>acceptedFriendIds.has(p.id));
    panel(`${header('PEOPLE & COMMUNITY','Your social circle','Find someone by username, open their profile, and chat privately.')}<section class="stat-card" style="margin-bottom:16px"><div class="section-label">YOUR SHAREABLE PROFILE</div><h3 style="margin:6px 0">${esc(profile?.display_name||'Your profile')}</h3><p class="sub">Username: <b>@${esc(profile?.username||'player')}</b></p><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="action-btn" data-share-profile="${esc(profile?.username||'')}" data-share-url="${esc(`${location.origin}${location.pathname}?find=${encodeURIComponent(profile?.username||'')}`)}">🔗 Share my profile</button><button class="action-btn" data-view-profile="${user.id}">View my profile</button></div></section><section class="stat-card" style="margin-bottom:16px"><div class="section-label">FIND PEOPLE</div><label for="usernameSearch" class="label">Search by exact username</label><div class="field-inline"><input id="usernameSearch" class="control" maxlength="32" placeholder="Enter username, e.g. jamila" value="${esc(new URLSearchParams(location.search).get('find')||'')}"><button class="action-btn" data-search-username>Search</button></div><div id="usernameSearchResults" style="margin-top:12px"></div></section><div class="stat-card message-compose"><span class="label">SEND A MESSAGE</span><div class="field"><label for="messageRecipient">Choose a player</label><select id="messageRecipient" class="control"><option value="">${friendPlayers.length?'Choose a friend':'No friends yet — add friends from Enzo Lounge first'}</option>${friendPlayers.map(p=>`<option value="${p.id}">${esc(p.display_name||p.username||'Player')}</option>`).join('')}</select></div><div class="field"><label for="messageBody">Your message</label><textarea id="messageBody" class="control" maxlength="1000" rows="3" placeholder="Write a message…"></textarea></div><button class="action-btn" data-action="send-message">Send message</button></div><h3 style="font-size:15px;margin:24px 0 10px">Recent messages</h3><div class="tx-list">${(recentMessages.data||[]).map(m=>{const other=messagePlayers.find(p=>p.id===(m.sender_id===user.id?m.recipient_id:m.sender_id));return `<div class="tx"><div><b>${m.sender_id===user.id?'You → ':''}${esc(other?.display_name||other?.username||'Player')}</b><small>${esc(m.body)}<br>${m.created_at?new Date(m.created_at).toLocaleString():''}</small></div><div style="display:grid;gap:6px"><span class="pill">${m.sender_id===user.id?'Sent':(m.read_at?'Read':'Received')}</span>${other?`<button class="mini-action" data-open-chat="${other.id}" data-person-name="${esc(other.display_name||other.username||'Player')}">Open chat</button>`:''}</div></div>`}).join('')||empty('Your conversations will appear here.')}</div><h3 style="font-size:15px;margin:24px 0 10px">Discover players</h3><div class="grid">${messagePlayers.map(p=>{const rel=rels.find(f=>f.requester_id===p.id||f.addressee_id===p.id);let label='Add friend',disabled=false;if(rel){if(rel.status==='accepted'){label='Friends';disabled=true;}else if(rel.status==='pending'){label=rel.requester_id===user.id?'Request sent':'Respond in requests';disabled=true;}}return `<article class="item-card"><div class="feature-icon">👤</div><h3>${esc(p.display_name||p.username||'Player')}</h3><p>@${esc(p.username||'player')}<br>Level ${p.level||1} · ${p.experience||0} XP</p><button data-view-profile="${p.id}">View profile</button><button class="action-btn" data-profile-message="${p.id}" data-person-name="${esc(p.display_name||p.username||'Player')}">Message</button><button data-friend="${p.id}" ${disabled?'disabled':''}>${label}</button></article>`}).join('')||empty('You are one of the first players here. Invite a friend to join you!')}</div><h3 style="font-size:15px;margin:24px 0 10px">Friend requests & connections</h3><div class="tx-list">${rels.map(f=>{const incoming=f.addressee_id===user.id&&f.status==='pending';const name=f.requester_id===user.id?(f.addressee?.display_name||f.addressee?.username):(f.requester?.display_name||f.requester?.username);return `<div class="tx"><div><b>${esc(name||'Player')}</b><small>${esc(f.status)}${incoming?' · incoming request':''}</small></div>${incoming?`<button class="action-btn" data-accept-friend="${f.id}">Accept</button>`:''}</div>`}).join('')||empty('No friend requests yet.')}</div>`);
  }
  document.addEventListener('click',async e=>{
    const inProfile=e.target.closest('.accra-profile-overlay');
    const inChat=e.target.closest('.accra-chat-overlay');
    if(!inProfile&&!inChat)return;
    const closeProfile=e.target.closest('[data-profile-close]');if(closeProfile){document.querySelector('.accra-profile-overlay')?.remove();return;}
    const closeChat=e.target.closest('[data-chat-close]');if(closeChat){document.querySelector('.accra-chat-overlay')?.remove();return;}
    const view=e.target.closest('[data-view-profile]');if(view){await showPublicProfile(view.dataset.viewProfile);return;}
    const share=e.target.closest('[data-share-profile]');if(share){const uname=share.dataset.shareProfile||'player',url=share.dataset.shareUrl||`${location.origin}${location.pathname}?find=${encodeURIComponent(uname)}`,shareText=`Find me on Accra Life: @${uname}\n${url}`;try{if(navigator.share)await navigator.share({title:'My Accra Life profile',text:shareText,url});else if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(shareText);toast('Your username and profile link were copied.');}else window.prompt('Copy and share your Accra Life username and profile link:',shareText);}catch(err){if(err?.name!=='AbortError')window.prompt('Copy and share your Accra Life username and profile link:',shareText);}return;}
    const msg=e.target.closest('[data-profile-message]');if(msg){const id=msg.dataset.profileMessage,name=msg.dataset.personName||'Player';document.querySelector('.accra-profile-overlay')?.remove();await openChatWith(id,name);return;}
    const blockUser=e.target.closest('[data-block-user]');if(blockUser){const blockedId=blockUser.dataset.blockUser;if(!blockedId||blockedId===user.id)return;if(!confirm(`Block ${blockUser.dataset.personName||'this player'}?`))return;const r=await sb.from('blocks').upsert({blocker_id:user.id,blocked_id:blockedId},{onConflict:'blocker_id,blocked_id'});if(r.error){toast(`Could not block player: ${errorText(r.error)}`);return;}toast('Player blocked.');document.querySelector('.accra-profile-overlay')?.remove();return;}
    const reportUser=e.target.closest('[data-report-user]');if(reportUser){const reportedId=reportUser.dataset.reportUser;const reason=window.prompt(`Why are you reporting ${reportUser.dataset.personName||'this player'}? Include what happened.`);if(!reason||reason.trim().length<3){toast('Enter a short reason to submit a report.');return;}const r=await sb.from('reports').insert({reporter_id:user.id,reported_id:reportedId,reason:reason.trim().slice(0,1000)});if(r.error){toast(`Could not submit report: ${errorText(r.error)}`);return;}toast('Report submitted for review.');document.querySelector('.accra-profile-overlay')?.remove();return;}
    const moneyButton=e.target.closest('[data-profile-money],[data-chat-money]');if(moneyButton){const id=moneyButton.dataset.profileMoney||moneyButton.dataset.chatMoney;await sendGameMoneyTo(id,moneyButton.dataset.personName||'this player');return;}
  });
  function testWalletKey(){return `accraLifeTestWallet:${user?.id||'guest'}`;}
  function readTestWallet(){try{const data=JSON.parse(localStorage.getItem(testWalletKey())||'{}');return {balance:Math.max(0,Number(data.balance)||0,0),transactions:Array.isArray(data.transactions)?data.transactions.slice(0,30):[]};}catch(_){return {balance:0,transactions:[]};}}
  function saveTestWallet(wallet){localStorage.setItem(testWalletKey(),JSON.stringify({balance:Math.max(0,Number(wallet.balance)||0),transactions:(wallet.transactions||[]).slice(0,30)}));}
  function testTxLine(t){const pending=t.kind==='withdrawal'&&t.status==='pending';return `<div class="tx"><div><b>${esc(t.title)}</b><small>${esc(t.statusLabel||t.status||'Recorded')} · ${new Date(t.createdAt).toLocaleString()}</small></div><div style="text-align:right"><strong class="${t.kind==='deposit'?'positive':'negative'}">${t.kind==='deposit'?'+':'−'}GH₵ ${money(t.amount)}</strong>${pending?`<br><button class="action-btn" style="margin-top:6px;padding:7px 9px;font-size:11px" data-test-complete="${esc(t.id)}">Simulate payout status</button>`:''}</div></div>`;}
  async function renderWallet(){
    const [wallet,tx]=await Promise.all([sb.from('wallets').select('balance').eq('player_id',user.id).maybeSingle(),sb.from('wallet_transactions').select('*').eq('player_id',user.id).order('created_at',{ascending:false}).limit(20)]);
    if(wallet.error)throw wallet.error;
    const players=await sb.from('players').select('id,display_name,username').neq('id',user.id).order('display_name').limit(100);
    const demo=readTestWallet();
    panel(`${header('YOUR MONEY','Game wallet','virtual money only, cannot send real money. Payment sandbox is for testing only.')}<div class="two-col"><div class="stat-card"><span class="label">AVAILABLE GAME BALANCE</span><strong>GH₵ ${money(wallet.data?.balance)}</strong><p class="sub" style="margin-top:8px">Earn in-game salary, manage spending and keep track of your moves.</p></div><div class="stat-card"><span class="label">PLAYER-TO-PLAYER TRANSFER</span><h3 style="margin:12px 0">Temporarily disabled</h3><p class="sub">Transfers are turned off for launch to prevent abuse of virtual funds. They will remain disabled until the GH₵200-per-day limit is implemented.</p></div></div><section class="stat-card" style="margin-top:18px;border:1px solid #d8ad65;background:linear-gradient(135deg,rgba(216,173,101,.12),rgba(255,255,255,.02))"><div class="section-label">DEVELOPER TEST MODE · VIRTUAL MONEY ONLY</div><h3 style="font-size:22px;margin:7px 0">Payment sandbox</h3><p class="sub">Use this screen to test wallet steps before connecting a payment provider. No Mobile Money, bank account, deposit, or withdrawal is contacted. Test balances are saved only in this browser on this device.</p><div class="two-col" style="margin-top:14px"><div><span class="label">TEST BALANCE</span><strong style="display:block;font-size:28px;margin:8px 0">GH₵ ${money(demo.balance)}</strong><div class="field"><label for="testWalletAmount">Test amount (GH₵)</label><input id="testWalletAmount" class="control" type="number" min="0.01" max="10000" step="0.01" placeholder="e.g. 10.00"></div><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="action-btn" data-action="test-wallet-add">Add test funds</button><button class="action-btn" data-action="test-wallet-withdraw">Request test withdrawal</button></div><button class="action-btn" data-action="test-wallet-reset" style="margin-top:10px;background:transparent;border:1px solid var(--line);color:var(--text)">Reset test wallet</button></div><div><span class="label">TEST TRANSACTION HISTORY</span><div class="tx-list" style="margin-top:8px">${demo.transactions.map(testTxLine).join('')||empty('Add virtual test funds to begin testing.')}</div></div></div><p class="sub" style="margin-top:14px;color:#b77924;font-weight:700">TEST ONLY — a simulated payout is not a real payment confirmation. Real-money features remain disabled until approved and connected.</p></section><h3 style="font-size:15px;margin:24px 0 8px">Game currency transactions</h3><div class="tx-list">${(tx.data||[]).map(t=>`<div class="tx"><div><b>${esc(t.description||t.transaction_type||'Transaction')}</b><small>${t.created_at?new Date(t.created_at).toLocaleString():''}</small></div><strong class="${Number(t.amount)>=0?'positive':'negative'}">${Number(t.amount)>=0?'+':'−'}GH₵ ${money(Math.abs(Number(t.amount)))}</strong></div>`).join('')||empty('Your game transactions will appear here.')}</div>`);
  }
  async function renderNotifications(){
    const r=await sb.from('notifications').select('*').eq('player_id',user.id).order('created_at',{ascending:false}).limit(50);
    if(r.error) throw r.error;
    const rows=r.data||[];
    const unread=rows.filter(n=>!n.read_at).map(n=>n.id);
    if(unread.length){const upd=await sb.from('notifications').update({read_at:new Date().toISOString()}).in('id',unread).eq('player_id',user.id);if(upd.error)console.warn(upd.error);}
    updateNotificationBadge(0);
    panel(`${header('YOUR ACTIVITY','Notifications','Messages, money transfers, friend requests and other important updates.')}<div class="tx-list">${rows.map(n=>`<div class="tx notification-row ${n.read_at?'':'unread'}"><div><b>${esc(n.title||'Accra Life update')}</b><small>${esc(n.body||'')}<br>${n.created_at?new Date(n.created_at).toLocaleString():''}</small></div><span class="pill">${esc(n.type||'update')}</span></div>`).join('')||empty('You’re all caught up. New messages and money transfers will appear here.')}</div>`);
  }
  function maskEmail(email){const value=String(email||'').trim();const at=value.indexOf('@');if(at<1)return value?'••••••':'Not available';const local=value.slice(0,at);const domain=value.slice(at+1);const dot=domain.lastIndexOf('.');const host=dot>0?domain.slice(0,dot):domain;const tld=dot>0?domain.slice(dot):'';const maskedHost=host.length>1?`${host[0]}${'•'.repeat(Math.min(6,Math.max(3,host.length-1)))}`:'••••';return `${local[0]}${'•'.repeat(Math.min(8,Math.max(4,local.length-1)))}@${maskedHost}${tld}`;}
  async function renderSettings(){
    const r=await sb.from('player_settings').select('notifications_enabled').eq('player_id',user.id).maybeSingle();
    if(r.error)throw r.error;
    const enabled=r.data?.notifications_enabled!==false;
    panel(`${header('YOUR ACCOUNT','Settings','Manage your profile, security and in-game notification preferences.')}<div class="two-col"><div class="stat-card"><span class="label">PROFILE</span><div class="field"><label for="settingsDisplayName">Display name</label><input id="settingsDisplayName" class="control" maxlength="80" value="${esc(profile?.display_name||'')}" /></div><button class="action-btn" data-action="save-display-name">Save display name</button><div class="field"><label>Email address</label><input class="control" value="${esc(maskEmail(user?.email||''))}" disabled /></div><div class="field"><label for="settingsEmail">Change email address</label><input id="settingsEmail" class="control" type="email" placeholder="New email address" /></div><button class="action-btn" data-action="change-email">Request email change</button><p class="sub" style="margin-top:8px">We will send you a confirmation email to confirm your new address.</p></div><div class="stat-card"><span class="label">SECURITY & NOTIFICATIONS</span><div class="field"><label for="settingsPassword">New password</label><input id="settingsPassword" class="control" type="password" minlength="6" placeholder="At least 6 characters" /></div><button class="action-btn" data-action="change-password">Update password</button><hr style="border:0;border-top:1px solid var(--line);margin:22px 0"><label class="settings-toggle"><input id="notificationsEnabled" type="checkbox" ${enabled?'checked':''}><span><b>In-game notifications</b><small>Receive alerts for messages, money received and friend requests.</small></span></label><button class="action-btn" data-action="save-settings" style="margin-top:16px">Save notification settings</button><hr style="border:0;border-top:1px solid var(--line);margin:22px 0"><button class="action-btn danger-btn" data-action="settings-logout">Log out of Accra Life</button></div></div>`);
  }
  function updateNotificationBadge(count){const el=$('notificationCount');if(!el)return;el.textContent=String(count);el.classList.toggle('has-count',count>0);}
  async function pollNotifications(showNew=false){
    if(!user)return;
    const settings=await sb.from('player_settings').select('notifications_enabled').eq('player_id',user.id).maybeSingle();
    if(settings.data?.notifications_enabled===false){updateNotificationBadge(0);return;}
    const r=await sb.from('notifications').select('id,title,body,type,created_at').eq('player_id',user.id).is('read_at',null).order('created_at',{ascending:false}).limit(20);
    if(r.error){console.warn(r.error);return;}
    const rows=r.data||[];updateNotificationBadge(rows.length);
    if(showNew&&rows.length){const newest=rows[0];if(lastNotificationId&&newest.id!==lastNotificationId){toast(`${newest.title||'New Accra Life notification'}${newest.body?' — '+newest.body:''}`);}lastNotificationId=newest.id;}
    else if(rows.length&&!lastNotificationId){lastNotificationId=rows[0].id;}
  }
  function startNotificationPolling(){if(notificationPoll)clearInterval(notificationPoll);lastNotificationId=null;pollNotifications(false);notificationPoll=setInterval(()=>pollNotifications(true),12000);}
  async function renderBusiness(){
    const [owned,investments]=await Promise.all([sb.from('businesses').select('*').eq('owner_id',user.id).order('created_at',{ascending:false}),sb.from('investments').select('*').eq('player_id',user.id).order('created_at',{ascending:false})]);
    panel(`${header('ENTREPRENEURSHIP','Build something of your own','Businesses and investments use game currency. Spend carefully; this is a simulation.')}<div class="two-col"><div class="stat-card"><span class="label">START A BUSINESS</span><div class="field"><label for="bizName">Business name</label><input id="bizName" class="control" maxlength="60" placeholder="e.g. Jamilatu’s Boutique"></div><div class="field-inline"><select id="bizCategory" class="control"><option>Fashion</option><option>Food & drink</option><option>Transport</option><option>Beauty</option><option>Technology</option><option>Retail</option><option>Entertainment</option></select><select id="bizLocation" class="control"><option>Osu</option><option>East Legon</option><option>Madina</option><option>Airport</option><option>Labadi</option><option>Accra Central</option></select></div><div class="field"><label for="bizPrice">Startup cost (GH₵)</label><input id="bizPrice" class="control" type="number" min="100" step="50" value="500"></div><button class="action-btn" data-action="create-business">Launch business</button></div><div class="stat-card"><span class="label">IN-GAME INVESTMENT</span><div class="field"><label for="assetName">Investment name</label><input id="assetName" class="control" maxlength="60" placeholder="e.g. Local food venture"></div><div class="field-inline"><input id="investAmount" class="control" type="number" min="10" step="10" placeholder="Principal GH₵"><input id="investRate" class="control" type="number" min="0" max="100" step="1" value="5" placeholder="Return %"></div><div class="field"><label for="investDays">Game holding period</label><select id="investDays" class="control"><option value="1">1 day</option><option value="7" selected>7 days</option><option value="30">30 days</option></select></div><button class="action-btn" data-action="create-investment">Make investment</button><p class="sub" style="margin-top:9px">Returns are game mechanics, not real-world financial advice.</p></div></div><h3 style="font-size:15px;margin:24px 0 10px">Your businesses</h3><div class="grid">${(owned.data||[]).map(b=>`<article class="item-card"><span class="pill">${esc(b.category)}</span><h3>${esc(b.name)}</h3><p>${esc(b.location||'Accra')}<br>Game revenue: GH₵ ${money(b.revenue)}</p><div class="price">Startup: GH₵ ${money(b.price)}</div></article>`).join('')||empty('Your first business could be listed here.')}</div><h3 style="font-size:15px;margin:24px 0 10px">Your investments</h3><div class="tx-list">${(investments.data||[]).map(i=>`<div class="tx"><div><b>${esc(i.asset_name)}</b><small>${esc(i.status)} · ${i.matured_at?`Matures ${new Date(i.matured_at).toLocaleDateString()}`:'Active'}</small></div><strong>GH₵ ${money(i.principal)}</strong></div>`).join('')||empty('No investments yet.')}</div>`);
  }
  async function doRpc(name,args,success,refresh=true){const r=await sb.rpc(name,args);if(r.error){toast(errorText(r.error));return false;}toast(success);if(refresh){await refreshWallet();await refreshProfile();await openTab(activeTab);}return true;}
  function showFlightExperience(destination,travelClass,booking){
    return new Promise(resolve=>{
      document.querySelector('.flight-overlay')?.remove();
      const city=destination.city||booking.destination||destination.name||'your destination';
      const country=destination.country||booking.country||'Destination';
      const fare=booking.fare;
      const overlay=document.createElement('div');
      overlay.className='hire-modal-overlay flight-overlay';
      overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-labelledby','flightTitle');
      overlay.innerHTML=`<div class="flight-modal">
        <div class="flight-topline"><span class="section-label">ACCRA LIFE AIR</span><span class="flight-class">${esc(travelClass)}</span></div>
        <h2 id="flightTitle">Accra <span>→</span> ${esc(city)}</h2>
        <p class="flight-subtitle" id="flightStatus" aria-live="polite">Your flight is preparing for takeoff…</p>
        <div class="flight-scene" id="flightScene"><div class="flight-sun"></div><div class="flight-cloud cloud-one">☁</div><div class="flight-cloud cloud-two">☁</div><div class="flight-cloud cloud-three">☁</div><div class="flight-route-line"></div><div class="flight-plane" role="img" aria-label="Passenger jet taxiing, taking off, cruising and landing"><svg viewBox="0 0 180 70" aria-hidden="true" focusable="false"><defs><linearGradient id="jetBody" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#b8c9d0"/></linearGradient><linearGradient id="jetWing" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#dce7eb"/><stop offset="1" stop-color="#758e9b"/></linearGradient></defs><path class="jet-wing-back" d="M70 31 L37 7 Q34 5 37 14 L52 36 Z" fill="#718894"/><path d="M27 31 L7 17 Q3 15 5 23 L16 39 Z" fill="#718894"/><path d="M68 38 L34 63 Q31 66 38 65 L91 43 Z" fill="url(#jetWing)" stroke="#8299a2" stroke-width="1"/><path d="M122 36 L158 50 Q162 52 159 45 L143 32 Z" fill="url(#jetWing)" stroke="#8299a2" stroke-width="1"/><path d="M8 34 Q12 30 22 30 L146 30 Q163 30 175 35 Q163 40 146 40 L22 40 Q12 40 8 36 Z" fill="url(#jetBody)" stroke="#7e959f" stroke-width="1.1"/><path d="M150 31 L174 35 L150 39 Z" fill="#e7eff2"/><path d="M18 31 L9 18 Q7 15 11 17 L35 30 Z" fill="#dce7eb" stroke="#8299a2" stroke-width="1"/><path d="M24 30 L30 10 Q31 7 34 10 L45 31 Z" fill="#f2f6f7" stroke="#8299a2" stroke-width="1"/><path d="M26 32 L36 32 L36 38 L26 38 Z" fill="#6d8793"/><path d="M42 33 L135 33" stroke="#d7a56c" stroke-width="2"/><g fill="#526e7b"><rect x="48" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="56" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="64" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="72" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="80" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="88" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="96" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="104" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="112" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="120" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="128" y="31.2" width="3.5" height="2.2" rx="1"/></g><path d="M18 36 L22 36" stroke="#fff" stroke-width="2"/><g class="jet-engines"><ellipse cx="66" cy="43" rx="8" ry="3.4" fill="#647e8a"/><ellipse cx="66" cy="43" rx="4.3" ry="2" fill="#233c49"/><ellipse cx="110" cy="27" rx="8" ry="3.4" fill="#647e8a"/><ellipse cx="110" cy="27" rx="4.3" ry="2" fill="#233c49"/></g><g class="jet-gear"><path d="M54 39 L53 48 M119 39 L120 47" stroke="#344c57" stroke-width="2"/><circle cx="53" cy="49" r="2.4" fill="#243b46"/><circle cx="120" cy="48" r="2.4" fill="#243b46"/></g><path d="M142 33 L150 35 L142 37" fill="#526f7b"/></svg></div><div class="flight-airport from-airport"><b>ACC</b><small>ACCRA</small></div><div class="flight-airport to-airport"><b>${esc((destination.airport_code||city.slice(0,3)).toUpperCase())}</b><small>${esc(city.toUpperCase())}</small></div><div class="flight-runway"></div></div>
        <div class="flight-progress"><span id="flightProgress"></span></div>
        <div class="flight-details"><div><small>TRAVEL CLASS</small><b>${esc(travelClass)}</b></div><div><small>TICKET</small><b>GH₵ ${money(fare)}</b></div><div><small>DESTINATION</small><b>${esc(country)}</b></div></div>
        <p class="flight-note" id="flightNote">Please fasten your seat belt. Your journey is underway.</p>
        <button type="button" class="primary full" id="flightContinue" disabled>Flying…</button>
        <button type="button" class="flight-skip" id="flightSkip">Skip animation</button>
      </div>`;
      document.body.appendChild(overlay);
      const status=overlay.querySelector('#flightStatus'),note=overlay.querySelector('#flightNote'),continueBtn=overlay.querySelector('#flightContinue'),plane=overlay.querySelector('.flight-plane'),progress=overlay.querySelector('#flightProgress');
      let ended=false,stageTimer=[];
      const arrive=()=>{
        if(ended)return;ended=true;stageTimer.forEach(clearTimeout);
        overlay.querySelector('#flightScene').classList.add('landed');
        status.textContent=`Welcome to ${city}!`;note.textContent='You have landed safely. Your Accra Life location has been updated.';
        continueBtn.disabled=false;continueBtn.textContent=`Arrive in ${city}`;
        overlay.querySelector('#flightSkip').style.display='none';
        progress.style.width='100%';
      };
      const close=async()=>{
        if(!ended){arrive();}
        overlay.remove();
        $('locationText').textContent=`${city.toUpperCase()}${country&&country!=='Ghana'?', '+country.toUpperCase():''}`;
        $('sceneZone').textContent=`${city.toUpperCase()}, ${country.toUpperCase()}`;
        $('footerStatus').textContent='LANDED';
        await refreshWallet();await refreshProfile();await openTab('travel');resolve();
      };
      continueBtn.addEventListener('click',close);
      overlay.querySelector('#flightSkip').addEventListener('click',arrive);
      overlay.addEventListener('click',e=>{if(e.target===overlay&&ended)close();});
      stageTimer.push(setTimeout(()=>{status.textContent='Taxiing on the runway…';note.textContent='The passenger jet is lining up and building speed for takeoff.';},1200));
      stageTimer.push(setTimeout(()=>{status.textContent='Taking off from Accra…';note.textContent='The nose lifts gently as the aircraft leaves the runway and climbs.';},3500));
      stageTimer.push(setTimeout(()=>{status.textContent=`In the air · En route to ${city}`;note.textContent='The aircraft settles into a steady cruise while clouds drift past the windows.';},6500));
      stageTimer.push(setTimeout(()=>{status.textContent='Beginning descent…';note.textContent=`The jet is descending gradually toward ${city} airport.`;},13500));
      stageTimer.push(setTimeout(()=>{status.textContent='On final approach…';note.textContent='The runway is ahead. The aircraft is lining up for a smooth landing.';},16000));
      stageTimer.push(setTimeout(arrive,18000));
      // The animation is intentionally slower, with a runway roll, gentle climb, cruise, descent and touchdown.
      const started=Date.now();const progressTimer=setInterval(()=>{if(ended){clearInterval(progressTimer);return;}progress.style.width=Math.min(98,((Date.now()-started)/18000)*100)+'%';},100);
    });
  }
  function showHireConfirmation(jobName,salary){
    document.querySelector('.hire-modal-overlay')?.remove();
    const overlay=document.createElement('div');
    overlay.className='hire-modal-overlay';
    overlay.setAttribute('role','dialog');
    overlay.setAttribute('aria-modal','true');
    overlay.setAttribute('aria-labelledby','hireModalTitle');
    overlay.innerHTML=`<div class="hire-modal"><div class="hire-modal-check">✓</div><div class="section-label">A NEW CHAPTER BEGINS</div><h2 id="hireModalTitle">Congratulations, ${esc(profile?.display_name||'Arria')}!</h2><p>You've been hired as <strong>${esc(jobName)}</strong>.</p><p class="hire-modal-sub">Your career in Accra starts now. Keep building your reputation and growing your wallet.</p>${salary!=null?`<div class="hire-modal-salary">GH₵ ${money(salary)} <small>per hour in game</small></div>`:''}<button type="button" class="primary full" id="hireModalContinue">Continue playing</button></div>`;
    document.body.appendChild(overlay);
    const close=()=>overlay.remove();
    overlay.querySelector('#hireModalContinue').addEventListener('click',close);
    overlay.addEventListener('click',e=>{if(e.target===overlay)close();});
    overlay.querySelector('#hireModalContinue').focus();
  }
  $('loginBtn').onclick=async()=>{if(user){await enterGame(user);}else showAuth('login');};
  function showLifePathPicker(){
    document.getElementById('lifePathOverlay')?.remove();
    const overlay=document.createElement('div');overlay.id='lifePathOverlay';overlay.className='life-path-overlay';
    overlay.innerHTML=`<div class="life-path-dialog" role="dialog" aria-modal="true" aria-labelledby="lifePathTitle"><button type="button" class="life-path-close" aria-label="Close">×</button><div class="section-label">CHOOSE YOUR STARTING STORY</div><h2 id="lifePathTitle">Where does your Accra story begin?</h2><p class="life-path-intro">Choose your starting money, home, family support and career difficulty. Your choice is saved to your new game account.</p><div class="life-path-grid"><button type="button" class="life-path-card" data-life-path="lapo"><span class="life-path-icon">🥲</span><b>LAPO</b><small>POOR KID · HARD MODE</small><strong>GH₵ 100</strong><p>Born in Nima. No allowance, no home, and low-paying hustle jobs to start.</p><span class="life-path-story">“Every cedi, you hustle.”</span><span class="life-path-choose">Choose Lapo</span></button><button type="button" class="life-path-card recommended" data-life-path="semi-rich"><span class="life-path-badge">DEFAULT</span><span class="life-path-icon">🙂</span><b>SEMI-RICH</b><small>MIDDLE CLASS · NORMAL MODE</small><strong>GH₵ 1,000</strong><p>Adenta family, Starter Studio in Osu, and GH₵ 200 family allowance every 7 days.</p><span class="life-path-story">“Parents support you, but you work.”</span><span class="life-path-choose">Choose Semi-rich</span></button><button type="button" class="life-path-card nepo-locked" data-life-path="nepo"><span class="life-path-icon">😎💰</span><b>NEPO BABY</b><small>RICH KID · EASY MODE</small><strong>GH₵ 10,000</strong><p>Airport Residential family, East Legon home, and GH₵ 1,000 weekly allowance.</p><span class="life-path-story">“Daddy owns four houses. Life is soft.”</span><span class="life-path-choose">🔒 Unlock options not active yet</span></button></div><p class="life-path-note">Nepo Baby requires a verified ad reward or a secure GH₵ 20 Paystack payment. Neither unlock method is connected yet, so no payment will be taken.</p></div>`;
    document.body.appendChild(overlay);
    overlay.querySelector('.life-path-close').onclick=()=>overlay.remove();
    overlay.addEventListener('click',ev=>{if(ev.target===overlay)overlay.remove();});
    overlay.querySelectorAll('[data-life-path]').forEach(card=>card.addEventListener('click',()=>{const path=card.dataset.lifePath;if(path==='nepo'){toast('Nepo Baby unlock is not active yet. No payment has been taken.');return;}selectedLifePath=path;overlay.remove();showAuth('signup');}));
  }
  $('signupBtn').onclick=async()=>{if(user){if(!confirm('You are signed in. Sign out of this account and start a separate new life? Your saved progress will remain on the account.'))return;await sb.auth.signOut();user=null;profile=null;if(notificationPoll)clearInterval(notificationPoll);}selectedLifePath='semi-rich';showLifePathPicker();};$('backBtn').onclick=()=>{showLanding();renderLandingPreview(user);};$('switchAuth').onclick=()=>showAuth(mode==='signup'?'login':'signup');$('signInTab').onclick=()=>showAuth('login');$('createAccountTab').onclick=()=>showAuth('signup');$('forgotPassword').onclick=async()=>{const email=$('email').value.trim();if(!email){$('authMsg').textContent='Enter your email address first, then tap Forgot password.';$('authMsg').className='msg';$('email').focus();return;}const button=$('forgotPassword');setBusy(button,true,'Sending reset email…');try{const result=await withTimeout(sb.auth.resetPasswordForEmail(email,{redirectTo:location.origin}),15000,'Password reset request timed out. Please try again.');if(result.error)throw result.error;$('authMsg').textContent='If an account exists for that email, a password reset link will be sent.';$('authMsg').className='msg ok';}catch(err){$('authMsg').textContent=errorText(err);$('authMsg').className='msg';}finally{setBusy(button,false);}};
  // Guard every login/create attempt so a stalled network request cannot leave the button spinning forever.
  const withTimeout = (promise, ms, label) => Promise.race([promise, new Promise((_, reject) => setTimeout(() => reject(new Error(label || 'The request timed out. Please check your connection and try again.')), ms))]);
  $('authForm').onsubmit=async e=>{
    e.preventDefault();
    const button=$('authSubmit');
    const email=$('email').value.trim(),password=$('password').value,name=$('username').value.trim(),confirmPassword=$('confirmPassword')?.value||'';
    $('authMsg').textContent='';$('authMsg').className='msg';
    if(mode==='signup'&&!name){$('authMsg').textContent='Choose a player name first.';return;}
    if(mode==='signup'&&name.length<3){$('authMsg').textContent='Your player name must be at least 3 characters.';return;}
    if(mode==='signup'&&password!==confirmPassword){$('authMsg').textContent='Your passwords do not match.';return;}
    setBusy(button,true,mode==='signup'?'Creating your life…':'Logging in…');
    try{
      let r;
      if(mode==='signup'){
        const schemaCheck=await withTimeout(sb.from('players').select('life_path').limit(1),10000,'Checking life-path setup timed out.');if(schemaCheck.error)throw new Error('Life paths are not enabled on the database yet. Apply V41-LIFE-PATHS-AND-OWNED-HOME-REVIEW.sql in Supabase before creating a new life.');
        const uname=name.toLowerCase().replace(/^@+/,'').trim();
        const usernameCheck=await withTimeout(sb.from('players').select('id').ilike('username',uname).limit(1),10000,'Username check timed out. Please try again.');
        if(usernameCheck.error)throw usernameCheck.error;
        if(usernameCheck.data?.length){throw new Error('That player name is already taken. Please choose another.');}
        r=await withTimeout(sb.auth.signUp({email,password,options:{data:{username:name,display_name:name,life_path:selectedLifePath||'semi-rich'},emailRedirectTo:location.origin}}),15000,'Creating your account is taking too long. Check your internet connection and Supabase configuration, then try again.');
        if(r.error)throw r.error;
        if(r.data.session&&r.data.user){
          $('authMsg').className='msg';$('authMsg').textContent='Account created. Loading your Accra story…';
          await withTimeout(enterGame(r.data.user),20000,'Your account was created, but loading the player profile timed out. Please log in again.');
        }else{
          $('authMsg').className='msg ok';
          $('authMsg').textContent='Account created. Check your email to confirm your account, then return here and choose Continue to log in.';
        }
      }else{
        r=await withTimeout(sb.auth.signInWithPassword({email,password}),15000,'Login is taking too long. Check your connection and try again.');
        if(r.error)throw r.error;
        $('authMsg').textContent='Logged in. Loading your Accra story…';
        await withTimeout(enterGame(r.data.user),20000,'You logged in, but your player profile took too long to load. Please try again.');
      }
    }catch(err){
      console.error('Accra Life login/create error:',err);
      $('authMsg').textContent=errorText(err);
      $('authMsg').className='msg';
    }finally{setBusy(button,false);}
  };
  $('tabs').addEventListener('click',e=>{const b=e.target.closest('[data-tab]');if(b)openTab(b.dataset.tab);});
  document.addEventListener('click',e=>{const b=e.target.closest('[data-phone-tab]');if(!b)return;const tab=b.dataset.phoneTab;if(tab==='games'){location.href='accra-life-games.html';return;}if(tab==='phone'){openTab('phone');return;}if(tab==='sendmoney'){toast('Player-to-player transfers are currently disabled.');return;}if(['home','assets','map','work','travel','social','wallet','business','notifications','settings'].includes(tab)){openTab(tab);return;}toast(`${b.dataset.phoneName||'This app'} is coming soon to Accra Life.`);});
  document.addEventListener('submit',async e=>{if(e.target?.id!=='accraSendMoneyForm')return;e.preventDefault();const status=$('sendMoneyStatus'),button=e.target.querySelector('button[type="submit"]');const username=($('sendRecipient')?.value||'').trim().replace(/^@+/,'').toLowerCase();const amount=Number($('sendAmount')?.value);const message=($('sendMessage')?.value||'').trim();if(!username){if(status)status.textContent='Enter the recipient username.';return;}if(!Number.isFinite(amount)||amount<1||amount>500){if(status)status.textContent='Enter an amount from GH₵1 to GH₵500.';return;}if(Number(profile?.level||1)<3){if(status)status.textContent='Reach Level 3 before sending money.';return;}setBusy(button,true,'Sending securely…');if(status)status.textContent='Checking recipient and applying server-side transfer limits…';try{const recipient=await sb.from('players').select('id,username,display_name').ilike('username',username).maybeSingle();if(recipient.error)throw recipient.error;if(!recipient.data){throw new Error('No player found with that username. Check the spelling.');}if(recipient.data.id===user.id)throw new Error('You cannot send money to yourself.');const result=await sb.rpc('send_game_money_with_fee',{p_recipient_id:recipient.data.id,p_amount:amount,p_message:message||null});if(result.error)throw result.error;const d=result.data||{};toast(`Sent GH₵ ${money(d.sent||amount)} to @${recipient.data.username}. Fee: GH₵ ${money(d.fee||amount*.15)}.`);if(status)status.textContent=`Transfer successful. @${recipient.data.username} received GH₵ ${money(d.sent||amount)}; fee GH₵ ${money(d.fee||amount*.15)}. Your new balance is GH₵ ${money(d.sender_balance)}.`;await refreshWallet();await openTab('sendmoney');}catch(err){console.error('Send money failed:',err);if(status)status.textContent=errorText(err);toast(errorText(err));}finally{setBusy(button,false);}});
  document.addEventListener('keydown',e=>{if(!venueActivePlaceId||activeTab!=='map'||/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName||''))return;const k=e.key.toLowerCase();const dirs={arrowup:[0,1],w:[0,1],arrowdown:[0,-1],s:[0,-1],arrowleft:[-1,0],a:[-1,0],arrowright:[1,0],d:[1,0]};if(dirs[k]){e.preventDefault();moveWorldCharacter(...dirs[k]);}else if(k===' '){e.preventDefault();doWorldAction(venueActivePlaceId==='upsa'?(worldPosition.seated?'study':'sit'):venueActivePlaceId==='church'?'worship':venueActivePlaceId==='nightclub'?'dance':venueActivePlaceId==='gym'?'workout':'talk');}});
  let furnitureDrag=null;
  document.addEventListener('pointerdown',e=>{const piece=e.target.closest('[data-drag-furniture]');if(!piece||!piece.closest('.apartment-room'))return;furnitureDrag={piece,id:piece.dataset.dragFurniture,room:piece.closest('.apartment-room')};piece.classList.add('is-dragging');e.preventDefault();});
  document.addEventListener('pointermove',e=>{if(!furnitureDrag)return;const r=furnitureDrag.room.getBoundingClientRect();const x=Math.max(2,Math.min(94,((e.clientX-r.left)/r.width)*100));const y=Math.max(3,Math.min(68,((r.bottom-e.clientY)/r.height)*100));furnitureDrag.piece.style.left=x+'%';furnitureDrag.piece.style.bottom=y+'%';furnitureDrag.piece.dataset.savedX=x;furnitureDrag.piece.dataset.savedY=y;});
  document.addEventListener('pointerup',async()=>{if(!furnitureDrag)return;const d=furnitureDrag;d.piece.classList.remove('is-dragging');furnitureDrag=null;if(d.piece.dataset.savedX===undefined)return;const x=Number(d.piece.dataset.savedX),y=Number(d.piece.dataset.savedY);const result=await sb.rpc('move_furniture',{p_furniture_id:d.id,p_pos_x:x,p_pos_y:y});if(result.error){toast(errorText(result.error));await openTab('assets');}else toast('Room arrangement saved.');});

  $('panel').addEventListener('submit',async e=>{
    if(e.target.id!=='clubSongForm')return;e.preventDefault();
    if(!MUSIC_ENABLED_PLACES.has(venueActivePlaceId)){toast('Enter a music-enabled venue to request a song.');return;}
    const title=$('clubSongTitle')?.value.trim(),artist=$('clubSongArtist')?.value.trim();
    if(!title||!artist){toast('Enter both the song title and artist.');return;}
    const button=e.target.querySelector('[type="submit"]');setBusy(button,true,'Sending request…');
    const row={venue_id:venueQueueId(venueActivePlaceId),requester_id:user.id,requester_name:profile?.display_name||profile?.username||'Player',song_title:title.slice(0,120),artist_name:artist.slice(0,120),youtube_video_id:null,status:'pending'};
    const result=await sb.from('club_song_requests').insert(row).select('id').single();
    setBusy(button,false);
    if(result.error){toast(`Song request could not be saved: ${errorText(result.error)}. Check the V25 database setup.`);return;}
    e.target.reset();toast(`Your song is in this venue’s shared queue!`);await refreshClubSongRoom();
  });
  $('panel').addEventListener('click',async e=>{
    const searchUsername=e.target.closest('[data-search-username]');if(searchUsername){const input=$('usernameSearch'),box=$('usernameSearchResults');const username=(input?.value||'').trim().replace(/^@+/,'').toLowerCase();if(!username){toast('Enter a username to search.');return;}box.innerHTML='<div class="loading">Searching for @'+esc(username)+'…</div>';const r=await sb.from('players').select('id,display_name,username,level,experience').ilike('username',username).limit(10);if(r.error){box.innerHTML=`<div class="empty">Search failed: ${esc(errorText(r.error))}</div>`;return;}const found=(r.data||[]).filter(p=>p.id!==user.id);box.innerHTML=found.map(p=>`<div class="tx"><div><b>${esc(p.display_name||p.username||'Accra Life user')}</b><small>@${esc(p.username||'player')} · Level ${p.level||1} · ${p.experience||0} XP</small></div><button class="action-btn" data-view-profile="${p.id}">View profile</button></div>`).join('')||'<div class="empty">No other account was found with that exact username. Check the spelling or ask them to share their username.</div>';return;}
    const viewProfile=e.target.closest('[data-view-profile]')?.dataset.viewProfile;if(viewProfile){await showPublicProfile(viewProfile);return;}
    const closeProfile=e.target.closest('[data-profile-close]');if(closeProfile){document.querySelector('.accra-profile-overlay')?.remove();return;}
    const closeChat=e.target.closest('[data-chat-close]');if(closeChat){document.querySelector('.accra-chat-overlay')?.remove();return;}
    const shareProfile=e.target.closest('[data-share-profile]');if(shareProfile){const uname=shareProfile.dataset.shareProfile||'player',url=shareProfile.dataset.shareUrl||`${location.origin}${location.pathname}?find=${encodeURIComponent(uname)}`,textToShare=`Find me on Accra Life: @${uname}\n${url}`;try{if(navigator.share)await navigator.share({title:'My Accra Life profile',text:textToShare,url});else if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(textToShare);toast('Your username and profile link were copied. Share them with your friend!');}else window.prompt('Copy and share your Accra Life username and profile link:',textToShare);}catch(err){if(err?.name!=='AbortError')window.prompt('Copy and share your Accra Life username and profile link:',textToShare);}return;}
    const profileMessage=e.target.closest('[data-profile-message]');if(profileMessage){const id=profileMessage.dataset.profileMessage,name=profileMessage.dataset.personName||'Player';document.querySelector('.accra-profile-overlay')?.remove();await openChatWith(id,name);return;}
    const openChat=e.target.closest('[data-open-chat]');if(openChat){await openChatWith(openChat.dataset.openChat,openChat.dataset.personName||'Player');return;}
    const profileMoney=e.target.closest('[data-profile-money]');if(profileMoney){await sendGameMoneyTo(profileMoney.dataset.profileMoney,profileMoney.dataset.personName||'this player');return;}
    const chatMoney=e.target.closest('[data-chat-money]');if(chatMoney){await sendGameMoneyTo(chatMoney.dataset.chatMoney,chatMoney.dataset.personName||'this player');return;}
    const personal=e.target.closest('[data-personal-music]');if(personal){const q=$('personalMusicSearch')?.value.trim();if(!q){toast('Type a song, artist or playlist first.');return;}const service=personal.dataset.personalMusic;const urls={youtube:`https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`,spotify:`https://open.spotify.com/search/${encodeURIComponent(q)}`,apple:`https://music.apple.com/us/search?term=${encodeURIComponent(q)}`};window.open(urls[service],'_blank','noopener');return;}
    if(e.target.closest('[data-club-refresh]')){toast('The queue refreshes automatically.');return;}
    const enableAudio=e.target.closest('[data-enable-club-audio]');if(enableAudio){toast('Embedded playback is disabled. Use Open song in YouTube.');return;}
    const playNext=e.target.closest('[data-club-play-next]')?.dataset.clubPlayNext;if(playNext){
      // Public DJ controls remain locked until a server-verified venue-staff role exists.
      toast('DJ controls are locked to verified venue staff. You can still request songs; the public queue refreshes automatically.');return;
      if(!MUSIC_ENABLED_PLACES.has(venueActivePlaceId)){toast('Enter the venue to operate its demo music queue.');return;}
      const button=e.target.closest('[data-club-play-next]');setBusy(button,true,'Starting…');
      const finish=await sb.from('club_song_requests').update({status:'played'}).eq('venue_id',venueQueueId(venueActivePlaceId)).eq('status','playing');
      if(finish.error){setBusy(button,false);toast(`Could not update the DJ queue: ${errorText(finish.error)}`);return;}
      const started=await sb.from('club_song_requests').update({status:'playing',accepted_at:new Date().toISOString()}).eq('id',playNext).eq('status','pending').select('id').maybeSingle();
      setBusy(button,false);
      if(started.error||!started.data){toast(started.error?errorText(started.error):'That request was already handled. Refresh the queue.');await refreshClubSongRoom();return;}
      toast('The venue started the requested song. Each listener can tap the player on their own device.');await refreshClubSongRoom();return;
    }
    const npcTarget=e.target.closest('[data-world-character]');
    if(npcTarget && npcTarget.classList.contains('is-npc')){
      const npcName=npcTarget.querySelector('.world-nameplate')?.textContent?.replace(/^NPC · /,'')||'Student';
      worldPosition.seated=false;worldPosition.action='talking';paintWorldCharacter();updateWorldPresence();
      const line=npcName.includes('Ama')?'I hope you brought your notes for today’s lecture.':npcName.includes('Kojo')?'Did you understand the last topic?':npcName.includes('Efua')?'Let’s compare notes after class.':'Hi! Are you here for the lecture too?';
      toast(`${npcName}: “${line}”`);return;
    }
    const move=e.target.closest('[data-world-move]')?.dataset.worldMove;if(move){const [dx,dy]=move.split(',').map(Number);moveWorldCharacter(dx,dy);return;}
    const worldAction=e.target.closest('[data-world-action]')?.dataset.worldAction;if(worldAction){doWorldAction(worldAction);return;}
    const place=e.target.closest('[data-place]')?.dataset.place;if(place){openPlace(place);return;}
    const tab=e.target.closest('[data-tab]')?.dataset.tab;if(tab){await openTab(tab);return;}
    const reload=e.target.closest('[data-reload]')?.dataset.reload;if(reload){await openTab(reload);return;}
    const hire=e.target.closest('[data-hire]')?.dataset.hire;if(hire){
      const jobResult=await sb.from('jobs').select('name,salary').eq('id',hire).maybeSingle();
      if(jobResult.error){toast(errorText(jobResult.error));return;}
      const jobName=jobResult.data?.name||'your new role';
      const hired=await doRpc('hire_for_job',{p_job_id:hire},'You have been hired!');
      if(hired) showHireConfirmation(jobName,jobResult.data?.salary);
      return;
    }
    const dest=e.target.closest('[data-dest]')?.dataset.dest;if(dest){
      const cls=$('travelClass')?.value||'Economy';
      const button=e.target.closest('[data-dest]');setBusy(button,true,'Booking flight…');
      try{
        const [destinationResult,bookingResult]=await Promise.all([
          sb.from('travel_destinations').select('id,name,city,country,airport_code,base_fare').eq('id',dest).maybeSingle(),
          sb.rpc('book_travel',{p_destination_id:dest,p_travel_class:cls})
        ]);
        if(bookingResult.error)throw bookingResult.error;
        const destination=destinationResult.data||{};
        await showFlightExperience(destination,cls,bookingResult.data||{});
      }catch(err){toast(errorText(err));setBusy(button,false);}
      return;
    }
    const prop=e.target.closest('[data-buy-property]')?.dataset.buyProperty;if(prop){await doRpc('purchase_property',{p_property_id:prop},'Property purchased!');return;}
    const car=e.target.closest('[data-buy-car]')?.dataset.buyCar;if(car){await doRpc('purchase_car',{p_car_id:car},'Car purchased!');return;}
    const inviteProperty=e.target.closest('[data-invite-property]')?.dataset.inviteProperty;
    if(inviteProperty){
      const guestId=$(`guestSelect-${inviteProperty}`)?.value;
      if(!guestId){toast('Choose a player to invite first.');return;}
      const result=await sb.from('apartment_visits').insert({owner_id:user.id,guest_id:guestId,property_id:inviteProperty,status:'pending'});
      if(result.error){toast(errorText(result.error));return;}
      toast('Apartment invitation sent! They will receive a notification.');await openTab('assets');return;
    }
    const visitId=e.target.closest('[data-visit-id]')?.dataset.visitId;
    const visitResponse=e.target.closest('[data-visit-response]')?.dataset.visitResponse;
    if(visitId&&visitResponse){const result=await sb.from('apartment_visits').update({status:visitResponse,responded_at:new Date().toISOString()}).eq('id',visitId).eq('guest_id',user.id);if(result.error){toast(errorText(result.error));return;}toast(visitResponse==='accepted'?'Invitation accepted! You can now visit the apartment.':'Invitation declined.');await openTab('assets');return;}
    const furnitureId=e.target.closest('[data-buy-furniture]')?.dataset.buyFurniture;
    if(furnitureId){const result=await sb.rpc('purchase_furniture',{p_item_id:furnitureId,p_pos_x:15+Math.floor(Math.random()*65),p_pos_y:12+Math.floor(Math.random()*38)});if(result.error){toast(errorText(result.error));return;}toast('Furniture purchased! Drag it to arrange your room.');await refreshWallet();await openTab('assets');return;}
    const sellFurniture=e.target.closest('[data-sell-furniture]')?.dataset.sellFurniture;if(sellFurniture){if(!confirm('Sell this furniture for 60% of its shop price?'))return;const result=await sb.rpc('sell_furniture',{p_furniture_id:sellFurniture});if(result.error){toast(errorText(result.error));return;}toast(`Sold ${result.data?.item||'furniture'} for GH₵ ${money(result.data?.payout)}.`);await refreshWallet();await openTab('assets');return;}
    const sellProperty=e.target.closest('[data-sell-property]')?.dataset.sellProperty;if(sellProperty){if(!confirm('Sell this property for 70% of its listed price? You may need to resolve apartment invitations first.'))return;const result=await sb.rpc('sell_player_property',{p_property_id:sellProperty});if(result.error){toast(errorText(result.error));return;}toast(`Property sold for GH₵ ${money(result.data?.payout)}.`);await refreshWallet();await openTab('assets');return;}
    const sellVehicle=e.target.closest('[data-sell-vehicle]')?.dataset.sellVehicle;if(sellVehicle){if(!confirm('Sell this vehicle for 70% of its listed price?'))return;const result=await sb.rpc('sell_player_vehicle',{p_car_id:sellVehicle});if(result.error){toast(errorText(result.error));return;}toast(`Vehicle sold for GH₵ ${money(result.data?.payout)}.`);await refreshWallet();await openTab('assets');return;}
    const openVisit=e.target.closest('[data-open-apartment]')?.dataset.openApartment;
    if(openVisit){const r=await sb.from('apartment_visits').select('*').eq('id',openVisit).in('status',['accepted']).maybeSingle();if(r.error||!r.data){toast('This apartment visit is no longer available.');return;}const v=r.data;if(v.owner_id!==user.id&&v.guest_id!==user.id){toast('You are not part of this invitation.');return;}const hostId=v.owner_id;const [host,home,decor]=await Promise.all([sb.from('players').select('display_name,username').eq('id',hostId).maybeSingle(),sb.from('properties').select('name,location').eq('id',v.property_id).maybeSingle(),sb.from('player_furniture').select('quantity,furniture_items(name,icon)').eq('player_id',hostId)]);const hostName=host.data?.display_name||host.data?.username||'Your friend';const pieces=(decor.data||[]).map(f=>`<span class="room-piece" style="position:static;display:inline-block;margin:8px;font-size:30px">${esc(f.furniture_items?.icon||'🪑')}<small style="display:block;font-size:10px">${esc(f.furniture_items?.name||'Furniture')} ×${f.quantity||1}</small></span>`).join('');document.querySelector('.apartment-visit-overlay')?.remove();const overlay=document.createElement('div');overlay.className='hire-modal-overlay apartment-visit-overlay';overlay.innerHTML=`<div class="hire-modal apartment-visit-modal"><div class="section-label">YOU'RE VISITING</div><h2>${esc(home.data?.name||'Apartment')}</h2><p>${esc(hostName)}'s home · ${esc(home.data?.location||'Accra')}</p><div class="guest-room-preview"><div class="room-window"><span></span><span></span><span></span></div><div class="room-floor"></div><div class="room-sofa">🛋️</div><div class="room-plant">🪴</div>${pieces}</div><p class="hire-modal-sub">You're visiting another player's apartment in Accra Life.</p><button class="primary full" id="closeApartmentVisit">Leave apartment</button></div>`;document.body.appendChild(overlay);overlay.querySelector('#closeApartmentVisit').onclick=()=>overlay.remove();overlay.addEventListener('click',ev=>{if(ev.target===overlay)overlay.remove();});return;}
    const joinParty=e.target.closest('[data-join-party]');if(joinParty){const partyId=joinParty.dataset.joinParty;const result=await sb.from('house_party_attendees').upsert({party_id:partyId,player_id:user.id},{onConflict:'party_id,player_id',ignoreDuplicates:true});if(result.error){toast(errorText(result.error));return;}const partyTitle=joinParty.dataset.partyTitle||'House party';const party=await sb.from('house_parties').select('starts_at').eq('id',partyId).maybeSingle();const zone=`House Party: ${partyTitle}`;localStorage.setItem('accraLifeLocation',zone);$('locationText').textContent=zone.toUpperCase();$('sceneZone').textContent=zone.toUpperCase();await sb.from('player_locations').upsert({player_id:user.id,zone,x:0.5,y:0.5,updated_at:new Date().toISOString()},{onConflict:'player_id'});toast('You’re on the guest list! Have fun at the house party.');await renderHouseParty(partyId);return;}
    const leaveParty=e.target.closest('[data-leave-party]')?.dataset.leaveParty;if(leaveParty){const result=await sb.from('house_party_attendees').delete().eq('party_id',leaveParty).eq('player_id',user.id);if(result.error){toast(errorText(result.error));return;}toast('You left the party guest list.');await openTab('map');return;}
    const cancelParty=e.target.closest('[data-cancel-party]')?.dataset.cancelParty;if(cancelParty){if(!confirm('Cancel this house party?'))return;const result=await sb.from('house_parties').update({status:'cancelled'}).eq('id',cancelParty).eq('host_id',user.id);if(result.error){toast(errorText(result.error));return;}toast('House party cancelled.');await openTab('map');return;}
    const refreshParty=e.target.closest('[data-refresh-party]')?.dataset.refreshParty;if(refreshParty){await renderHouseParty(refreshParty);return;}
    const partyMessage=e.target.closest('[data-party-message]');if(partyMessage){const recipient=partyMessage.dataset.partyMessage,name=partyMessage.dataset.personName||'this player';const body=window.prompt(`Say hello to ${name}:`,'Hi! I’m at the house party too.');if(body&&body.trim()){const sent=await sb.from('messages').insert({sender_id:user.id,recipient_id:recipient,body:body.trim().slice(0,1000)});if(sent.error)toast(errorText(sent.error));else toast(`Message sent to ${name}!`);}return;}
    const refreshCrowd=e.target.closest('[data-refresh-crowd]')?.dataset.refreshCrowd;if(refreshCrowd){await refreshVenueCrowd(refreshCrowd);return;}
    const venueMessage=e.target.closest('[data-venue-message]');if(venueMessage){const recipient=venueMessage.dataset.venueMessage;const name=venueMessage.dataset.personName||'this player';const body=window.prompt(`Say hello to ${name}:`,'Hey! I saw you here in Accra Life. Want to chill?');if(body&&body.trim()){const sent=await sb.from('messages').insert({sender_id:user.id,recipient_id:recipient,body:body.trim().slice(0,1000)});if(sent.error)toast(errorText(sent.error));else toast(`Message sent to ${name}!`);}return;}
    const activity=e.target.closest('[data-place-activity]');if(activity){const p=ACCRA_PLACES.find(x=>x.id===activity.dataset.placeId);const index=Number(activity.dataset.placeActivity);if(p&&p.activities[index]){showActivityStage(p,index);document.getElementById('activityStage')?.scrollIntoView({behavior:'smooth',block:'center'});}return;}
    const startActivity=e.target.closest('[data-start-activity]');if(startActivity){beginActivity(startActivity.dataset.startActivity);return;}
    const cancelActivity=e.target.closest('[data-cancel-activity]');if(cancelActivity){clearInterval(activityTimer);activityTimer=null;activitySession=null;const p=ACCRA_PLACES.find(x=>x.id===cancelActivity.dataset.cancelActivity);if(p)showActivityStage(p,Number(cancelActivity.dataset.activityIndex),null);return;}
    const friend=e.target.closest('[data-friend]')?.dataset.friend;if(friend){const r=await sb.from('friendships').insert({requester_id:user.id,addressee_id:friend,status:'pending'});if(r.error)toast(errorText(r.error));else{toast('Friend request sent.');if(activeTab==='map')await renderVenue(ACCRA_PLACES.find(p=>`${p.name}, Accra`===(localStorage.getItem('accraLifeLocation')||''))?.id);else await openTab('social');}return;}
    const accept=e.target.closest('[data-accept-friend]')?.dataset.acceptFriend;if(accept){const r=await sb.from('friendships').update({status:'accepted',updated_at:new Date().toISOString()}).eq('id',accept).eq('addressee_id',user.id);if(r.error)toast(errorText(r.error));else{toast('Friend request accepted.');await openTab('social');}return;}
    const testComplete=e.target.closest('[data-test-complete]')?.dataset.testComplete;if(testComplete){const demo=readTestWallet();const item=demo.transactions.find(t=>t.id===testComplete&&t.kind==='withdrawal'&&t.status==='pending');if(!item){toast('That test request is no longer pending.');return;}item.status='simulated-complete';item.statusLabel='SIMULATED COMPLETE · NOT PAID';item.title='Virtual test withdrawal (simulated)';saveTestWallet(demo);toast('Simulation updated only. No money was transferred.');await openTab('wallet');return;}
    const action=e.target.closest('[data-action]')?.dataset.action;if(!action)return;
    if(action==='create-house-party'){
      const propertyId=$('partyProperty')?.value,title=$('partyTitle')?.value?.trim(),theme=$('partyTheme')?.value||'House party',startsRaw=$('partyStarts')?.value,description=$('partyDescription')?.value?.trim()||'';
      const startsAt=startsRaw?new Date(startsRaw):null;
      if(!propertyId){toast('Choose a property you own.');return;}if(!title||title.length<3){toast('Give your party a name with at least 3 characters.');return;}if(!startsAt||Number.isNaN(startsAt.getTime())||startsAt.getTime()<Date.now()-60000){toast('Choose a future date and time for your party.');return;}
      const result=await sb.from('house_parties').insert({host_id:user.id,property_id:propertyId,title,party_theme:theme,starts_at:startsAt.toISOString(),description,status:'open'}).select('id').single();if(result.error){toast(errorText(result.error));return;}toast('Your house party is published! Other players can find and join it on the map.');await openTab('map');return;
    }
    if(action==='test-wallet-add'){
      const amount=Number($('testWalletAmount')?.value);if(!Number.isFinite(amount)||amount<=0||amount>10000){toast('Enter a test amount from GH₵0.01 to GH₵10,000.');return;}
      const demo=readTestWallet();demo.balance=Math.round((demo.balance+amount)*100)/100;demo.transactions.unshift({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),kind:'deposit',amount,status:'simulated',statusLabel:'TEST FUNDS ADDED · NOT REAL MONEY',title:'Virtual test deposit',createdAt:new Date().toISOString()});saveTestWallet(demo);toast(`Added GH₵ ${money(amount)} in virtual test funds only.`);await openTab('wallet');return;
    }
    if(action==='test-wallet-withdraw'){
      const amount=Number($('testWalletAmount')?.value);const demo=readTestWallet();if(!Number.isFinite(amount)||amount<=0||amount>10000){toast('Enter a test withdrawal amount from GH₵0.01 to GH₵10,000.');return;}if(amount>demo.balance){toast('The test balance is too low for that withdrawal. Add virtual test funds first.');return;}
      demo.balance=Math.round((demo.balance-amount)*100)/100;demo.transactions.unshift({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),kind:'withdrawal',amount,status:'pending',statusLabel:'TEST REQUEST · NOT SENT',title:'Virtual test withdrawal request',createdAt:new Date().toISOString()});saveTestWallet(demo);toast('Test withdrawal request recorded. No money was sent.');await openTab('wallet');return;
    }
    if(action==='test-wallet-reset'){
      if(!confirm('Reset your local virtual test balance and test history? This does not affect your game wallet.'))return;localStorage.removeItem(testWalletKey());toast('Virtual test wallet reset.');await openTab('wallet');return;
    }
    if(action==='salary'){await doRpc('claim_job_salary',{},'Salary claimed!');return;}
    if(action==='transfer'){toast('Player-to-player transfers are disabled for launch.');return;}
    if(action==='send-message'){
      const recipient=$('messageRecipient')?.value,body=$('messageBody')?.value?.trim();
      if(!recipient||!body){toast('Choose a player and write a message first.');return;}
      const r=await sb.from('messages').insert({sender_id:user.id,recipient_id:recipient,body}).select('id').single();
      if(r.error){toast(errorText(r.error));return;}
      toast('Message sent.');await openTab('social');return;
    }
    if(action==='save-display-name'){
      const name=$('settingsDisplayName')?.value?.trim();if(!name){toast('Enter a display name.');return;}
      const r=await sb.from('players').update({display_name:name,updated_at:new Date().toISOString()}).eq('id',user.id);
      if(r.error){toast(errorText(r.error));return;}await refreshProfile();toast('Display name updated.');await openTab('settings');return;
    }
    if(action==='change-email'){
      const email=$('settingsEmail')?.value?.trim();if(!email){toast('Enter the new email address.');return;}
      const r=await sb.auth.updateUser({email});if(r.error){toast(errorText(r.error));return;}toast('Email change requested. Check your email for confirmation.');return;
    }
    if(action==='change-password'){
      const password=$('settingsPassword')?.value;if(!password||password.length<6){toast('Use a password with at least 6 characters.');return;}
      const r=await sb.auth.updateUser({password});if(r.error){toast(errorText(r.error));return;}$('settingsPassword').value='';toast('Password updated.');return;
    }
    if(action==='save-settings'){
      const enabled=$('notificationsEnabled')?.checked===true;
      const r=await sb.from('player_settings').upsert({player_id:user.id,notifications_enabled:enabled,updated_at:new Date().toISOString()},{onConflict:'player_id'});
      if(r.error){toast(errorText(r.error));return;}toast(enabled?'In-game notifications are on.':'In-game notifications are off.');await pollNotifications(false);return;
    }
    if(action==='settings-logout'){await sb.auth.signOut();user=null;profile=null;if(notificationPoll)clearInterval(notificationPoll);showLanding();return;}
    if(action==='create-business'){const name=$('bizName')?.value?.trim(),category=$('bizCategory')?.value,location=$('bizLocation')?.value,price=Number($('bizPrice')?.value);if(!name||!Number.isFinite(price)||price<100){toast('Enter a business name and startup cost of at least GH₵100.');return;}await doRpc('create_business',{p_name:name,p_category:category,p_location:location,p_price:price},'Your business is open!');return;}
    if(action==='create-investment'){const name=$('assetName')?.value?.trim(),principal=Number($('investAmount')?.value),rate=Number($('investRate')?.value),days=Number($('investDays')?.value);if(!name||!Number.isFinite(principal)||principal<=0||!Number.isFinite(rate)||rate<0||rate>100){toast('Enter an investment name, amount and return rate from 0 to 100%.');return;}await doRpc('create_investment',{p_asset_name:name,p_principal:principal,p_return_rate:rate,p_days:days},'In-game investment created!');}
  });
  $('logoutBtn').onclick=async()=>{await sb.auth.signOut();user=null;profile=null;if(notificationPoll)clearInterval(notificationPoll);showLanding();};
  sb.auth.getSession().then(({data,error})=>{if(error){console.warn(error);return;}if(data.session){user=data.session.user;renderLandingPreview(user);}else renderLandingPreview(null);}).catch(console.error);
  sb.auth.onAuthStateChange((_event,session)=>{if(session&&!user){user=session.user;setTimeout(()=>renderLandingPreview(user),0);}else if(!session&&user){user=null;profile=null;if(notificationPoll)clearInterval(notificationPoll);showLanding();renderLandingPreview(null);}});
})();
