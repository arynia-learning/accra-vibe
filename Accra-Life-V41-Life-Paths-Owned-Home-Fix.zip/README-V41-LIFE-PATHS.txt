ACCRA LIFE V41 — LIFE PATHS + OWNED HOME STATUS

WHAT THIS PACKAGE CHANGES
- Keeps the current Accra Life landing illustration and both Continue / New Life buttons on one compact landing page.
- Landing account summary now shows the real saved wallet balance and player level for signed-in users. It does not fake online counts.
- New Life opens a three-path chooser overlay: Lapo (GH₵100) and Semi-rich (GH₵1,000 default). Selecting either opens the combined Create Account tab.
- Nepo Baby is shown as locked. The GH₵20 Paystack checkout and rewarded-ad verification are NOT connected, so the package does not charge anyone or grant GH₵10,000 without verified payment.
- The home card shows a disabled “Owned ✓” status for homes already listed in public.player_properties, while retaining a separate Sell button.
- Adds an optional weekly allowance UI for Semi-rich and Nepo paths, plus path-specific job filtering. These backend features require the SQL migration below.
- Keeps player-to-player transfers disabled; the Send Money app reports that transfers are disabled rather than opening a transfer form.
- Adds V41-LIFE-PATHS-AND-OWNED-HOME-REVIEW.sql.

IMPORTANT: DATABASE MIGRATION
The live Supabase schema uses public.players and public.player_properties. It does NOT use public.profiles or public.user_houses. The SQL file is review-first and has NOT been applied to Supabase. Back up the database and review the whole migration before applying it. New account creation through this V41 path chooser checks that the `life_path` column exists first; apply the V41 migration before testing signup. It changes the new-account trigger and hire_for_job RPC; it does not change existing wallet balances, delete accounts, or modify current home prices.

After the migration is applied, test with a BRAND-NEW test account:
1. New Life -> Lapo should create a new player with GH₵100 and no starter home.
2. New Life -> Semi-rich should create a new player with GH₵1,000 and Starter Studio ownership.
3. Existing accounts and their saved wallet balances should remain unchanged.
4. A permitted path should see its matching jobs; the database RPC should reject jobs from another path.
5. Weekly allowance should only credit once per 7 days and should be recorded in wallet_transactions.

NOT INCLUDED / NOT CLAIMED AS WORKING
- No fake “1.4k online” number. Use real online presence counts or a neutral “Accra community” label.
- No account deletion has been performed. The live data uses public.players, not public.profiles; several matching usernames were found, including two Arria records with different IDs. Review account IDs and dependencies before deletion.
- Paystack and rewarded ads are not implemented. Do not advertise the Nepo unlock as available until a server-side payment webhook/ad reward verifier is deployed.
- The migration is not automatically run when you upload website files.

MANUAL WEBSITE UPLOAD
1. Download and extract this ZIP.
2. Upload the website files to the root of the existing Cloudflare Pages project, replacing files with the same names.
3. Do not upload SQL into the website root as though it were a webpage; review/apply it separately in Supabase only after backup and review.
4. Test on Safari: New Life chooser, Lapo account creation, Semi-rich account creation, owned-home status, and existing login/wallet persistence.

TEST STATUS
- JavaScript syntax and ZIP integrity are checked locally.
- The website has not been deployed by this package build, and the live iPhone experience has not been end-to-end tested here.
