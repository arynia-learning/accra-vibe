ACCRA LIFE — V37 LOGIN / NEW LIFE LOADING FIX

WHAT THIS PATCH CHANGES
- Adds a 15-second timeout to Continue/login and New Life/account creation requests.
- Adds a 20-second timeout while loading the player profile/game after authentication.
- Ensures the submit button is restored after an error/timeout instead of spinning forever.
- Shows a readable error message in the sign-in/create-account screen.
- Does not delete accounts or modify the live database.

IMPORTANT
This patch improves stuck-loading handling and reports a timeout instead of spinning forever. It cannot repair a Supabase server/configuration/database policy issue by itself. If the screen reports a timeout, that message is useful evidence of the underlying connection/query issue.

DEPLOY TO CLOUDFLARE PAGES
1. Download and extract the ZIP.
2. In the extracted folder, select the runtime website files at the top level: index.html, app.js, styles.css, config.js, accra-life-games.html, admin.html, admin-dj.html, reset-password.html, and _redirects.
3. Upload/deploy those files together as the site's root (not inside a nested folder).
4. Wait for Cloudflare Pages to finish deployment.
5. Open https://prettycontent.pages.dev/ in Safari, refresh, then test New life and Continue.
6. If it still fails, read the exact error shown under the form. Do not repeatedly create new accounts as a test.

The ZIP includes the existing site files and a fix to app.js. SQL files and admin documentation are intentionally not part of the deployment bundle. No database migration is applied by this patch.
