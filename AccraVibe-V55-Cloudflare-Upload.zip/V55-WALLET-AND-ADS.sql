-- Accra Vibe V55. Already applied to the connected Supabase production project.
-- 1) Wallet defaults for future wallet rows.
ALTER TABLE public.wallets ALTER COLUMN balance SET DEFAULT 1200;

-- 2) Ad inventory. Every ad is virtual-only; billboard/sea-plot charges use RPC below.
CREATE TABLE IF NOT EXISTS public.ad_slots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('promotion','billboard','sea_plot')),
  title text NOT NULL DEFAULT 'Accra Vibe advert',
  link text NOT NULL CHECK (link ~* '^https?://'),
  image text,
  price numeric NOT NULL DEFAULT 0 CHECK (price >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS ad_slots_active_idx ON public.ad_slots(expires_at DESC);
CREATE INDEX IF NOT EXISTS ad_slots_user_idx ON public.ad_slots(user_id,created_at DESC);
ALTER TABLE public.ad_slots ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS ad_slots_active_ads_read ON public.ad_slots;
CREATE POLICY ad_slots_active_ads_read ON public.ad_slots FOR SELECT TO authenticated USING (expires_at > now());
DROP POLICY IF EXISTS ad_slots_owner_read ON public.ad_slots;
CREATE POLICY ad_slots_owner_read ON public.ad_slots FOR SELECT TO authenticated USING (user_id = (select auth.uid()));
GRANT SELECT ON public.ad_slots TO authenticated;

CREATE OR REPLACE FUNCTION public.city_create_ad_slot(p_type text, p_link text, p_image text DEFAULT NULL, p_title text DEFAULT 'Accra Vibe advert')
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_type text := lower(trim(coalesce(p_type,'')));
  v_link text := trim(coalesce(p_link,''));
  v_image text := nullif(trim(coalesce(p_image,'')),'');
  v_title text := left(trim(coalesce(p_title,'Accra Vibe advert')),100);
  v_price numeric;
  v_balance numeric;
  v_id uuid;
  v_expires timestamptz := now() + interval '7 days';
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Please sign in first.'; END IF;
  IF v_type NOT IN ('promotion','billboard','sea_plot') THEN RAISE EXCEPTION 'Choose a valid advert type.'; END IF;
  IF v_link !~* '^https?://' OR length(v_link)>1000 THEN RAISE EXCEPTION 'Enter a valid website link starting with https:// or http://'; END IF;
  IF v_image IS NOT NULL AND (v_image !~* '^https?://' OR length(v_image)>1000) THEN RAISE EXCEPTION 'Image link must start with https:// or http://'; END IF;
  IF length(v_title)<3 THEN RAISE EXCEPTION 'Enter an advert title of at least 3 characters.'; END IF;
  v_price := CASE v_type WHEN 'billboard' THEN 1500 WHEN 'sea_plot' THEN 50 ELSE 0 END;
  IF v_price > 0 THEN
    UPDATE public.wallets SET balance=balance-v_price,updated_at=now() WHERE player_id=v_uid AND balance>=v_price RETURNING balance INTO v_balance;
    IF NOT FOUND THEN RAISE EXCEPTION 'Not enough virtual money. This advert costs GH₵ %.', v_price; END IF;
    INSERT INTO public.wallet_transactions(player_id,amount,transaction_type,description)
    VALUES(v_uid,-v_price,'ad_slot_purchase',CASE v_type WHEN 'billboard' THEN 'Booked Accra Vibe billboard for 7 days' ELSE 'Rented Accra Vibe sea plot for 7 days' END);
  ELSE SELECT balance INTO v_balance FROM public.wallets WHERE player_id=v_uid; END IF;
  INSERT INTO public.ad_slots(user_id,type,title,link,image,price,expires_at) VALUES(v_uid,v_type,v_title,v_link,v_image,v_price,v_expires) RETURNING id INTO v_id;
  RETURN jsonb_build_object('id',v_id,'type',v_type,'price',v_price,'balance',v_balance,'expires_at',v_expires);
END; $$;
REVOKE ALL ON FUNCTION public.city_create_ad_slot(text,text,text,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.city_create_ad_slot(text,text,text,text) TO authenticated;

-- 3) New auth users begin with GH₵1,200 in the virtual wallet.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE base_username text; chosen_username text; chosen_display_name text; chosen_path text; starting_balance numeric := 1200;
BEGIN
  chosen_display_name := left(coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'), ''),nullif(split_part(coalesce(new.email, ''), '@', 1), ''),'New Player'),80);
  base_username := lower(regexp_replace(coalesce(nullif(trim(new.raw_user_meta_data->>'username'), ''),nullif(split_part(coalesce(new.email, ''), '@', 1), ''),'player'),'[^a-zA-Z0-9_]', '', 'g'));
  IF base_username = '' THEN base_username := 'player'; END IF;
  chosen_username := left(base_username,24);
  chosen_path := CASE WHEN new.raw_user_meta_data->>'life_path'='lapo' THEN 'lapo' WHEN new.raw_user_meta_data->>'life_path'='nepo' THEN 'nepo' ELSE 'semi-rich' END;
  BEGIN
    INSERT INTO public.players(id,username,display_name,life_path) VALUES(new.id,chosen_username,chosen_display_name,chosen_path) ON CONFLICT(id) DO NOTHING;
  EXCEPTION WHEN unique_violation THEN
    chosen_username := left(base_username,15)||'_'||substr(replace(new.id::text,'-',''),1,8);
    INSERT INTO public.players(id,username,display_name,life_path) VALUES(new.id,chosen_username,chosen_display_name,chosen_path) ON CONFLICT(id) DO NOTHING;
  END;
  INSERT INTO public.wallets(player_id,balance) VALUES(new.id,starting_balance) ON CONFLICT(player_id) DO NOTHING;
  IF chosen_path='nepo' THEN
    INSERT INTO public.player_properties(player_id,property_id) SELECT new.id,p.id FROM public.properties p WHERE p.name='East Legon Hills Villa' ON CONFLICT(player_id,property_id) DO NOTHING;
  ELSIF chosen_path='semi-rich' THEN
    INSERT INTO public.player_properties(player_id,property_id) SELECT new.id,p.id FROM public.properties p WHERE p.name='Starter Studio' ON CONFLICT(player_id,property_id) DO NOTHING;
  END IF;
  RETURN new;
END; $$;
