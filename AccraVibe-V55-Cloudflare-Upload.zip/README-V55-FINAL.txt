ACCRA VIBE V55 — WALLET + PHONE + MY ADS

What's included:
- Phone UI now displays 28 Ghana-themed app icons in a purple-to-orange gradient shell, with a skyline footer and live Africa/Accra clock.
- My Ads app supports free promotion links, GH₵1,500 billboards for 7 days, and GH₵50 sea plots for 7 days. Paid placements deduct virtual wallet funds through a server-side Supabase RPC that checks the balance.
- Active ads are listed in the Map screen for logged-in players; user ads expire after 7 days.
- Ghana flag tricolour strip uses continuous red/yellow/green bands with no white gaps.
- Duplicate DJ song requests are checked against pending/accepted requests for the same venue.
- New auth accounts now start with GH₵1,200. Existing non-zero balances remain unchanged; zero balances previously repaired to GH₵1,200.
- Public landing page for advertisers is included at /advertise (Cloudflare Pages _redirects routes it to advertise.html).
- Service-worker cache is bumped to v55.

IMPORTANT:
- Supabase migrations for wallet default, zero-balance repair, new-user wallet initialization, and ad_slots were applied to the existing production project and verified where possible.
- This ZIP has not been deployed to Cloudflare by this package creation step. Upload the ZIP contents to the existing Cloudflare Pages project jamila-dnm using Production.
- Test My Ads with a test account before announcing launch. Paid ads cost virtual game money; they are not real payments.
- The exact custom domain accravibe.app must be configured in Cloudflare DNS for https://accravibe.app/advertise to work; on the current Pages hostname use /advertise.
