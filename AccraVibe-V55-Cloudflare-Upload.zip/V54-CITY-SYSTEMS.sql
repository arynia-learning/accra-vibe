-- Accra Vibe V53: additive city systems. All currency is virtual game currency.
-- Safe to re-run: tables/indexes/functions use IF NOT EXISTS / CREATE OR REPLACE.

create table if not exists public.city_police_cases (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.players(id) on delete cascade,
  reported_id uuid not null references public.players(id) on delete cascade,
  reason text not null check (char_length(reason) between 3 and 500),
  status text not null default 'open' check (status in ('open','under_review','dismissed','resolved')),
  created_at timestamptz not null default now(),
  check (reporter_id <> reported_id)
);
create index if not exists city_police_cases_reported_created_idx on public.city_police_cases(reported_id, created_at desc);

create table if not exists public.city_jail (
  player_id uuid primary key references public.players(id) on delete cascade,
  reason text not null default 'Pending in-game police review',
  bail_amount numeric not null default 500 check (bail_amount >= 0),
  jailed_at timestamptz not null default now(),
  jailed_until timestamptz not null default (now() + interval '5 minutes')
);

create table if not exists public.city_court_cases (
  id uuid primary key default gen_random_uuid(),
  plaintiff_id uuid not null references public.players(id) on delete cascade,
  defendant_username text not null,
  defendant_id uuid references public.players(id) on delete set null,
  claim text not null check (char_length(claim) between 10 and 1000),
  status text not null default 'filed' check (status in ('filed','scheduled','settled','dismissed','closed')),
  filing_fee numeric not null default 50 check (filing_fee >= 0),
  created_at timestamptz not null default now()
);

alter table public.businesses add column if not exists daily_income numeric not null default 0 check (daily_income >= 0);
alter table public.businesses add column if not exists last_income_at timestamptz;

create table if not exists public.city_business_catalog (
  slug text primary key,
  name text not null,
  category text not null,
  price numeric not null check (price > 0),
  daily_income numeric not null check (daily_income >= 0),
  description text not null default '',
  is_active boolean not null default true
);
insert into public.city_business_catalog(slug,name,category,price,daily_income,description) values
 ('trotro-bus','Trotro Bus','Transport',120000,1500,'Own a virtual trotro route and earn game income once per day.'),
 ('makola-stall','Makola Market Stall','Retail',10000,400,'A busy virtual stall in Accra’s famous market.'),
 ('chop-bar','Neighbourhood Chop Bar','Food & Drink',25000,650,'Serve virtual local meals.'),
 ('salon','Beauty Salon','Beauty',18000,500,'A small salon with daily game income.'),
 ('phone-shop','Phone & Accessories Shop','Retail',45000,900,'Sell virtual devices and accessories.'),
 ('laundry','Laundry Service','Services',15000,350,'A local laundry business.'),
 ('mini-mart','Community Mini-Mart','Retail',60000,1100,'A convenience store in your neighbourhood.'),
 ('event-rentals','Event Rentals','Events',35000,750,'Rent virtual chairs, canopies and sound systems.'),
 ('ride-share-car','Ride-share Car','Transport',80000,1000,'A vehicle working virtual ride-share shifts.'),
 ('guest-house','Accra Guest House','Hospitality',250000,3000,'A premium virtual hospitality investment.')
on conflict(slug) do update set name=excluded.name,category=excluded.category,price=excluded.price,daily_income=excluded.daily_income,description=excluded.description,is_active=true;

create table if not exists public.city_bank_products (
  id uuid primary key default gen_random_uuid(),
  player_id uuid not null references public.players(id) on delete cascade,
  product_type text not null check (product_type in ('savings','bond')),
  principal numeric not null check (principal > 0),
  interest_rate numeric not null check (interest_rate >= 0 and interest_rate <= 100),
  opened_at timestamptz not null default now(),
  matures_at timestamptz not null,
  status text not null default 'active' check (status in ('active','paid')),
  paid_at timestamptz
);
create index if not exists city_bank_products_player_idx on public.city_bank_products(player_id,status,matures_at);

create table if not exists public.city_billboard_rentals (
  id uuid primary key default gen_random_uuid(),
  player_id uuid not null references public.players(id) on delete cascade,
  billboard_name text not null,
  ad_text text not null check (char_length(ad_text) between 3 and 100),
  rental_days integer not null check (rental_days in (1,7,30)),
  price numeric not null check (price >= 0),
  starts_at timestamptz not null default now(),
  ends_at timestamptz not null,
  created_at timestamptz not null default now()
);

alter table public.city_police_cases enable row level security;
alter table public.city_jail enable row level security;
alter table public.city_court_cases enable row level security;
alter table public.city_bank_products enable row level security;
alter table public.city_billboard_rentals enable row level security;
alter table public.city_business_catalog enable row level security;

drop policy if exists city_bank_products_owner_select on public.city_bank_products;
create policy city_bank_products_owner_select on public.city_bank_products for select to authenticated using (player_id = (select auth.uid()));
drop policy if exists city_billboard_rentals_owner_select on public.city_billboard_rentals;
create policy city_billboard_rentals_owner_select on public.city_billboard_rentals for select to authenticated using (player_id = (select auth.uid()));
drop policy if exists city_police_cases_reporter_select on public.city_police_cases;
create policy city_police_cases_reporter_select on public.city_police_cases for select to authenticated using (reporter_id = (select auth.uid()));
drop policy if exists city_court_cases_plaintiff_select on public.city_court_cases;
create policy city_court_cases_plaintiff_select on public.city_court_cases for select to authenticated using (plaintiff_id = (select auth.uid()));
drop policy if exists city_business_catalog_read on public.city_business_catalog;
create policy city_business_catalog_read on public.city_business_catalog for select to authenticated using (is_active = true);
-- Jail status is intentionally only visible to the affected player. Changes happen through checked RPCs.
drop policy if exists city_jail_self_select on public.city_jail;
create policy city_jail_self_select on public.city_jail for select to authenticated using (player_id = (select auth.uid()));

grant select on public.city_bank_products, public.city_billboard_rentals, public.city_police_cases, public.city_court_cases, public.city_jail, public.city_business_catalog to authenticated;

create or replace function public.city_report_player(p_username text, p_reason text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_uid uuid := auth.uid(); v_target uuid; v_reason text := left(trim(coalesce(p_reason,'')),500); v_case uuid;
begin
 if v_uid is null then raise exception 'Please sign in first.'; end if;
 if char_length(v_reason)<3 then raise exception 'Explain the report in at least 3 characters.'; end if;
 select id into v_target from public.players where lower(username)=lower(trim(both '@' from trim(coalesce(p_username,'')))) limit 1;
 if v_target is null then raise exception 'That username was not found.'; end if;
 if v_target=v_uid then raise exception 'You cannot report your own account.'; end if;
 if exists(select 1 from public.city_police_cases where reporter_id=v_uid and reported_id=v_target and created_at>now()-interval '24 hours') then raise exception 'You already filed a report about this player in the last 24 hours.'; end if;
 insert into public.city_police_cases(reporter_id,reported_id,reason) values(v_uid,v_target,v_reason) returning id into v_case;
 -- In-game roleplay jail: 5-minute timer. A single reporter can only trigger one report per target per day.
 insert into public.city_jail(player_id,reason,bail_amount,jailed_at,jailed_until)
 values(v_target,'In-game report filed. Case '||left(v_case::text,8),500,now(),now()+interval '5 minutes')
 on conflict(player_id) do update set reason=excluded.reason,bail_amount=500,jailed_at=now(),jailed_until=now()+interval '5 minutes';
 return jsonb_build_object('case_id',v_case,'jailed',true,'bail_amount',500,'timer_seconds',300);
end $$;

create or replace function public.city_clean_record()
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_uid uuid:=auth.uid(); v_open integer; v_jailed boolean;
begin
 if v_uid is null then raise exception 'Please sign in first.'; end if;
 select count(*) into v_open from public.city_police_cases where reported_id=v_uid and status in ('open','under_review');
 select exists(select 1 from public.city_jail where player_id=v_uid and jailed_until>now()) into v_jailed;
 return jsonb_build_object('clear',v_open=0 and not v_jailed,'open_cases',v_open,'currently_jailed',v_jailed);
end $$;

create or replace function public.city_pay_bail(p_username text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_uid uuid:=auth.uid(); v_target uuid; v_balance numeric;
begin
 if v_uid is null then raise exception 'Please sign in first.'; end if;
 select id into v_target from public.players where lower(username)=lower(trim(both '@' from trim(coalesce(p_username,'')))) limit 1;
 if v_target is null then raise exception 'That username was not found.'; end if;
 if v_target=v_uid then raise exception 'Ask a friend to pay your bail from their account.'; end if;
 if not exists(select 1 from public.city_jail where player_id=v_target and jailed_until>now()) then raise exception 'That player is not currently in the in-game jail.'; end if;
 update public.wallets set balance=balance-500,updated_at=now() where player_id=v_uid and balance>=500 returning balance into v_balance;
 if not found then raise exception 'You need at least GH₵500 to pay bail.'; end if;
 insert into public.wallet_transactions(player_id,amount,transaction_type,description) values(v_uid,-500,'bail_paid','Paid virtual bail for @'||trim(both '@' from p_username));
 delete from public.city_jail where player_id=v_target;
 return jsonb_build_object('paid',500,'payer_balance',v_balance,'released_username',trim(both '@' from p_username));
end $$;

create or replace function public.city_file_court_case(p_username text,p_claim text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_uid uuid:=auth.uid(); v_target uuid; v_case uuid; v_balance numeric; v_claim text:=left(trim(coalesce(p_claim,'')),1000);
begin
 if v_uid is null then raise exception 'Please sign in first.'; end if;
 if char_length(v_claim)<10 then raise exception 'Describe your claim in at least 10 characters.'; end if;
 if char_length(trim(coalesce(p_username,'')))<2 then raise exception 'Enter the defendant username.'; end if;
 update public.wallets set balance=balance-50,updated_at=now() where player_id=v_uid and balance>=50 returning balance into v_balance;
 if not found then raise exception 'Court filing costs GH₵50 in game money.'; end if;
 select id into v_target from public.players where lower(username)=lower(trim(both '@' from trim(coalesce(p_username,'')))) limit 1;
 insert into public.city_court_cases(plaintiff_id,defendant_username,defendant_id,claim,filing_fee)
 values(v_uid,trim(both '@' from trim(p_username)),v_target,v_claim,50) returning id into v_case;
 insert into public.wallet_transactions(player_id,amount,transaction_type,description) values(v_uid,-50,'court_filing','Filed an in-game court case');
 return jsonb_build_object('case_id',v_case,'balance',v_balance,'defendant_found',v_target is not null);
end $$;

create or replace function public.city_open_bank_product(p_product_type text,p_amount numeric)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_uid uuid:=auth.uid(); v_rate numeric; v_days integer; v_id uuid; v_balance numeric;
begin
 if v_uid is null then raise exception 'Please sign in first.'; end if;
 if p_amount is null or p_amount<=0 or p_amount>1000000000 then raise exception 'Choose a valid amount.'; end if;
 if p_product_type='savings' then v_rate:=0.5; v_days:=7;
 elsif p_product_type='bond' then v_rate:=2; v_days:=7;
 else raise exception 'Choose savings or a 7-day bond.'; end if;
 update public.wallets set balance=balance-p_amount,updated_at=now() where player_id=v_uid and balance>=p_amount returning balance into v_balance;
 if not found then raise exception 'Your available wallet balance is too low.'; end if;
 insert into public.city_bank_products(player_id,product_type,principal,interest_rate,matures_at)
 values(v_uid,p_product_type,p_amount,v_rate,now()+(v_days||' days')::interval) returning id into v_id;
 insert into public.wallet_transactions(player_id,amount,transaction_type,description) values(v_uid,-p_amount,'bank_product_opened','Opened virtual '||p_product_type||' product');
 return jsonb_build_object('id',v_id,'balance',v_balance,'matures_in_days',v_days,'rate',v_rate);
end $$;

create or replace function public.city_claim_bank_product(p_product_id uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_uid uuid:=auth.uid(); v_product public.city_bank_products%rowtype; v_total numeric; v_balance numeric;
begin
 if v_uid is null then raise exception 'Please sign in first.'; end if;
 select * into v_product from public.city_bank_products where id=p_product_id and player_id=v_uid for update;
 if not found then raise exception 'Bank product not found.'; end if;
 if v_product.status<>'active' then raise exception 'This product has already been paid.'; end if;
 if now()<v_product.matures_at then raise exception 'This product has not matured yet.'; end if;
 v_total:=round(v_product.principal*(1+v_product.interest_rate/100),2);
 update public.city_bank_products set status='paid',paid_at=now() where id=p_product_id;
 update public.wallets set balance=balance+v_total,updated_at=now() where player_id=v_uid returning balance into v_balance;
 insert into public.wallet_transactions(player_id,amount,transaction_type,description) values(v_uid,v_total,'bank_product_matured','Virtual principal and interest paid');
 return jsonb_build_object('paid',v_total,'balance',v_balance);
end $$;

create or replace function public.city_buy_business(p_slug text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_uid uuid:=auth.uid(); v_item public.city_business_catalog%rowtype; v_balance numeric; v_id uuid;
begin
 if v_uid is null then raise exception 'Please sign in first.'; end if;
 select * into v_item from public.city_business_catalog where slug=p_slug and is_active=true;
 if not found then raise exception 'This business is not available.'; end if;
 update public.wallets set balance=balance-v_item.price,updated_at=now() where player_id=v_uid and balance>=v_item.price returning balance into v_balance;
 if not found then raise exception 'Not enough game money for this business.'; end if;
 insert into public.businesses(owner_id,name,category,location,price,revenue,daily_income,last_income_at)
 values(v_uid,v_item.name,v_item.category,'Accra',v_item.price,0,v_item.daily_income,now()) returning id into v_id;
 insert into public.wallet_transactions(player_id,amount,transaction_type,description) values(v_uid,-v_item.price,'business_purchase','Purchased '||v_item.name);
 return jsonb_build_object('business_id',v_id,'name',v_item.name,'price',v_item.price,'daily_income',v_item.daily_income,'balance',v_balance);
end $$;

create or replace function public.city_collect_business_income()
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_uid uuid:=auth.uid(); v_total numeric:=0; v_tax numeric:=0; v_net numeric:=0; v_count integer:=0; v_balance numeric;
begin
 if v_uid is null then raise exception 'Please sign in first.'; end if;
 with due as (
   select id,daily_income,greatest(1,floor(extract(epoch from (now()-coalesce(last_income_at,created_at)))/86400))::numeric as days_due
   from public.businesses where owner_id=v_uid and daily_income>0 and now()-coalesce(last_income_at,created_at)>=interval '24 hours' for update
 ), paid as (
   update public.businesses b set revenue=b.revenue+(d.daily_income*d.days_due),last_income_at=now()
   from due d where b.id=d.id returning d.daily_income*d.days_due as amount
 ) select coalesce(sum(amount),0),count(*) into v_total,v_count from paid;
 if v_total>0 then
   v_tax:=round(v_total*0.075,2); v_net:=v_total-v_tax;
   update public.wallets set balance=balance+v_net,updated_at=now() where player_id=v_uid returning balance into v_balance;
   insert into public.wallet_transactions(player_id,amount,transaction_type,description) values(v_uid,v_total,'business_income','Gross virtual business income');
   if v_tax>0 then insert into public.wallet_transactions(player_id,amount,transaction_type,description) values(v_uid,-v_tax,'gra_virtual_tax','Virtual GRA tax at 7.5%'); end if;
 else select balance into v_balance from public.wallets where player_id=v_uid; end if;
 return jsonb_build_object('gross_income',v_total,'tax',v_tax,'income',v_net,'businesses_paid',v_count,'balance',v_balance);
end $$;

create or replace function public.city_claim_matured_investments()
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_uid uuid:=auth.uid(); v_total numeric:=0; v_count integer:=0; v_balance numeric;
begin
 if v_uid is null then raise exception 'Please sign in first.'; end if;
 with due as (
   update public.investments set status='closed'
   where player_id=v_uid and status='active' and matured_at is not null and matured_at<=now()
   returning round(principal*(1+return_rate/100),2) amount
 ) select coalesce(sum(amount),0),count(*) into v_total,v_count from due;
 if v_total>0 then
   update public.wallets set balance=balance+v_total,updated_at=now() where player_id=v_uid returning balance into v_balance;
   insert into public.wallet_transactions(player_id,amount,transaction_type,description) values(v_uid,v_total,'investment_matured','Matured virtual investments paid');
 else select balance into v_balance from public.wallets where player_id=v_uid; end if;
 return jsonb_build_object('paid',v_total,'count',v_count,'balance',v_balance);
end $$;

create or replace function public.city_rent_billboard(p_billboard_name text,p_ad_text text,p_days integer)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_uid uuid:=auth.uid(); v_price numeric; v_id uuid; v_balance numeric; v_ad text:=left(trim(coalesce(p_ad_text,'')),100);
begin
 if v_uid is null then raise exception 'Please sign in first.'; end if;
 if char_length(v_ad)<3 then raise exception 'Write an ad message with at least 3 characters.'; end if;
 if p_days=1 then v_price:=100; elsif p_days=7 then v_price:=500; elsif p_days=30 then v_price:=1500; else raise exception 'Choose 1, 7 or 30 days.'; end if;
 update public.wallets set balance=balance-v_price,updated_at=now() where player_id=v_uid and balance>=v_price returning balance into v_balance;
 if not found then raise exception 'Not enough virtual money to rent this billboard.'; end if;
 insert into public.city_billboard_rentals(player_id,billboard_name,ad_text,rental_days,price,ends_at)
 values(v_uid,left(trim(coalesce(p_billboard_name,'Accra Street Billboard')),80),v_ad,p_days,v_price,now()+(p_days||' days')::interval) returning id into v_id;
 insert into public.wallet_transactions(player_id,amount,transaction_type,description) values(v_uid,-v_price,'billboard_rental','Rented a virtual billboard for '||p_days||' days');
 return jsonb_build_object('id',v_id,'price',v_price,'balance',v_balance,'ends_at',now()+(p_days||' days')::interval);
end $$;

-- 100 in-game catalogue items across ten categories. Price scale intentionally reaches GH₵250m.
with categories(category,items) as (values
 ('Seating',array['Plastic Chair','Wooden Dining Chair','Office Chair','Accent Chair','Bar Stool','Love Seat','Two-Seater Sofa','Three-Seater Sofa','Luxury Recliner','Diamond Throne']),
 ('Bedroom',array['Foam Mattress','Single Bed Frame','Bedside Stool','Bedside Table','Small Wardrobe','Double Mattress','Queen Bed','King Bed','Walk-in Wardrobe','Gold Canopy Bed']),
 ('Living Room',array['Floor Mat','Small Rug','Curtains','Coffee Table','TV Stand','Bookshelf','Wall Art','Premium Rug','Smart Entertainment Wall','Diamond Living Room Set']),
 ('Kitchen',array['Plastic Bowl Set','Kettle','Rice Cooker','Microwave','Gas Cooker','Fridge','Deep Freezer','Kitchen Island','Luxury Cabinet Set','Gold Chef Kitchen']),
 ('Electronics',array['Phone Charger','Radio','Desk Lamp','Bluetooth Speaker','Smartphone','Tablet','Laptop','55-inch TV','Home Cinema','Diamond Smart Home System']),
 ('Transport',array['Bicycle','Used Scooter','Push Cart','Used Motorbike','City Bicycle','Used Sedan','Taxi Car','SUV','Luxury Sports Car','Gold Supercar']),
 ('Fashion',array['Basic T-Shirt','Flip-Flops','Canvas Sneakers','Denim Outfit','Traditional Kente Outfit','Designer Handbag','Premium Watch','Diamond Necklace','Haute Couture Look','Royal Diamond Collection']),
 ('Beauty',array['Comb Set','Body Lotion','Makeup Kit','Hair Dryer','Wig Stand','Salon Chair','Professional Makeup Station','Luxury Spa Bed','Private Beauty Suite','Diamond Beauty Lounge']),
 ('Leisure',array['Football','Board Game','Yoga Mat','Gaming Controller','Bicycle Trainer','Game Console','Pool Table','Jacuzzi','Private Cinema','Luxury Yacht Club Membership']),
 ('Property Decor',array['Plant Pot','Wall Clock','Small Mirror','Full-Length Mirror','Standing Fan','Wall Fan','Air Conditioner','Crystal Chandelier','Indoor Waterfall','Diamond Palace Installation'])
), numbered as (
 select c.category,x.name,row_number() over(order by c.category,x.ord) rn from categories c cross join lateral unnest(c.items) with ordinality as x(name,ord)
)
insert into public.inventory_items(name,category,price,description)
select n.name,n.category,
 case n.rn%10 when 1 then 500 when 2 then 1200 when 3 then 2500 when 4 then 5000 when 5 then 12000 when 6 then 35000 when 7 then 100000 when 8 then 750000 when 9 then 5000000 else 250000000 end,
 'Virtual '||lower(n.name)||' for your Accra Vibe lifestyle.'
from numbered n
where not exists(select 1 from public.inventory_items i where i.name=n.name and i.category=n.category);

create or replace function public.city_buy_catalogue_item(p_item_id uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_uid uuid:=auth.uid(); v_item public.inventory_items%rowtype; v_balance numeric;
begin
 if v_uid is null then raise exception 'Please sign in first.'; end if;
 select * into v_item from public.inventory_items where id=p_item_id for share;
 if not found then raise exception 'Catalogue item not found.'; end if;
 update public.wallets set balance=balance-v_item.price,updated_at=now() where player_id=v_uid and balance>=v_item.price returning balance into v_balance;
 if not found then raise exception 'Not enough virtual money for this item.'; end if;
 insert into public.player_inventory(player_id,item_id,quantity) values(v_uid,p_item_id,1)
 on conflict(player_id,item_id) do update set quantity=public.player_inventory.quantity+1;
 insert into public.wallet_transactions(player_id,amount,transaction_type,description) values(v_uid,-v_item.price,'catalogue_purchase','Bought '||v_item.name);
 return jsonb_build_object('item',v_item.name,'price',v_item.price,'balance',v_balance);
end $$;

-- Daily mission ledger (local Ghana date supplied by server timezone; no client-side reward amounts).
create table if not exists public.city_daily_missions (
 player_id uuid not null references public.players(id) on delete cascade,
 mission_date date not null default (timezone('Africa/Accra',now()))::date,
 buka_visits integer not null default 0 check (buka_visits>=0),
 gems_found integer not null default 0 check (gems_found>=0),
 claimed boolean not null default false,
 primary key(player_id,mission_date)
);
alter table public.city_daily_missions enable row level security;
drop policy if exists city_daily_missions_owner_select on public.city_daily_missions;
create policy city_daily_missions_owner_select on public.city_daily_missions for select to authenticated using (player_id=(select auth.uid()));
grant select on public.city_daily_missions to authenticated;

create or replace function public.city_progress_mission(p_mission text,p_amount integer default 1)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_uid uuid:=auth.uid(); v_row public.city_daily_missions%rowtype;
begin
 if v_uid is null then raise exception 'Please sign in first.'; end if;
 if p_amount<1 or p_amount>10 then raise exception 'Invalid mission progress.'; end if;
 insert into public.city_daily_missions(player_id,mission_date) values(v_uid,(timezone('Africa/Accra',now()))::date) on conflict do nothing;
 if p_mission='buka' then update public.city_daily_missions set buka_visits=least(1,buka_visits+p_amount) where player_id=v_uid and mission_date=(timezone('Africa/Accra',now()))::date;
 elsif p_mission='gems' then update public.city_daily_missions set gems_found=least(3000,gems_found+p_amount) where player_id=v_uid and mission_date=(timezone('Africa/Accra',now()))::date;
 else raise exception 'Unknown mission.'; end if;
 select * into v_row from public.city_daily_missions where player_id=v_uid and mission_date=(timezone('Africa/Accra',now()))::date;
 return to_jsonb(v_row);
end $$;
create or replace function public.city_claim_mission_reward()
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_uid uuid:=auth.uid(); v_row public.city_daily_missions%rowtype; v_reward numeric:=0; v_balance numeric;
begin
 if v_uid is null then raise exception 'Please sign in first.'; end if;
 select * into v_row from public.city_daily_missions where player_id=v_uid and mission_date=(timezone('Africa/Accra',now()))::date for update;
 if not found then raise exception 'Start a daily mission first.'; end if;
 if v_row.claimed then raise exception 'Today’s mission reward was already claimed.'; end if;
 if v_row.buka_visits<1 or v_row.gems_found<1750 then raise exception 'Visit the buka and find at least 1,750 gems before claiming.'; end if;
 v_reward:=300;
 update public.city_daily_missions set claimed=true where player_id=v_uid and mission_date=(timezone('Africa/Accra',now()))::date;
 update public.wallets set balance=balance+v_reward,updated_at=now() where player_id=v_uid returning balance into v_balance;
 insert into public.wallet_transactions(player_id,amount,transaction_type,description) values(v_uid,v_reward,'daily_mission_reward','Accra Vibe daily mission reward');
 return jsonb_build_object('reward',v_reward,'balance',v_balance);
end $$;

create or replace function public.city_richest_players()
returns table(username text, display_name text, level integer, balance numeric)
language sql stable security definer set search_path = '' as $$
 select p.username,p.display_name,p.level,w.balance
 from public.players p join public.wallets w on w.player_id=p.id
 where p.is_public=true
 order by w.balance desc,p.updated_at desc limit 10
$$;

-- Limit privileged RPC execution to signed-in users; functions still validate auth.uid() internally.
revoke all on function public.city_richest_players() from public, anon;
grant execute on function public.city_richest_players() to authenticated;
revoke all on function public.city_report_player(text,text) from public, anon;
revoke all on function public.city_clean_record() from public, anon;
revoke all on function public.city_pay_bail(text) from public, anon;
revoke all on function public.city_file_court_case(text,text) from public, anon;
revoke all on function public.city_open_bank_product(text,numeric) from public, anon;
revoke all on function public.city_claim_bank_product(uuid) from public, anon;
revoke all on function public.city_buy_business(text) from public, anon;
revoke all on function public.city_collect_business_income() from public, anon;
revoke all on function public.city_claim_matured_investments() from public, anon;
revoke all on function public.city_rent_billboard(text,text,integer) from public, anon;
revoke all on function public.city_buy_catalogue_item(uuid) from public, anon;
revoke all on function public.city_progress_mission(text,integer) from public, anon;
revoke all on function public.city_claim_mission_reward() from public, anon;
grant execute on function public.city_report_player(text,text) to authenticated;
grant execute on function public.city_clean_record() to authenticated;
grant execute on function public.city_pay_bail(text) to authenticated;
grant execute on function public.city_file_court_case(text,text) to authenticated;
grant execute on function public.city_open_bank_product(text,numeric) to authenticated;
grant execute on function public.city_claim_bank_product(uuid) to authenticated;
grant execute on function public.city_buy_business(text) to authenticated;
grant execute on function public.city_collect_business_income() to authenticated;
grant execute on function public.city_claim_matured_investments() to authenticated;
grant execute on function public.city_rent_billboard(text,text,integer) to authenticated;
grant execute on function public.city_buy_catalogue_item(uuid) to authenticated;
grant execute on function public.city_progress_mission(text,integer) to authenticated;
grant execute on function public.city_claim_mission_reward() to authenticated;
