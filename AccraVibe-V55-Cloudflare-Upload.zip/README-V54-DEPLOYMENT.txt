ACCRA VIBE V54 — CITY SYSTEMS + FRONTEND PACKAGE

This package continues from the existing V52/V53 site. It does not create a new Supabase project and it does not replace the existing database.

FRONTEND ADDED
- City Services entry on the home screen and phone apps.
- Bank products: virtual savings (0.5% after 7 days), 7-day bonds (2%), quick amount buttons, all-cash amount, maturity claim buttons, bail payment, and link to transaction history.
- Ghana Police Service roleplay reports, report history and five-minute jail screen/timer.
- Accra High Court roleplay case filing (GH₵50 virtual filing fee).
- EOCO-style fictional unusual-wealth notice.
- Ten virtual businesses including Trotro Bus (GH₵120,000 / GH₵1,500 gross per eligible day) and Makola Market Stall (GH₵10,000 / GH₵400 gross per eligible day).
- Passive income collection with 7.5% virtual GRA tax recorded as a separate wallet transaction.
- One hundred catalogue items in ten categories, from GH₵500 to GH₵250,000,000, with server-side purchase and wallet deduction.
- Daily buka and gem missions with server-side progress and a GH₵300 reward.
- Billboard rental for 1, 7 or 30 days.
- Forbes-style leaderboard of public profiles, ranked by virtual wallet balance.
- Dumsor Mode toggle and local mood/energy controls.
- Ghana-time date logic uses Accra/GMT; service-worker cache and manifest query are bumped to V54.

IMPORTANT DATABASE STEP
The new frontend expects the new SQL migration in `V54-CITY-SYSTEMS.sql`. It has NOT been applied to the live database from this ZIP-building step. Apply it to the existing Accra Life/Accra Vibe Supabase project before testing the new systems:
1. Open the existing project in Supabase Dashboard → SQL Editor.
2. Review `V54-CITY-SYSTEMS.sql` and run it as one script.
3. Verify the migration completed without errors; then check that the `city_*` tables and RPC functions exist.
4. Do not create a new project, delete tables, or rerun older migrations blindly.

DEPLOY FRONTEND
1. Extract the ZIP.
2. Upload the extracted site contents to the existing Cloudflare Pages project, replacing the corresponding files.
3. Keep `config.js` and the current Supabase project configuration intact.
4. Hard-refresh the site. If the installed PWA keeps old assets, remove it and reinstall so the V54 cache and icon are used.

TEST CHECKLIST
- Sign in and confirm the saved wallet amount is visible.
- Buy a low-priced catalogue item and verify wallet balance falls exactly once and a transaction appears.
- Open a virtual savings product and verify principal is deducted and listed.
- Buy the Makola stall only if the wallet has GH₵10,000; confirm it is recorded as owned. After 24 hours, collect income and verify gross income, 7.5% virtual tax and net income transactions.
- Test report/jail with a second test account only. The roleplay report places the reported player in a five-minute timer; bail is GH₵500 paid by a different account.
- File a fictional court case and verify the GH₵50 virtual fee.
- Complete both daily missions and claim the reward once.
- Rent a billboard and verify its expiry date.
- Confirm the public leaderboard only shows accounts with public profiles enabled.
- Toggle Dumsor Mode and verify the game view dims; turn it off after testing.

LIMITATIONS / HONEST STATUS
- The weekly-bill feature is currently a Ghana-time reminder, not an automatic bill debit; no bill amount was specified.
- Mood/energy sliders and Dumsor preference are device-local visuals (Dumsor preference is also synced to player settings when possible).
- The new catalogue cards are text/emoji cards, while existing furniture catalogue imagery remains in the existing Furniture Shop.
- This package includes no real-money payments, deposits, withdrawals, legal services or real police integrations. All new economy and justice features are game roleplay.
- Existing furniture/property/vehicle RPCs remain the source of truth for those purchases. The V54 catalogue and business/bank RPCs use atomic server-side wallet updates and transaction records.
