ACCRA VIBE V55 — CLOUDFLARE PAGES PRODUCTION UPLOAD

Package: AccraVibe-V55-Cloudflare-Upload.zip
Existing Cloudflare Pages project: jamila-dnm

UPLOAD STEPS (iPhone):
1. Download and extract this ZIP first (if Cloudflare's upload page requires files rather than a ZIP, select the extracted files and folders).
2. Open Cloudflare Pages and select the EXISTING project jamila-dnm.
3. Choose Production deployment, not Preview.
4. Upload the package contents from the root: index.html, app.js, styles.css, config.js, manifest.webmanifest, sw.js, assets/, admin pages, game page, and supporting files.
5. Deploy, wait for success, then open https://jamila-dnm.pages.dev and refresh. If the phone was installed to the home screen, close it fully and reopen to clear the old PWA cache.
6. Test My Ads from Phone → My Ads. Use a test account before paying for a billboard or sea plot.
7. Test /advertise on the Pages hostname after deploy. The custom accravibe.app domain requires its DNS/domain to be configured separately.

DATABASE:
The wallet default and zero-wallet repair were applied earlier. The new-user trigger now starts new accounts at GH₵1,200. The ad_slots table and city_create_ad_slot RPC were created in Supabase. See V55-WALLET-AND-ADS.sql for the schema/function reference; it has already been applied to the connected project.

SAFETY / TESTING:
All currency is virtual game money. Billboard (GH₵1,500/7 days) and Sea Plot (GH₵50/7 days) purchases use a server-side RPC that checks the user's balance. Free promotion links are also supported. End-to-end live-site tests still need to be performed after the Cloudflare upload.
