ACCRA LIFE V17 — INTERACTIVE ACCRA MAP + SLOW, REALISTIC PASSENGER-JET JOURNEY

Included in this package
- Existing Accra Life game and Supabase connection configuration.
- Interactive game-style Accra map with clickable locations and photo cards, including UPSA, University of Ghana, hostels/student homes, Accra Mall, Osu, Labadi Beach, East Legon lounges, and apartments/homes.
- Location detail pages with activities and a GO TO THIS PLACE action.
- A redesigned passenger jet (inline SVG, not an emoji) and a slower 18-second flight animation: runway roll, gentle climb, steady cruise, gradual descent, final approach, and landing.
- Existing work, travel, homes/cars, social, wallet, business, alerts, and settings features from the prior version.

IMPORTANT
This is a front-end deployment package. Creating this ZIP does NOT publish it to Netlify. The live website changes only after the package is uploaded/deployed to the correct existing Netlify site. I do not have an authenticated Netlify deployment connection in this chat, so I cannot honestly say the live site has been updated yet.

DEPLOY THE PACKAGE
1. Download this ZIP and extract it.
2. In Netlify, open the existing Accra Life site (the one that currently serves https://teal-pasca-ed171f.netlify.app/).
3. Open the site's Deploys page and use the manual deploy / deploy drop-zone option.
4. Upload the extracted site folder or a ZIP containing the four site files at its root: index.html, app.js, styles.css, config.js. Do not upload only README.txt.
5. Wait for Netlify to report that the deploy is published.
6. Open the public site in a private/incognito tab or refresh with a cache-busting reload.
7. Sign in, open Map, tap a place, and use GO TO THIS PLACE. Then open Travel and book a test trip to watch the longer flight animation.

SECURITY
config.js uses the project's public publishable Supabase key. Never put a Supabase service-role key or other secret in this public frontend package.

TEST STATUS
The app.js JavaScript syntax was checked locally with Node.js. The package contents and ZIP integrity were checked locally. I have not completed a real browser test against a live account or confirmed a Netlify deployment.

V18 — ROOM DECORATION, RESALE, LAND & TRAILERS
- Furniture pieces appear inside the room at saved positions. Drag a piece on touch or with a mouse to arrange the room; positions are saved to the player's account.
- Furniture can be sold back for 60% of the listed shop price.
- Owned properties and vehicles can be sold back for 70% of their listed price. The game asks for confirmation before each sale.
- Added land plots in Madina, East Legon and Airport City to the Supabase property catalogue.
- Added utility, covered cargo and luxury travel trailers to the vehicle catalogue. Existing trailer entries remain available too.
- Sale proceeds are added to the virtual game wallet and recorded in wallet transactions. These are in-game amounts, not real-money cashouts.
- Database RPCs created: move_furniture, sell_furniture, sell_player_property and sell_player_vehicle.
- The furniture layout, land and trailer data are in the Supabase project; this ZIP still must be deployed to Netlify to appear on the public website.

V19 — PUBLIC VENUE MEETUPS (NO INVITATION NEEDED)
- Public places now use Supabase Realtime Presence channels, so logged-in players who are simultaneously inside the same venue can appear in one another's crowd list live.
- The venue crowd puts players who are online at that venue first and labels recent database check-ins separately as "Visited recently".
- Public venue empty states no longer ask the player to invite people. They explain that the player can stay at the venue and meet people when others arrive.
- Leaving the venue/map or switching to another game tab unsubscribes the presence channel.
- Live meeting requires the updated front end to be deployed, Realtime Presence to be enabled for the Supabase project, and both players to be signed in and viewing the same venue at the same time. This is a live presence/crowd list, not yet a fully animated shared 3D world.
- No invitation is needed to meet players in public venues. Apartment invitations remain for private-home visits.

V19 TEST STATUS
- `node --check app.js` passed.
- ZIP integrity check passed.
- No full two-account live Realtime/browser test has been performed, and this package has not been deployed to Netlify.
