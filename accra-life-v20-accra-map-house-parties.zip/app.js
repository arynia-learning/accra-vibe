(() => {
  'use strict';
  const cfg = window.ACCRA_LIFE_CONFIG || {};
  if (!window.supabase || typeof window.supabase.createClient !== 'function') { const m=document.getElementById('loadFallback'); if(m)m.style.display='block'; return; }
  if (!cfg.supabaseUrl || !cfg.supabaseKey) { const m=document.getElementById('loadFallback'); if(m)m.style.display='block'; return; }
  const sb = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseKey);
  const $ = id => document.getElementById(id);
  let mode = 'signup', user = null, profile = null, activeTab = 'home', selectedRecipient = null, notificationPoll = null, lastNotificationId = null;
  let venueChannel = null, venueActivePlaceId = null, venuePeopleRefreshBusy = false;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const money = value => Number(value || 0).toLocaleString('en-GH', {minimumFractionDigits:2, maximumFractionDigits:2});
  const toast = message => { const t=$('toast'); t.textContent=message; t.classList.add('show'); clearTimeout(toast.timer); toast.timer=setTimeout(()=>t.classList.remove('show'),3200); };
  const errorText = error => error?.message || 'Something went wrong. Please try again.';
  const setBusy = (button, busy, label) => { if (!button) return; button.disabled=busy; if (busy) {button.dataset.oldLabel=button.textContent;button.textContent=label||'Please wait…';} else if(button.dataset.oldLabel){button.textContent=button.dataset.oldLabel;delete button.dataset.oldLabel;} };
  function showAuth(next='signup') { mode=next; $('landing').classList.add('hidden'); $('game').classList.add('hidden'); $('auth').classList.remove('hidden'); $('authTitle').textContent=mode==='signup'?'Create your life':'Welcome back'; $('authSub').textContent=mode==='signup'?'Choose a name. Start your story.':'Your Accra story is waiting.'; $('usernameWrap').classList.toggle('hidden',mode!=='signup'); $('password').autocomplete=mode==='signup'?'new-password':'current-password'; $('authSubmit').textContent=mode==='signup'?'Create my Accra Life':'Log in'; $('switchAuth').textContent=mode==='signup'?'I already have an account':'Create a new account'; $('authMsg').textContent=''; $('authMsg').className='msg'; }
  function showLanding(){ $('auth').classList.add('hidden'); $('game').classList.add('hidden'); $('landing').classList.remove('hidden'); }
  async function loadProfile(u){
    const result=await sb.from('players').select('*').eq('id',u.id).maybeSingle();
    if(result.error) throw result.error;
    if(result.data){profile=result.data;return profile;}
    const raw=(u.user_metadata?.display_name||u.user_metadata?.username||u.email?.split('@')[0]||'New Player').trim();
    const username=raw.toLowerCase().replace(/[^a-z0-9_]/g,'').slice(0,24)||('player_'+u.id.slice(0,8));
    const inserted=await sb.from('players').insert({id:u.id,username,display_name:raw.slice(0,80)}).select('*').single();
    if(inserted.error){const retry=await sb.from('players').select('*').eq('id',u.id).maybeSingle();if(retry.error||!retry.data)throw inserted.error;profile=retry.data;}else profile=inserted.data;
    return profile;
  }
  async function enterGame(u){
    user=u;
    try { await loadProfile(u); $('landing').classList.add('hidden');$('auth').classList.add('hidden');$('game').classList.remove('hidden');$('welcome').textContent=`Welcome, ${profile.display_name||'Player'}`; $('level').textContent=profile.level||1; $('xp').textContent=`${profile.experience||0} XP`; $('footerStatus').textContent='CONNECTED'; const loc=await sb.from('player_locations').select('zone').eq('player_id',u.id).maybeSingle(); const savedZone=loc.data?.zone||localStorage.getItem('accraLifeLocation')||'Osu, Accra'; localStorage.setItem('accraLifeLocation',savedZone); $('locationText').textContent=savedZone.toUpperCase(); $('sceneZone').textContent=savedZone.toUpperCase(); await refreshWallet(); await openTab('home'); startNotificationPolling(); }
    catch(e){console.error(e);$('game').classList.add('hidden');$('auth').classList.remove('hidden');$('authMsg').textContent=`We couldn't load your player profile: ${errorText(e)}`;$('authMsg').className='msg';}
  }
  async function refreshWallet(){ if(!user)return; const r=await sb.from('wallets').select('balance').eq('player_id',user.id).maybeSingle(); if(r.error){$('balance').textContent='—';console.warn(r.error);return;} $('balance').textContent=money(r.data?.balance); }
  async function refreshProfile(){ if(!user)return; const r=await sb.from('players').select('*').eq('id',user.id).maybeSingle();if(r.data){profile=r.data;$('welcome').textContent=`Welcome, ${profile.display_name||'Player'}`;$('level').textContent=profile.level||1;$('xp').textContent=`${profile.experience||0} XP`;} }
  function panel(html){$('panel').innerHTML=html;}
  function header(kicker,title,subtitle,side=''){return `<div class="panel-head"><div><div class="section-label">${esc(kicker)}</div><h2>${esc(title)}</h2><p class="sub">${esc(subtitle)}</p></div>${side}</div>`;}
  function empty(text){return `<div class="empty">${esc(text)}</div>`;}
  async function openTab(tab){
    if(tab!=='map'&&venueChannel)await leaveVenuePresence();
    activeTab=tab;document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));panel('<div class="loading">Loading your Accra story…</div>');
    try {
      if(tab==='home') return await renderHome();
      if(tab==='map') return await renderMap();
      if(tab==='work') return await renderWork();
      if(tab==='travel') return await renderTravel();
      if(tab==='assets') return await renderAssets();
      if(tab==='social') return await renderSocial();
      if(tab==='wallet') return await renderWallet();
      if(tab==='business') return await renderBusiness();
      if(tab==='notifications') return await renderNotifications();
      if(tab==='settings') return await renderSettings();
    } catch(e){console.error(e);panel(`${header('A LITTLE SETBACK','Could not load this section',errorText(e))}<button class="action-btn" data-reload="${esc(tab)}">Try again</button>`);}
  }
  async function renderHome(){
    const [wallet,job,home,car,travel]=await Promise.all([
      sb.from('wallets').select('balance').eq('player_id',user.id).maybeSingle(),
      sb.from('player_jobs').select('job_id,jobs(name,salary)').eq('player_id',user.id).maybeSingle(),
      sb.from('player_properties').select('property_id').eq('player_id',user.id),
      sb.from('player_cars').select('car_id').eq('player_id',user.id),
      sb.from('travel_bookings').select('id').eq('player_id',user.id)
    ]);
    panel(`${header('YOUR LIFE IN ACCRA','Your Accra, your rules','Start small, build your reputation, and make your next move.')}<div class="grid"><div class="feature-card" data-tab="work"><div class="feature-icon">💼</div><h3>Build a career</h3><p>${job.data?.jobs?.name?`Current role: ${esc(job.data.jobs.name)}`:'Find your first job and earn a salary.'}</p><span class="card-link">EXPLORE WORK ↗</span></div><div class="feature-card" data-tab="assets"><div class="feature-icon">🏡</div><h3>Own your space</h3><p>${home.data?.length||0} home(s) · ${car.data?.length||0} car(s). Work toward the life you want.</p><span class="card-link">HOMES & CARS ↗</span></div><div class="feature-card" data-tab="travel"><div class="feature-icon">🌍</div><h3>See the world</h3><p>${travel.data?.length||0} trip(s) booked. Explore Ghana and destinations beyond.</p><span class="card-link">PLAN A TRIP ↗</span></div><div class="feature-card" data-tab="social"><div class="feature-icon">🤝</div><h3>Meet your people</h3><p>Discover other players and grow your circle.</p><span class="card-link">GO SOCIAL ↗</span></div><div class="feature-card" data-tab="wallet"><div class="feature-icon">₵</div><h3>Manage your money</h3><p>Your current game balance is GH₵ ${money(wallet.data?.balance)}.</p><span class="card-link">OPEN WALLET ↗</span></div><div class="feature-card" data-tab="business"><div class="feature-icon">📈</div><h3>Think bigger</h3><p>Start a business or explore in-game investments.</p><span class="card-link">BUILD WEALTH ↗</span></div></div>`);
  }
  const ACCRA_PLACES = [
    {id:'church',name:'Church',area:'Accra',kind:'Worship',icon:'⛪',x:51,y:29,image:'https://images.unsplash.com/photo-1438032005730-c779502df39b?auto=format&fit=crop&w=900&q=82',description:'Visit a church, take part in a service, and meet other people in the community.',activities:['Attend a service','Meet the congregation','Join a community event']},
    {id:'gym',name:'Fitness Centre',area:'East Legon',kind:'Fitness',icon:'🏋️',x:88,y:49,image:'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=900&q=82',description:'Work out, improve your fitness, and meet other players.',activities:['Work out','Join a class','Meet gym members']},
    {id:'cinema',name:'Cinema',area:'Accra Mall',kind:'Entertainment',icon:'🎬',x:60,y:50,image:'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=900&q=82',description:'Catch a movie, relax, and meet people before or after the show.',activities:['Watch a movie','Buy snacks','Meet movie fans']},
    {id:'upsa',name:'UPSA',area:'Legon–Madina',kind:'University',icon:'🎓',x:27,y:23,image:'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=900&q=82',description:'Visit campus, meet students, and explore university life.',activities:['Explore campus','Meet students','Visit the hostel']},
    {id:'ug',name:'University of Ghana',area:'Legon',kind:'University',icon:'🏛️',x:65,y:16,image:'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&w=900&q=82',description:'A campus destination for study, friendship, and student activities.',activities:['Walk around campus','Meet friends','Find student events']},
    {id:'hostel',name:'Hostels & Student Homes',area:'Legon / Madina',kind:'Accommodation',icon:'🛏️',x:43,y:38,image:'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=900&q=82',description:'Find a place to stay and build your everyday routine.',activities:['View accommodation','Meet neighbours','Rest at home']},
    {id:'mall',name:'Accra Mall',area:'Tetteh Quarshie',kind:'Shopping',icon:'🛍️',x:72,y:43,image:'https://images.unsplash.com/photo-1519567241046-7f570eee3ce6?auto=format&fit=crop&w=900&q=82',description:'Spend time shopping, browsing stores, and hanging out.',activities:['Go shopping','Meet a friend','Visit a café']},
    {id:'osu',name:'Osu Oxford Street',area:'Osu',kind:'City Centre',icon:'🌆',x:42,y:61,image:'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=900&q=82',description:'Explore the busy city streets, restaurants, and social spots.',activities:['Explore the street','Visit a restaurant','Meet players']},
    {id:'labadi',name:'Labadi Beach',area:'La / Labadi',kind:'Beach',icon:'🏖️',x:72,y:76,image:'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=900&q=82',description:'Relax by the sea, take pictures, and hang out with friends.',activities:['Relax by the sea','Take photos','Meet beachgoers']},
    {id:'eastlegon',name:'East Legon Lounges',area:'East Legon',kind:'Nightlife',icon:'🥂',x:83,y:26,image:'https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&w=900&q=82',description:'Discover stylish lounges, restaurants, and nightlife venues.',activities:['Visit a lounge','Order food','Meet new people']},
    {id:'nightclub',name:'Osu Nightclub',area:'Osu',kind:'Nightlife',icon:'🎶',x:25,y:72,image:'https://images.unsplash.com/photo-1571266028243-d220c9c3b5c5?auto=format&fit=crop&w=900&q=82',description:'Step into the music, dance, meet other players, and spend a night out together.',activities:['Dance to the music','Chill with the crowd','Meet new people','Join the dance floor']},
    {id:'apartments',name:'Apartments & Homes',area:'Across Accra',kind:'Homes',icon:'🏡',x:18,y:53,image:'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=900&q=82',description:'Work toward owning a home, decorate it, and host visitors.',activities:['Browse homes','Decorate your home','Invite a guest']}
  ];
  async function renderMap(){
    await leaveVenuePresence();
    const current=localStorage.getItem('accraLifeLocation')||'Osu, Accra';
    const [partyResult,ownedResult,attendeeResult]=await Promise.all([
      sb.from('house_parties').select('id,host_id,property_id,title,party_theme,starts_at,description,status,created_at,properties(name,location)').eq('status','open').gte('starts_at',new Date(Date.now()-3*60*60*1000).toISOString()).order('starts_at',{ascending:true}).limit(30),
      sb.from('player_properties').select('property_id,properties(name,location)').eq('player_id',user.id),
      sb.from('house_party_attendees').select('party_id,player_id')
    ]);
    const parties=partyResult.error?[]:(partyResult.data||[]),owned=ownedResult.error?[]:(ownedResult.data||[]),attendees=attendeeResult.error?[]:(attendeeResult.data||[]);
    const hostIds=[...new Set(parties.map(x=>x.host_id))];let hostNames={};
    if(hostIds.length){const hs=await sb.from('players').select('id,display_name,username').in('id',hostIds);(hs.data||[]).forEach(h=>hostNames[h.id]=h.display_name||h.username||'Player');}
    const pins=ACCRA_PLACES.map(p=>`<button class="map-pin ${current.toLowerCase().includes(p.name.toLowerCase())?'is-current':''}" style="left:${p.x}%;top:${p.y}%" data-place="${p.id}" aria-label="Open ${esc(p.name)}"><span>${p.icon}</span><small>${esc(p.name)}</small></button>`).join('');
    const partyCards=parties.map(p=>{const count=attendees.filter(a=>a.party_id===p.id).length;const joined=attendees.some(a=>a.party_id===p.id&&a.player_id===user.id);const mine=p.host_id===user.id;return `<article class="party-card"><div class="party-card-top"><span class="pill">🏠 ${esc(p.party_theme||'House party')}</span><span class="party-attendee-count">👥 ${count} going</span></div><h4>${esc(p.title)}</h4><p>📍 ${esc(p.properties?.name||'Private home')} · ${esc(p.properties?.location||'Accra')}<br>Hosted by ${esc(hostNames[p.host_id]||'Player')}</p><p class="party-time">🗓 ${new Date(p.starts_at).toLocaleString([], {dateStyle:'medium',timeStyle:'short'})}</p>${p.description?`<p>${esc(p.description)}</p>`:''}${mine?`<button class="action-btn" data-cancel-party="${p.id}">Cancel my party</button>`:joined?`<button class="action-btn" data-leave-party="${p.id}">Leave party</button>`:`<button class="primary" data-join-party="${p.id}" data-party-title="${esc(p.title)}">Join house party</button>`}</article>`;}).join('');
    panel(`${header('YOUR CITY, YOUR STORY','Explore Accra','Tap a place to go there. Visit public spots, meet people, and find house parties.',`<span class="map-current-pill">📍 ${esc(current)}</span>`)}
      <div class="accra-map-shell"><div class="map-top-label"><b>ACCRA</b><span>GREATER ACCRA · GHANA</span></div><div class="accra-map-art" role="group" aria-label="Interactive illustrated map of Accra"><div class="map-water"></div><div class="map-road road-a"></div><div class="map-road road-b"></div><div class="map-road road-c"></div><div class="map-road road-d"></div><div class="map-district district-one">LEGON</div><div class="map-district district-two">EAST LEGON</div><div class="map-district district-three">OSU</div><div class="map-district district-four">LA / LABADI</div>${pins}<div class="map-compass">N<br>↑</div></div><div class="map-legend"><span><i></i> Places to explore</span><span>Tap a pin to open a location</span></div></div>
      <div class="map-place-heading"><div><div class="section-label">PICK YOUR NEXT STOP</div><h3>Places in Accra</h3></div><span class="map-count">${ACCRA_PLACES.length} destinations</span></div><div class="map-place-grid">${ACCRA_PLACES.map(p=>`<article class="map-place-card"><button class="map-photo-button" data-place="${p.id}" aria-label="View ${esc(p.name)}"><img src="${p.image}" alt="Atmosphere photo for ${esc(p.name)}" loading="lazy" onerror="this.style.display='none'"><span class="map-photo-icon">${p.icon}</span><span class="map-kind">${esc(p.kind)}</span></button><div class="map-place-copy"><h4>${esc(p.name)}</h4><p>📍 ${esc(p.area)}</p><button class="action-btn" data-place="${p.id}">View place ↗</button></div></article>`).join('')}</div>
      <section class="house-party-section"><div class="section-label">SOCIAL EVENTS</div><h3>🎉 House parties in Accra</h3><p class="sub">Find a party hosted by another player, or organise one at a property you own. Public listings mean no personal invitation is needed.</p><div class="party-grid">${partyCards||'<div class="party-empty">No upcoming house parties yet. Be the first to organise one!</div>'}</div>
      <div class="party-create-box"><h4>🏡 Organise a house party</h4>${owned.length?`<div class="party-form-grid"><div class="field"><label for="partyProperty">Your property</label><select id="partyProperty" class="control">${owned.map(o=>`<option value="${o.property_id}">${esc(o.properties?.name||'My property')} · ${esc(o.properties?.location||'Accra')}</option>`).join('')}</select></div><div class="field"><label for="partyTitle">Party name</label><input id="partyTitle" class="control" maxlength="80" placeholder="e.g. Friday Night Chill"></div><div class="field"><label for="partyTheme">Party style</label><select id="partyTheme" class="control"><option>House party</option><option>Birthday party</option><option>Game night</option><option>Pool party</option><option>Movie night</option><option>Chill & music</option></select></div><div class="field"><label for="partyStarts">Date and time</label><input id="partyStarts" class="control" type="datetime-local"></div><div class="field party-description-field"><label for="partyDescription">Description (optional)</label><input id="partyDescription" class="control" maxlength="240" placeholder="Music, snacks, dress code…"></div></div><button class="primary" data-action="create-house-party">Publish house party</button>`:'<p class="sub">You need to own a property before you can host a party. Visit Homes & Cars to buy your first place.</p><button class="action-btn" data-tab="assets">Browse properties</button>'}</div></section>
      <p class="map-disclaimer">This is an in-game map, not live GPS navigation. Venue photos are illustrative. House parties are virtual game events.</p>`);
    const dateInput=document.getElementById('partyStarts');if(dateInput){const d=new Date(Date.now()+60*60*1000);d.setMinutes(Math.ceil(d.getMinutes()/15)*15,0,0);dateInput.value=new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,16);dateInput.min=new Date(Date.now()-new Date().getTimezoneOffset()*60000).toISOString().slice(0,16);}
  }
  async function renderHouseParty(partyId){
    const pr=await sb.from('house_parties').select('id,host_id,property_id,title,party_theme,starts_at,description,status,properties(name,location)').eq('id',partyId).maybeSingle();
    if(pr.error||!pr.data){toast('This house party is no longer available.');await openTab('map');return;}
    const party=pr.data;const ar=await sb.from('house_party_attendees').select('player_id,joined_at').eq('party_id',partyId).order('joined_at');
    const ids=[...new Set([party.host_id,...(ar.data||[]).map(a=>a.player_id)])];let people=[];
    if(ids.length){const players=await sb.from('players').select('id,display_name,username,level').in('id',ids);if(!players.error)people=players.data||[];}
    const byId=new Map(people.map(x=>[x.id,x]));
    const guestCards=ids.map(id=>{const person=byId.get(id);if(!person)return '';const isHost=id===party.host_id;return `<article class="venue-person"><div class="venue-avatar">${esc((person.display_name||person.username||'P').slice(0,1).toUpperCase())}</div><div class="venue-person-copy"><b>${esc(person.display_name||person.username||'Player')}</b><small>@${esc(person.username||'player')} · Level ${person.level||1}<br>${isHost?'<span class="pill">HOST</span>':'At this party'}</small></div>${id!==user.id?`<button class="action-btn" data-party-message="${id}" data-person-name="${esc(person.display_name||person.username||'Player')}">Say hi</button>`:''}</article>`;}).join('');
    const isHost=party.host_id===user.id;
    panel(`${header('SOCIAL EVENT · YOU ARE HERE',`🎉 ${party.title}`,`${party.party_theme||'House party'} · ${party.properties?.name||'Private home'} · ${party.properties?.location||'Accra'}`,`<button class="action-btn" data-tab="map">← Back to map</button>`)}<section class="venue-scene"><img src="https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=1200&q=82" alt="House party atmosphere" onerror="this.style.display='none'"><div class="venue-scene-shade"></div><div class="venue-scene-caption"><span class="venue-live-pill">🏠 HOUSE PARTY · GUEST LIST</span><h3>${esc(party.title)}</h3><p>${esc(party.description||'Meet other players, say hello, and enjoy the party.')}</p><p>🗓 ${new Date(party.starts_at).toLocaleString([], {dateStyle:'medium',timeStyle:'short'})}</p></div></section><section class="venue-crowd"><div class="venue-crowd-head"><div><div class="section-label">THE GUESTS</div><h3>Who's at the party?</h3><p class="sub">Players who joined this party appear here. Say hi to start getting to know them.</p></div><span class="venue-count">${ids.length} ${ids.length===1?'person':'people'}</span></div><div class="venue-people-list">${guestCards||'<div class="venue-empty">No guests have joined yet.</div>'}</div><button class="action-btn" style="margin-top:12px" data-refresh-party="${partyId}">Refresh guest list</button>${isHost?`<button class="action-btn" style="margin:12px 0 0;width:100%" data-cancel-party="${partyId}">Cancel my party</button>`:`<button class="action-btn" style="margin:12px 0 0;width:100%" data-leave-party="${partyId}">Leave party</button>`}</section><p class="map-disclaimer">This is a virtual social event in Accra Life.</p>`);
  }
  function openPlace(placeId){
    const p=ACCRA_PLACES.find(x=>x.id===placeId);if(!p)return;
    document.querySelector('.place-detail-overlay')?.remove();
    const overlay=document.createElement('div');overlay.className='hire-modal-overlay place-detail-overlay';
    overlay.innerHTML=`<div class="hire-modal place-detail-modal"><button class="place-close" id="closePlace" aria-label="Close">×</button><img class="place-detail-image" src="${p.image}" alt="Illustrative scene for ${esc(p.name)}" onerror="this.style.display='none'"><div class="section-label">${esc(p.kind)} · ${esc(p.area)}</div><h2>${p.icon} ${esc(p.name)}</h2><p>${esc(p.description)}</p><div class="place-activities"><b>WHAT YOU CAN DO</b>${p.activities.map(a=>`<span>✦ ${esc(a)}</span>`).join('')}</div><button class="primary full" id="visitPlace">GO TO THIS PLACE ↗</button><p class="hire-modal-sub">This updates your in-game location. Real-world travel is not involved.</p></div>`;
    document.body.appendChild(overlay);
    const close=()=>overlay.remove();overlay.querySelector('#closePlace').onclick=close;overlay.addEventListener('click',e=>{if(e.target===overlay)close();});
    overlay.querySelector('#visitPlace').onclick=async()=>{
      const zone=`${p.name}, Accra`;localStorage.setItem('accraLifeLocation',zone);
      $('locationText').textContent=zone.toUpperCase();$('sceneZone').textContent=zone.toUpperCase();
      const coords={x:p.x/100,y:p.y/100};
      try{const saved=await sb.from('player_locations').upsert({player_id:user.id,zone,x:coords.x,y:coords.y,updated_at:new Date().toISOString()},{onConflict:'player_id'});if(saved.error)console.warn('Could not save map location:',saved.error);}catch(err){console.warn(err);}
      close();toast(`You arrived at ${p.name}!`);await renderVenue(p.id);
    };
  }
  async function leaveVenuePresence(){
    const old=venueChannel;venueChannel=null;venueActivePlaceId=null;
    if(old){try{await sb.removeChannel(old);}catch(err){console.warn('Could not leave venue presence:',err);}}
  }
  function venuePersonCard(person,online){
    const name=person.display_name||person.username||'Player';
    return `<article class="venue-person"><div class="venue-avatar">${esc(name.slice(0,1).toUpperCase())}</div><div class="venue-person-copy"><b>${esc(name)}</b><small>@${esc(person.username||'player')} · Level ${person.level||1}<br><span class="venue-live-dot" style="background:${online?'#d3f36b':'#9ba6a3'}"></span>${online?'Online here now':'Visited recently'}</small></div><div class="venue-person-actions"><button class="action-btn" data-friend="${person.id}">Add friend</button><button class="action-btn" data-venue-message="${person.id}" data-person-name="${esc(name)}">Say hi</button></div></article>`;
  }
  async function refreshVenueCrowd(placeId){
    if(venuePeopleRefreshBusy||venueActivePlaceId!==placeId||!user)return;
    venuePeopleRefreshBusy=true;
    try{
      const p=ACCRA_PLACES.find(x=>x.id===placeId);if(!p)return;
      const zone=`${p.name}, Accra`,cutoff=new Date(Date.now()-45*60*1000).toISOString();
      const byId=new Map(),onlineIds=new Set();
      if(venueChannel){
        const state=venueChannel.presenceState();
        Object.values(state||{}).flat().forEach(person=>{
          const id=person.player_id||person.id;
          if(!id||id===user.id)return;
          onlineIds.add(id);byId.set(id,{id,display_name:person.display_name,username:person.username,level:person.level||1});
        });
      }
      const locs=await sb.from('player_locations').select('player_id,updated_at').eq('zone',zone).neq('player_id',user.id).gte('updated_at',cutoff).order('updated_at',{ascending:false}).limit(40);
      if(!locs.error){
        const ids=(locs.data||[]).map(x=>x.player_id).filter(id=>!byId.has(id));
        if(ids.length){const found=await sb.from('players').select('id,display_name,username,level,experience').in('id',ids);if(!found.error)(found.data||[]).forEach(person=>byId.set(person.id,person));}
      }
      const people=[...byId.values()];
      people.sort((a,b)=>Number(onlineIds.has(b.id))-Number(onlineIds.has(a.id))||(a.display_name||a.username||'').localeCompare(b.display_name||b.username||''));
      const list=document.getElementById('venuePeopleList'),count=document.getElementById('venueCount');
      if(!list||venueActivePlaceId!==placeId)return;
      if(count)count.textContent=`${onlineIds.size} online · ${people.length} ${people.length===1?'player':'players'} seen`;
      list.innerHTML=people.length?people.map(person=>venuePersonCard(person,onlineIds.has(person.id))).join(''):`<div class="venue-empty"><div>👋</div><b>You're one of the first here!</b><p>Stay in this venue to meet other players when they arrive. When someone else opens this same place, they can appear here live—no invitation needed.</p><button class="action-btn" data-refresh-crowd="${placeId}">Check for people again</button></div>`;
    }catch(err){console.warn('Could not refresh venue crowd:',err);}
    finally{venuePeopleRefreshBusy=false;}
  }
  async function renderVenue(placeId){
    const p=ACCRA_PLACES.find(x=>x.id===placeId)||ACCRA_PLACES.find(x=>`${x.name}, Accra`===(localStorage.getItem('accraLifeLocation')||''));
    if(!p){await openTab('map');return;}
    await leaveVenuePresence();
    venueActivePlaceId=p.id;
    const activityButtons=p.activities.map((a,i)=>`<button type="button" class="venue-activity" data-place-activity="${i}" data-place-id="${p.id}">${['🎉','📸','💬','✨'][i%4]} ${esc(a)}</button>`).join('');
    panel(`${header(`${p.kind.toUpperCase()} · YOU ARE HERE` ,`${p.icon} ${p.name}`,`You have arrived in ${p.area}. Hang out here and meet other players who come to this same place. No invitation needed.`,`<button class="action-btn" data-tab="map">← Back to map</button>`)}<section class="venue-scene"><img src="${p.image}" alt="Illustrative scene at ${esc(p.name)}" onerror="this.style.display='none'"><div class="venue-scene-shade"></div><div class="venue-scene-caption"><span class="venue-live-pill">📍 YOU ARE HERE · LIVE VENUE</span><h3>${esc(p.name)}</h3><p>${esc(p.description)}</p></div></section><section class="venue-activities"><div><div class="section-label">MAKE YOUR MOVE</div><h3>What do you want to do?</h3><p class="sub">Choose an activity while you hang out here. Other players at this venue can meet you too.</p></div><div class="venue-activity-grid">${activityButtons}</div></section><section class="venue-crowd"><div class="venue-crowd-head"><div><div class="section-label">THE CROWD</div><h3>People at this place</h3><p class="sub">Players online here appear live. Recent visitors may also be shown.</p></div><span class="venue-count" id="venueCount">Finding the crowd…</span></div><div class="venue-people-list" id="venuePeopleList"><div class="venue-empty"><div>👀</div><b>Looking around…</b><p>Checking who is here now.</p></div></div></section><p class="map-disclaimer">This is an in-game social space. The game does not use real-world location tracking.</p>`);
    // Realtime Presence lets players who are in the same venue discover one another without sending invitations.
    try{
      const channel=sb.channel(`public-venue:${p.id}`,{config:{presence:{key:user.id}}})
        .on('presence',{event:'sync'},()=>{refreshVenueCrowd(p.id);})
        .on('presence',{event:'join'},()=>{refreshVenueCrowd(p.id);})
        .on('presence',{event:'leave'},()=>{refreshVenueCrowd(p.id);});
      venueChannel=channel;
      channel.subscribe(async status=>{
          if(status==='SUBSCRIBED'&&venueChannel===channel&&venueActivePlaceId===p.id){
            const tracked=await channel.track({player_id:user.id,display_name:profile?.display_name||'Player',username:profile?.username||'player',level:profile?.level||1,joined_at:new Date().toISOString()});
            if(tracked?.error)console.warn('Could not join live venue presence:',tracked.error);
            await refreshVenueCrowd(p.id);
          }
        });
    }catch(err){console.warn('Live venue presence unavailable; recent visitors will still be shown:',err);}
    await refreshVenueCrowd(p.id);
  }
  async function renderWork(){
    const [jobs,chosen]=await Promise.all([sb.from('jobs').select('*').order('salary',{ascending:false}),sb.from('player_jobs').select('job_id,jobs(name,salary,last_salary_at)').eq('player_id',user.id).maybeSingle()]);
    if(jobs.error)throw jobs.error;
    const current=chosen.data?.jobs;
    panel(`${header('CAREER & INCOME','Work in Accra','Choose a path, then claim your game salary when it becomes available.',`<button class="action-btn" data-action="salary">Claim salary</button>`)}${current?`<div class="stat-card" style="margin-bottom:14px"><span class="label">YOUR CURRENT JOB</span><strong>${esc(current.name)}</strong><p class="sub">GH₵ ${money(current.salary)} per hour in game</p></div>`:''}<div class="grid">${(jobs.data||[]).map(j=>`<article class="item-card"><span class="pill">${esc(j.category||'Career')}</span><h3>${esc(j.name)}</h3><p>${esc(j.description||'Work hard and grow your career in Accra.')}</p><div class="price">GH₵ ${money(j.salary)} <small style="color:var(--muted);font-size:10px">/ hour</small></div><button data-hire="${j.id}" ${chosen.data?.job_id===j.id?'disabled':''}>${chosen.data?.job_id===j.id?'Current job':'Choose this job'}</button></article>`).join('')||empty('No jobs are available yet.')}</div>`);
  }
  async function renderTravel(){
    const [destinations,bookings]=await Promise.all([sb.from('travel_destinations').select('*').order('base_fare'),sb.from('travel_bookings').select('id,travel_class,fare,status,booked_at,travel_destinations(name,country,city)').eq('player_id',user.id).order('booked_at',{ascending:false}).limit(6)]);
    if(destinations.error)throw destinations.error;
    const classes=['Economy','Premium Economy','Business','First Class'];
    panel(`${header('GET OUT THERE','Explore beyond Accra','Pick a destination and travel class. Fares are paid from your in-game wallet.')}<div class="field-inline"><label for="travelClass" class="sub">Travel class</label><select id="travelClass">${classes.map(c=>`<option>${c}</option>`).join('')}</select></div><div class="grid">${(destinations.data||[]).map(d=>`<article class="item-card"><span class="pill">${esc(d.region||'International')}</span><h3>✈ ${esc(d.city||d.name)}</h3><p>${esc(d.country||'Destination')} ${d.airport_code?`· ${esc(d.airport_code)}`:''}<br>${Number(d.distance_km||0).toLocaleString()} km from home</p><div class="price">From GH₵ ${money(d.base_fare)}</div><button data-dest="${d.id}">Book this trip</button></article>`).join('')||empty('Destinations are being prepared.')}</div><h3 style="margin:24px 0 8px;font-size:15px">Your recent trips</h3><div class="tx-list">${(bookings.data||[]).map(b=>`<div class="tx"><div><b>${esc(b.travel_destinations?.city||b.travel_destinations?.name||'Trip')}</b><small>${esc(b.travel_class)} · ${esc(b.status)} · ${b.booked_at?new Date(b.booked_at).toLocaleDateString():''}</small></div><strong class="negative">−GH₵ ${money(b.fare)}</strong></div>`).join('')||empty('Your booked trips will appear here.')}</div>`);
  }
  async function renderAssets(){
    const [properties,cars,ownedP,ownedC,furniture,ownedFurniture,visits,players]=await Promise.all([
      sb.from('properties').select('*').order('price'),
      sb.from('cars').select('*').order('price'),
      sb.from('player_properties').select('property_id,properties(name,location,property_type)').eq('player_id',user.id),
      sb.from('player_cars').select('car_id').eq('player_id',user.id),
      sb.from('furniture_items').select('*').order('price'),
      sb.from('player_furniture').select('id,item_id,quantity,pos_x,pos_y,furniture_items(name,category,icon)').eq('player_id',user.id),
      sb.from('apartment_visits').select('*').or(`owner_id.eq.${user.id},guest_id.eq.${user.id}`).order('created_at',{ascending:false}).limit(30),
      sb.from('players').select('id,display_name,username').neq('id',user.id).order('display_name').limit(100)
    ]);
    if(properties.error)throw properties.error;if(cars.error)throw cars.error;
    const pids=new Set((ownedP.data||[]).map(x=>x.property_id)),cids=new Set((ownedC.data||[]).map(x=>x.car_id));
    const props=ownedP.data||[], guests=players.data||[], visitRows=visits.data||[];
    const hostIds=[...new Set(visitRows.map(v=>v.owner_id).filter(id=>id!==user.id))];
    const guestIds=[...new Set(visitRows.map(v=>v.guest_id).filter(id=>id!==user.id))];
    const allIds=[...new Set([...hostIds,...guestIds])];
    let nameMap={};
    if(allIds.length){const names=await sb.from('players').select('id,display_name,username').in('id',allIds);(names.data||[]).forEach(p=>nameMap[p.id]=p.display_name||p.username||'Player');}
    const propIds=[...new Set(visitRows.map(v=>v.property_id))];let propMap={};
    if(propIds.length){const names=await sb.from('properties').select('id,name,location').in('id',propIds);(names.data||[]).forEach(p=>propMap[p.id]=p);}
    const ownedRoom=props[0];
    const roomFurniture=(ownedFurniture.data||[]).map((f,i)=>`<button type="button" class="room-piece" data-drag-furniture="${f.id}" style="left:${Number(f.pos_x??(12+(i%5)*17))}%;bottom:${Number(f.pos_y??12)}%" title="Drag to arrange: ${esc(f.furniture_items?.name||'Furniture')}" aria-label="Move ${esc(f.furniture_items?.name||'Furniture')}">${esc(f.furniture_items?.icon||'🪑')}</button>`).join('');
    const incoming=visitRows.filter(v=>v.guest_id===user.id&&v.status==='pending');
    const outgoing=visitRows.filter(v=>v.owner_id===user.id&&v.status==='pending');
    const accepted=visitRows.filter(v=>(v.owner_id===user.id||v.guest_id===user.id)&&v.status==='accepted');
    const apartmentHtml=`<section class="apartment-section"><div class="section-label">YOUR PRIVATE SPACE</div><h3 style="font-size:18px;margin:0 0 7px">🏡 Apartment life</h3><p class="sub" style="margin-bottom:14px">Buy a home, furnish your room, then invite friends over. Invitations appear in their notifications.</p>
      ${ownedRoom?`<div class="apartment-room"><div class="room-window"><span></span><span></span><span></span></div><div class="room-wall-art">ACCRA<br><small>HOME</small></div><div class="room-floor"></div><div class="room-sofa">🛋️</div><div class="room-plant">🪴</div>${roomFurniture}<div class="room-label"><b>${esc(ownedRoom.properties?.name||'Your apartment')}</b><small>${esc(ownedRoom.properties?.location||'Accra')} · Your home</small></div></div>
      <div class="two-col" style="margin-top:12px"><div class="stat-card"><span class="label">INVITE SOMEONE OVER</span><div class="field"><label for="guestSelect-${ownedRoom.property_id}">Choose a player</label><select id="guestSelect-${ownedRoom.property_id}" class="control"><option value="">Choose a friend</option>${guests.map(g=>`<option value="${g.id}">${esc(g.display_name||g.username||'Player')}</option>`).join('')}</select></div><button class="action-btn" data-invite-property="${ownedRoom.property_id}">Send apartment invitation</button></div><div class="stat-card"><span class="label">MAKE IT YOURS</span><p class="sub" style="margin:10px 0">Furniture owned: ${(ownedFurniture.data||[]).reduce((n,f)=>n+Number(f.quantity||1),0)}. Add pieces to make your apartment feel like home.</p><div class="room-inventory">${(ownedFurniture.data||[]).map(f=>`<div class="owned-furniture-row"><span>${esc(f.furniture_items?.icon||'🪑')} ${esc(f.furniture_items?.name||'Furniture')} ×${f.quantity||1}</span><button class="mini-action" data-sell-furniture="${f.id}">Sell · 60%</button></div>`).join('')||'<span class="sub">Your room is waiting for its first furniture.</span>'}</div><p class="sub" style="margin-top:8px">Move furniture by dragging it around the room. Your arrangement saves automatically.</p></div></div>
      <h4 style="font-size:14px;margin:22px 0 10px">Furniture shop</h4><div class="grid">${(furniture.data||[]).map(f=>`<article class="item-card"><div class="feature-icon">${esc(f.icon||'🪑')}</div><h3>${esc(f.name)}</h3><p>${esc(f.category||'Home decor')}</p><div class="price">GH₵ ${money(f.price)}</div><button data-buy-furniture="${f.id}">Buy & add to room</button></article>`).join('')||empty('More furniture is coming soon.')}</div>`:`<div class="empty">You need to own an apartment before you can furnish it or invite guests.</div><p class="sub">Purchase a property above to unlock your private apartment.</p>`}
      <h4 style="font-size:14px;margin:22px 0 10px">Apartment invitations</h4>
      ${incoming.map(v=>`<div class="tx"><div><b>🏡 ${esc(nameMap[v.owner_id]||'A player')} invited you over</b><small>${esc(propMap[v.property_id]?.name||'Apartment')} · ${new Date(v.created_at).toLocaleString()}</small></div><div class="invite-actions"><button class="action-btn" data-visit-response="accepted" data-visit-id="${v.id}">Accept</button><button class="action-btn" data-visit-response="declined" data-visit-id="${v.id}">Decline</button></div></div>`).join('')||'<p class="sub">No incoming apartment invitations.</p>'}
      ${outgoing.map(v=>`<div class="tx"><div><b>Invitation sent to ${esc(nameMap[v.guest_id]||'Player')}</b><small>${esc(propMap[v.property_id]?.name||'Apartment')} · Waiting for a response</small></div><span class="pill">Pending</span></div>`).join('')}
      ${accepted.map(v=>{const other=v.owner_id===user.id?nameMap[v.guest_id]:nameMap[v.owner_id];return `<div class="tx"><div><b>🏠 ${v.owner_id===user.id?'Your guest: ':'You can visit: '}${esc(other||'Player')}</b><small>${esc(propMap[v.property_id]?.name||'Apartment')} · Invitation accepted</small></div><button class="action-btn" data-open-apartment="${v.id}">Visit apartment</button></div>`}).join('')}
      </section>`;
    panel(`${header('BUILD YOUR DREAM LIFE','Homes & cars','Buy a place, make it your own, and invite other players over.')}<h3 style="font-size:15px;margin:12px 0">🏡 Properties</h3><div class="grid">${(properties.data||[]).map(x=>`<article class="item-card"><span class="pill">${esc(x.property_type)}</span><h3>${esc(x.name)}</h3><p>${esc(x.location||'Accra')}<br>${esc(x.description||'A place to call your own.')}</p><div class="price">GH₵ ${money(x.price)}</div>${pids.has(x.id)?`<button class="action-btn" data-sell-property="${x.id}">Sell · receive 70%</button>`:`<button data-buy-property="${x.id}">Purchase property</button>`}</article>`).join('')||empty('Properties coming soon. ')} </div><h3 style="font-size:15px;margin:25px 0 12px">🚘 Vehicles & trailers</h3><div class="grid">${(cars.data||[]).map(x=>`<article class="item-card"><span class="pill">${esc(x.category||'Vehicle')}</span><h3>${esc(x.brand||'')} ${esc(x.name)}</h3><p>${String(x.category||'').toLowerCase().includes('trailer')?'Own a trailer for your hauling and travel-life collection.':'Get around Accra in style.'}</p><div class="price">GH₵ ${money(x.price)}</div>${cids.has(x.id)?`<button class="action-btn" data-sell-vehicle="${x.id}">Sell · receive 70%</button>`:`<button data-buy-car="${x.id}">Buy ${String(x.category||'Vehicle').toLowerCase()}</button>`}</article>`).join('')||empty('Cars coming soon.')}</div>${apartmentHtml}`);
  }
  async function renderSocial(){
    const [players,friends]=await Promise.all([sb.from('players').select('id,display_name,username,level,experience').neq('id',user.id).order('level',{ascending:false}).limit(30),sb.from('friendships').select('id,requester_id,addressee_id,status,requester:players!friendships_requester_id_fkey(display_name,username),addressee:players!friendships_addressee_id_fkey(display_name,username)').or(`requester_id.eq.${user.id},addressee_id.eq.${user.id}`).order('created_at',{ascending:false}).limit(30)]);
    const rels=friends.data||[];const related=new Set(rels.map(f=>f.requester_id===user.id?f.addressee_id:f.requester_id));
    const recentMessages=await sb.from('messages').select('id,sender_id,recipient_id,body,created_at,read_at').or(`sender_id.eq.${user.id},recipient_id.eq.${user.id}`).order('created_at',{ascending:false}).limit(12);
    const messagePlayers=players.data||[];
    panel(`${header('PEOPLE & COMMUNITY','Your social circle','Meet players, send friend requests and message each other.')}<div class="stat-card message-compose"><span class="label">SEND A MESSAGE</span><div class="field"><label for="messageRecipient">Choose a player</label><select id="messageRecipient" class="control"><option value="">Choose a player</option>${messagePlayers.map(p=>`<option value="${p.id}">${esc(p.display_name||p.username||'Player')}</option>`).join('')}</select></div><div class="field"><label for="messageBody">Your message</label><textarea id="messageBody" class="control" maxlength="1000" rows="3" placeholder="Write a message…"></textarea></div><button class="action-btn" data-action="send-message">Send message</button></div><h3 style="font-size:15px;margin:24px 0 10px">Recent messages</h3><div class="tx-list">${(recentMessages.data||[]).map(m=>{const other=messagePlayers.find(p=>p.id===(m.sender_id===user.id?m.recipient_id:m.sender_id));return `<div class="tx"><div><b>${m.sender_id===user.id?'You → ':''}${esc(other?.display_name||other?.username||'Player')}</b><small>${esc(m.body)}<br>${m.created_at?new Date(m.created_at).toLocaleString():''}</small></div><span class="pill">${m.sender_id===user.id?'Sent':(m.read_at?'Read':'Received')}</span></div>`}).join('')||empty('Your conversations will appear here.')}</div><h3 style="font-size:15px;margin:24px 0 10px">Discover players</h3><div class="grid">${messagePlayers.map(p=>{const rel=rels.find(f=>f.requester_id===p.id||f.addressee_id===p.id);let label='Add friend',disabled=false;if(rel){if(rel.status==='accepted'){label='Friends';disabled=true;}else if(rel.status==='pending'){label=rel.requester_id===user.id?'Request sent':'Respond in requests';disabled=true;}}return `<article class="item-card"><div class="feature-icon">👤</div><h3>${esc(p.display_name||p.username||'Player')}</h3><p>@${esc(p.username||'player')}<br>Level ${p.level||1} · ${p.experience||0} XP</p><button data-friend="${p.id}" ${disabled?'disabled':''}>${label}</button></article>`}).join('')||empty('You are one of the first players here. Invite a friend to join you!')}</div><h3 style="font-size:15px;margin:24px 0 10px">Friend requests & connections</h3><div class="tx-list">${rels.map(f=>{const incoming=f.addressee_id===user.id&&f.status==='pending';const name=f.requester_id===user.id?(f.addressee?.display_name||f.addressee?.username):(f.requester?.display_name||f.requester?.username);return `<div class="tx"><div><b>${esc(name||'Player')}</b><small>${esc(f.status)}${incoming?' · incoming request':''}</small></div>${incoming?`<button class="action-btn" data-accept-friend="${f.id}">Accept</button>`:''}</div>`}).join('')||empty('No friend requests yet.')}</div>`);
  }
  async function renderWallet(){
    const [wallet,tx]=await Promise.all([sb.from('wallets').select('balance').eq('player_id',user.id).maybeSingle(),sb.from('wallet_transactions').select('*').eq('player_id',user.id).order('created_at',{ascending:false}).limit(20)]);
    if(wallet.error)throw wallet.error;
    const players=await sb.from('players').select('id,display_name,username').neq('id',user.id).order('display_name').limit(100);
    panel(`${header('YOUR MONEY','Game wallet','This balance is virtual game currency. It is not real cash and cannot currently be withdrawn.')}<div class="two-col"><div class="stat-card"><span class="label">AVAILABLE GAME BALANCE</span><strong>GH₵ ${money(wallet.data?.balance)}</strong><p class="sub" style="margin-top:8px">Earn in-game salary, manage spending and keep track of your moves.</p></div><div class="stat-card"><span class="label">PLAYER-TO-PLAYER TRANSFER</span><div class="field" style="margin:12px 0"><label for="recipientSelect">Send to a player</label><select id="recipientSelect" class="control"><option value="">Choose a player</option>${(players.data||[]).map(p=>`<option value="${p.id}">${esc(p.display_name||p.username)}</option>`).join('')}</select></div><div class="field-inline"><input id="transferAmount" type="number" min="0.01" step="0.01" placeholder="Amount (GH₵)"><input id="transferNote" maxlength="100" placeholder="Note (optional)"></div><button class="action-btn" data-action="transfer">Send game money</button></div></div><h3 style="font-size:15px;margin:24px 0 8px">Recent transactions</h3><div class="tx-list">${(tx.data||[]).map(t=>`<div class="tx"><div><b>${esc(t.description||t.transaction_type||'Transaction')}</b><small>${t.created_at?new Date(t.created_at).toLocaleString():''}</small></div><strong class="${Number(t.amount)>=0?'positive':'negative'}">${Number(t.amount)>=0?'+':'−'}GH₵ ${money(Math.abs(Number(t.amount)))}</strong></div>`).join('')||empty('Your game transactions will appear here.')}</div>`);
  }
  async function renderNotifications(){
    const r=await sb.from('notifications').select('*').eq('player_id',user.id).order('created_at',{ascending:false}).limit(50);
    if(r.error) throw r.error;
    const rows=r.data||[];
    const unread=rows.filter(n=>!n.read_at).map(n=>n.id);
    if(unread.length){const upd=await sb.from('notifications').update({read_at:new Date().toISOString()}).in('id',unread).eq('player_id',user.id);if(upd.error)console.warn(upd.error);}
    updateNotificationBadge(0);
    panel(`${header('YOUR ACTIVITY','Notifications','Messages, money transfers, friend requests and other important updates.')}<div class="tx-list">${rows.map(n=>`<div class="tx notification-row ${n.read_at?'':'unread'}"><div><b>${esc(n.title||'Accra Life update')}</b><small>${esc(n.body||'')}<br>${n.created_at?new Date(n.created_at).toLocaleString():''}</small></div><span class="pill">${esc(n.type||'update')}</span></div>`).join('')||empty('You’re all caught up. New messages and money transfers will appear here.')}</div>`);
  }
  async function renderSettings(){
    const r=await sb.from('player_settings').select('notifications_enabled').eq('player_id',user.id).maybeSingle();
    if(r.error)throw r.error;
    const enabled=r.data?.notifications_enabled!==false;
    panel(`${header('YOUR ACCOUNT','Settings','Manage your profile, security and in-game notification preferences.')}<div class="two-col"><div class="stat-card"><span class="label">PROFILE</span><div class="field"><label for="settingsDisplayName">Display name</label><input id="settingsDisplayName" class="control" maxlength="80" value="${esc(profile?.display_name||'')}" /></div><button class="action-btn" data-action="save-display-name">Save display name</button><div class="field"><label>Email address</label><input class="control" value="${esc(user?.email||'')}" disabled /></div><div class="field"><label for="settingsEmail">Change email address</label><input id="settingsEmail" class="control" type="email" placeholder="New email address" /></div><button class="action-btn" data-action="change-email">Request email change</button><p class="sub" style="margin-top:8px">Supabase may email you a confirmation link before the new address takes effect.</p></div><div class="stat-card"><span class="label">SECURITY & NOTIFICATIONS</span><div class="field"><label for="settingsPassword">New password</label><input id="settingsPassword" class="control" type="password" minlength="6" placeholder="At least 6 characters" /></div><button class="action-btn" data-action="change-password">Update password</button><hr style="border:0;border-top:1px solid var(--line);margin:22px 0"><label class="settings-toggle"><input id="notificationsEnabled" type="checkbox" ${enabled?'checked':''}><span><b>In-game notifications</b><small>Receive alerts for messages, money received and friend requests.</small></span></label><button class="action-btn" data-action="save-settings" style="margin-top:16px">Save notification settings</button><hr style="border:0;border-top:1px solid var(--line);margin:22px 0"><button class="action-btn danger-btn" data-action="settings-logout">Log out of Accra Life</button></div></div>`);
  }
  function updateNotificationBadge(count){const el=$('notificationCount');if(!el)return;el.textContent=String(count);el.classList.toggle('has-count',count>0);}
  async function pollNotifications(showNew=false){
    if(!user)return;
    const settings=await sb.from('player_settings').select('notifications_enabled').eq('player_id',user.id).maybeSingle();
    if(settings.data?.notifications_enabled===false){updateNotificationBadge(0);return;}
    const r=await sb.from('notifications').select('id,title,body,type,created_at').eq('player_id',user.id).is('read_at',null).order('created_at',{ascending:false}).limit(20);
    if(r.error){console.warn(r.error);return;}
    const rows=r.data||[];updateNotificationBadge(rows.length);
    if(showNew&&rows.length){const newest=rows[0];if(lastNotificationId&&newest.id!==lastNotificationId){toast(`${newest.title||'New Accra Life notification'}${newest.body?' — '+newest.body:''}`);}lastNotificationId=newest.id;}
    else if(rows.length&&!lastNotificationId){lastNotificationId=rows[0].id;}
  }
  function startNotificationPolling(){if(notificationPoll)clearInterval(notificationPoll);lastNotificationId=null;pollNotifications(false);notificationPoll=setInterval(()=>pollNotifications(true),12000);}
  async function renderBusiness(){
    const [owned,investments]=await Promise.all([sb.from('businesses').select('*').eq('owner_id',user.id).order('created_at',{ascending:false}),sb.from('investments').select('*').eq('player_id',user.id).order('created_at',{ascending:false})]);
    panel(`${header('ENTREPRENEURSHIP','Build something of your own','Businesses and investments use game currency. Spend carefully; this is a simulation.')}<div class="two-col"><div class="stat-card"><span class="label">START A BUSINESS</span><div class="field"><label for="bizName">Business name</label><input id="bizName" class="control" maxlength="60" placeholder="e.g. Jamilatu’s Boutique"></div><div class="field-inline"><select id="bizCategory" class="control"><option>Fashion</option><option>Food & drink</option><option>Transport</option><option>Beauty</option><option>Technology</option><option>Retail</option><option>Entertainment</option></select><select id="bizLocation" class="control"><option>Osu</option><option>East Legon</option><option>Madina</option><option>Airport</option><option>Labadi</option><option>Accra Central</option></select></div><div class="field"><label for="bizPrice">Startup cost (GH₵)</label><input id="bizPrice" class="control" type="number" min="100" step="50" value="500"></div><button class="action-btn" data-action="create-business">Launch business</button></div><div class="stat-card"><span class="label">IN-GAME INVESTMENT</span><div class="field"><label for="assetName">Investment name</label><input id="assetName" class="control" maxlength="60" placeholder="e.g. Local food venture"></div><div class="field-inline"><input id="investAmount" class="control" type="number" min="10" step="10" placeholder="Principal GH₵"><input id="investRate" class="control" type="number" min="0" max="100" step="1" value="5" placeholder="Return %"></div><div class="field"><label for="investDays">Game holding period</label><select id="investDays" class="control"><option value="1">1 day</option><option value="7" selected>7 days</option><option value="30">30 days</option></select></div><button class="action-btn" data-action="create-investment">Make investment</button><p class="sub" style="margin-top:9px">Returns are game mechanics, not real-world financial advice.</p></div></div><h3 style="font-size:15px;margin:24px 0 10px">Your businesses</h3><div class="grid">${(owned.data||[]).map(b=>`<article class="item-card"><span class="pill">${esc(b.category)}</span><h3>${esc(b.name)}</h3><p>${esc(b.location||'Accra')}<br>Game revenue: GH₵ ${money(b.revenue)}</p><div class="price">Startup: GH₵ ${money(b.price)}</div></article>`).join('')||empty('Your first business could be listed here.')}</div><h3 style="font-size:15px;margin:24px 0 10px">Your investments</h3><div class="tx-list">${(investments.data||[]).map(i=>`<div class="tx"><div><b>${esc(i.asset_name)}</b><small>${esc(i.status)} · ${i.matured_at?`Matures ${new Date(i.matured_at).toLocaleDateString()}`:'Active'}</small></div><strong>GH₵ ${money(i.principal)}</strong></div>`).join('')||empty('No investments yet.')}</div>`);
  }
  async function doRpc(name,args,success,refresh=true){const r=await sb.rpc(name,args);if(r.error){toast(errorText(r.error));return false;}toast(success);if(refresh){await refreshWallet();await refreshProfile();await openTab(activeTab);}return true;}
  function showFlightExperience(destination,travelClass,booking){
    return new Promise(resolve=>{
      document.querySelector('.flight-overlay')?.remove();
      const city=destination.city||booking.destination||destination.name||'your destination';
      const country=destination.country||booking.country||'Destination';
      const fare=booking.fare;
      const overlay=document.createElement('div');
      overlay.className='hire-modal-overlay flight-overlay';
      overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-labelledby','flightTitle');
      overlay.innerHTML=`<div class="flight-modal">
        <div class="flight-topline"><span class="section-label">ACCRA LIFE AIR</span><span class="flight-class">${esc(travelClass)}</span></div>
        <h2 id="flightTitle">Accra <span>→</span> ${esc(city)}</h2>
        <p class="flight-subtitle" id="flightStatus" aria-live="polite">Your flight is preparing for takeoff…</p>
        <div class="flight-scene" id="flightScene"><div class="flight-sun"></div><div class="flight-cloud cloud-one">☁</div><div class="flight-cloud cloud-two">☁</div><div class="flight-cloud cloud-three">☁</div><div class="flight-route-line"></div><div class="flight-plane" role="img" aria-label="Passenger jet taxiing, taking off, cruising and landing"><svg viewBox="0 0 180 70" aria-hidden="true" focusable="false"><defs><linearGradient id="jetBody" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#b8c9d0"/></linearGradient><linearGradient id="jetWing" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#dce7eb"/><stop offset="1" stop-color="#758e9b"/></linearGradient></defs><path class="jet-wing-back" d="M70 31 L37 7 Q34 5 37 14 L52 36 Z" fill="#718894"/><path d="M27 31 L7 17 Q3 15 5 23 L16 39 Z" fill="#718894"/><path d="M68 38 L34 63 Q31 66 38 65 L91 43 Z" fill="url(#jetWing)" stroke="#8299a2" stroke-width="1"/><path d="M122 36 L158 50 Q162 52 159 45 L143 32 Z" fill="url(#jetWing)" stroke="#8299a2" stroke-width="1"/><path d="M8 34 Q12 30 22 30 L146 30 Q163 30 175 35 Q163 40 146 40 L22 40 Q12 40 8 36 Z" fill="url(#jetBody)" stroke="#7e959f" stroke-width="1.1"/><path d="M150 31 L174 35 L150 39 Z" fill="#e7eff2"/><path d="M18 31 L9 18 Q7 15 11 17 L35 30 Z" fill="#dce7eb" stroke="#8299a2" stroke-width="1"/><path d="M24 30 L30 10 Q31 7 34 10 L45 31 Z" fill="#f2f6f7" stroke="#8299a2" stroke-width="1"/><path d="M26 32 L36 32 L36 38 L26 38 Z" fill="#6d8793"/><path d="M42 33 L135 33" stroke="#d7a56c" stroke-width="2"/><g fill="#526e7b"><rect x="48" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="56" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="64" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="72" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="80" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="88" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="96" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="104" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="112" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="120" y="31.2" width="3.5" height="2.2" rx="1"/><rect x="128" y="31.2" width="3.5" height="2.2" rx="1"/></g><path d="M18 36 L22 36" stroke="#fff" stroke-width="2"/><g class="jet-engines"><ellipse cx="66" cy="43" rx="8" ry="3.4" fill="#647e8a"/><ellipse cx="66" cy="43" rx="4.3" ry="2" fill="#233c49"/><ellipse cx="110" cy="27" rx="8" ry="3.4" fill="#647e8a"/><ellipse cx="110" cy="27" rx="4.3" ry="2" fill="#233c49"/></g><g class="jet-gear"><path d="M54 39 L53 48 M119 39 L120 47" stroke="#344c57" stroke-width="2"/><circle cx="53" cy="49" r="2.4" fill="#243b46"/><circle cx="120" cy="48" r="2.4" fill="#243b46"/></g><path d="M142 33 L150 35 L142 37" fill="#526f7b"/></svg></div><div class="flight-airport from-airport"><b>ACC</b><small>ACCRA</small></div><div class="flight-airport to-airport"><b>${esc((destination.airport_code||city.slice(0,3)).toUpperCase())}</b><small>${esc(city.toUpperCase())}</small></div><div class="flight-runway"></div></div>
        <div class="flight-progress"><span id="flightProgress"></span></div>
        <div class="flight-details"><div><small>TRAVEL CLASS</small><b>${esc(travelClass)}</b></div><div><small>TICKET</small><b>GH₵ ${money(fare)}</b></div><div><small>DESTINATION</small><b>${esc(country)}</b></div></div>
        <p class="flight-note" id="flightNote">Please fasten your seat belt. Your journey is underway.</p>
        <button type="button" class="primary full" id="flightContinue" disabled>Flying…</button>
        <button type="button" class="flight-skip" id="flightSkip">Skip animation</button>
      </div>`;
      document.body.appendChild(overlay);
      const status=overlay.querySelector('#flightStatus'),note=overlay.querySelector('#flightNote'),continueBtn=overlay.querySelector('#flightContinue'),plane=overlay.querySelector('.flight-plane'),progress=overlay.querySelector('#flightProgress');
      let ended=false,stageTimer=[];
      const arrive=()=>{
        if(ended)return;ended=true;stageTimer.forEach(clearTimeout);
        overlay.querySelector('#flightScene').classList.add('landed');
        status.textContent=`Welcome to ${city}!`;note.textContent='You have landed safely. Your Accra Life location has been updated.';
        continueBtn.disabled=false;continueBtn.textContent=`Arrive in ${city}`;
        overlay.querySelector('#flightSkip').style.display='none';
        progress.style.width='100%';
      };
      const close=async()=>{
        if(!ended){arrive();}
        overlay.remove();
        $('locationText').textContent=`${city.toUpperCase()}${country&&country!=='Ghana'?', '+country.toUpperCase():''}`;
        $('sceneZone').textContent=`${city.toUpperCase()}, ${country.toUpperCase()}`;
        $('footerStatus').textContent='LANDED';
        await refreshWallet();await refreshProfile();await openTab('travel');resolve();
      };
      continueBtn.addEventListener('click',close);
      overlay.querySelector('#flightSkip').addEventListener('click',arrive);
      overlay.addEventListener('click',e=>{if(e.target===overlay&&ended)close();});
      stageTimer.push(setTimeout(()=>{status.textContent='Taxiing on the runway…';note.textContent='The passenger jet is lining up and building speed for takeoff.';},1200));
      stageTimer.push(setTimeout(()=>{status.textContent='Taking off from Accra…';note.textContent='The nose lifts gently as the aircraft leaves the runway and climbs.';},3500));
      stageTimer.push(setTimeout(()=>{status.textContent=`In the air · En route to ${city}`;note.textContent='The aircraft settles into a steady cruise while clouds drift past the windows.';},6500));
      stageTimer.push(setTimeout(()=>{status.textContent='Beginning descent…';note.textContent=`The jet is descending gradually toward ${city} airport.`;},13500));
      stageTimer.push(setTimeout(()=>{status.textContent='On final approach…';note.textContent='The runway is ahead. The aircraft is lining up for a smooth landing.';},16000));
      stageTimer.push(setTimeout(arrive,18000));
      // The animation is intentionally slower, with a runway roll, gentle climb, cruise, descent and touchdown.
      const started=Date.now();const progressTimer=setInterval(()=>{if(ended){clearInterval(progressTimer);return;}progress.style.width=Math.min(98,((Date.now()-started)/18000)*100)+'%';},100);
    });
  }
  function showHireConfirmation(jobName,salary){
    document.querySelector('.hire-modal-overlay')?.remove();
    const overlay=document.createElement('div');
    overlay.className='hire-modal-overlay';
    overlay.setAttribute('role','dialog');
    overlay.setAttribute('aria-modal','true');
    overlay.setAttribute('aria-labelledby','hireModalTitle');
    overlay.innerHTML=`<div class="hire-modal"><div class="hire-modal-check">✓</div><div class="section-label">A NEW CHAPTER BEGINS</div><h2 id="hireModalTitle">Congratulations, ${esc(profile?.display_name||'Arria')}!</h2><p>You've been hired as <strong>${esc(jobName)}</strong>.</p><p class="hire-modal-sub">Your career in Accra starts now. Keep building your reputation and growing your wallet.</p>${salary!=null?`<div class="hire-modal-salary">GH₵ ${money(salary)} <small>per hour in game</small></div>`:''}<button type="button" class="primary full" id="hireModalContinue">Continue playing</button></div>`;
    document.body.appendChild(overlay);
    const close=()=>overlay.remove();
    overlay.querySelector('#hireModalContinue').addEventListener('click',close);
    overlay.addEventListener('click',e=>{if(e.target===overlay)close();});
    overlay.querySelector('#hireModalContinue').focus();
  }
  $('loginBtn').onclick=()=>showAuth('login');$('signupBtn').onclick=()=>showAuth('signup');$('backBtn').onclick=showLanding;$('switchAuth').onclick=()=>showAuth(mode==='signup'?'login':'signup');
  $('authForm').onsubmit=async e=>{e.preventDefault();const button=$('authSubmit');setBusy(button,true,mode==='signup'?'Creating your life…':'Logging in…');$('authMsg').textContent='';$('authMsg').className='msg';const email=$('email').value.trim(),password=$('password').value,name=$('username').value.trim();try{let r;if(mode==='signup'){if(!name){$('authMsg').textContent='Choose a player name first.';return;}r=await sb.auth.signUp({email,password,options:{data:{username:name,display_name:name},emailRedirectTo:location.origin}});if(r.error)throw r.error;if(r.data.session&&r.data.user){await enterGame(r.data.user);}else{$('authMsg').className='msg ok';$('authMsg').textContent='Account created. If email confirmation is enabled, confirm your email, then log in.';}}else{r=await sb.auth.signInWithPassword({email,password});if(r.error)throw r.error;await enterGame(r.data.user);}}catch(err){$('authMsg').textContent=errorText(err);}finally{setBusy(button,false);}};
  $('tabs').addEventListener('click',e=>{const b=e.target.closest('[data-tab]');if(b)openTab(b.dataset.tab);});
  let furnitureDrag=null;
  document.addEventListener('pointerdown',e=>{const piece=e.target.closest('[data-drag-furniture]');if(!piece||!piece.closest('.apartment-room'))return;furnitureDrag={piece,id:piece.dataset.dragFurniture,room:piece.closest('.apartment-room')};piece.classList.add('is-dragging');e.preventDefault();});
  document.addEventListener('pointermove',e=>{if(!furnitureDrag)return;const r=furnitureDrag.room.getBoundingClientRect();const x=Math.max(2,Math.min(94,((e.clientX-r.left)/r.width)*100));const y=Math.max(3,Math.min(68,((r.bottom-e.clientY)/r.height)*100));furnitureDrag.piece.style.left=x+'%';furnitureDrag.piece.style.bottom=y+'%';furnitureDrag.piece.dataset.savedX=x;furnitureDrag.piece.dataset.savedY=y;});
  document.addEventListener('pointerup',async()=>{if(!furnitureDrag)return;const d=furnitureDrag;d.piece.classList.remove('is-dragging');furnitureDrag=null;if(d.piece.dataset.savedX===undefined)return;const x=Number(d.piece.dataset.savedX),y=Number(d.piece.dataset.savedY);const result=await sb.rpc('move_furniture',{p_furniture_id:d.id,p_pos_x:x,p_pos_y:y});if(result.error){toast(errorText(result.error));await openTab('assets');}else toast('Room arrangement saved.');});

  $('panel').addEventListener('click',async e=>{
    const place=e.target.closest('[data-place]')?.dataset.place;if(place){openPlace(place);return;}
    const tab=e.target.closest('[data-tab]')?.dataset.tab;if(tab){await openTab(tab);return;}
    const reload=e.target.closest('[data-reload]')?.dataset.reload;if(reload){await openTab(reload);return;}
    const hire=e.target.closest('[data-hire]')?.dataset.hire;if(hire){
      const jobResult=await sb.from('jobs').select('name,salary').eq('id',hire).maybeSingle();
      if(jobResult.error){toast(errorText(jobResult.error));return;}
      const jobName=jobResult.data?.name||'your new role';
      const hired=await doRpc('hire_for_job',{p_job_id:hire},'You have been hired!');
      if(hired) showHireConfirmation(jobName,jobResult.data?.salary);
      return;
    }
    const dest=e.target.closest('[data-dest]')?.dataset.dest;if(dest){
      const cls=$('travelClass')?.value||'Economy';
      const button=e.target.closest('[data-dest]');setBusy(button,true,'Booking flight…');
      try{
        const [destinationResult,bookingResult]=await Promise.all([
          sb.from('travel_destinations').select('id,name,city,country,airport_code,base_fare').eq('id',dest).maybeSingle(),
          sb.rpc('book_travel',{p_destination_id:dest,p_travel_class:cls})
        ]);
        if(bookingResult.error)throw bookingResult.error;
        const destination=destinationResult.data||{};
        await showFlightExperience(destination,cls,bookingResult.data||{});
      }catch(err){toast(errorText(err));setBusy(button,false);}
      return;
    }
    const prop=e.target.closest('[data-buy-property]')?.dataset.buyProperty;if(prop){await doRpc('purchase_property',{p_property_id:prop},'Property purchased!');return;}
    const car=e.target.closest('[data-buy-car]')?.dataset.buyCar;if(car){await doRpc('purchase_car',{p_car_id:car},'Car purchased!');return;}
    const inviteProperty=e.target.closest('[data-invite-property]')?.dataset.inviteProperty;
    if(inviteProperty){
      const guestId=$(`guestSelect-${inviteProperty}`)?.value;
      if(!guestId){toast('Choose a player to invite first.');return;}
      const result=await sb.from('apartment_visits').insert({owner_id:user.id,guest_id:guestId,property_id:inviteProperty,status:'pending'});
      if(result.error){toast(errorText(result.error));return;}
      toast('Apartment invitation sent! They will receive a notification.');await openTab('assets');return;
    }
    const visitId=e.target.closest('[data-visit-id]')?.dataset.visitId;
    const visitResponse=e.target.closest('[data-visit-response]')?.dataset.visitResponse;
    if(visitId&&visitResponse){const result=await sb.from('apartment_visits').update({status:visitResponse,responded_at:new Date().toISOString()}).eq('id',visitId).eq('guest_id',user.id);if(result.error){toast(errorText(result.error));return;}toast(visitResponse==='accepted'?'Invitation accepted! You can now visit the apartment.':'Invitation declined.');await openTab('assets');return;}
    const furnitureId=e.target.closest('[data-buy-furniture]')?.dataset.buyFurniture;
    if(furnitureId){const result=await sb.rpc('purchase_furniture',{p_item_id:furnitureId,p_pos_x:15+Math.floor(Math.random()*65),p_pos_y:12+Math.floor(Math.random()*38)});if(result.error){toast(errorText(result.error));return;}toast('Furniture purchased! Drag it to arrange your room.');await refreshWallet();await openTab('assets');return;}
    const sellFurniture=e.target.closest('[data-sell-furniture]')?.dataset.sellFurniture;if(sellFurniture){if(!confirm('Sell this furniture for 60% of its shop price?'))return;const result=await sb.rpc('sell_furniture',{p_furniture_id:sellFurniture});if(result.error){toast(errorText(result.error));return;}toast(`Sold ${result.data?.item||'furniture'} for GH₵ ${money(result.data?.payout)}.`);await refreshWallet();await openTab('assets');return;}
    const sellProperty=e.target.closest('[data-sell-property]')?.dataset.sellProperty;if(sellProperty){if(!confirm('Sell this property for 70% of its listed price? You may need to resolve apartment invitations first.'))return;const result=await sb.rpc('sell_player_property',{p_property_id:sellProperty});if(result.error){toast(errorText(result.error));return;}toast(`Property sold for GH₵ ${money(result.data?.payout)}.`);await refreshWallet();await openTab('assets');return;}
    const sellVehicle=e.target.closest('[data-sell-vehicle]')?.dataset.sellVehicle;if(sellVehicle){if(!confirm('Sell this vehicle for 70% of its listed price?'))return;const result=await sb.rpc('sell_player_vehicle',{p_car_id:sellVehicle});if(result.error){toast(errorText(result.error));return;}toast(`Vehicle sold for GH₵ ${money(result.data?.payout)}.`);await refreshWallet();await openTab('assets');return;}
    const openVisit=e.target.closest('[data-open-apartment]')?.dataset.openApartment;
    if(openVisit){const r=await sb.from('apartment_visits').select('*').eq('id',openVisit).in('status',['accepted']).maybeSingle();if(r.error||!r.data){toast('This apartment visit is no longer available.');return;}const v=r.data;if(v.owner_id!==user.id&&v.guest_id!==user.id){toast('You are not part of this invitation.');return;}const hostId=v.owner_id;const [host,home,decor]=await Promise.all([sb.from('players').select('display_name,username').eq('id',hostId).maybeSingle(),sb.from('properties').select('name,location').eq('id',v.property_id).maybeSingle(),sb.from('player_furniture').select('quantity,furniture_items(name,icon)').eq('player_id',hostId)]);const hostName=host.data?.display_name||host.data?.username||'Your friend';const pieces=(decor.data||[]).map(f=>`<span class="room-piece" style="position:static;display:inline-block;margin:8px;font-size:30px">${esc(f.furniture_items?.icon||'🪑')}<small style="display:block;font-size:10px">${esc(f.furniture_items?.name||'Furniture')} ×${f.quantity||1}</small></span>`).join('');document.querySelector('.apartment-visit-overlay')?.remove();const overlay=document.createElement('div');overlay.className='hire-modal-overlay apartment-visit-overlay';overlay.innerHTML=`<div class="hire-modal apartment-visit-modal"><div class="section-label">YOU'RE VISITING</div><h2>${esc(home.data?.name||'Apartment')}</h2><p>${esc(hostName)}'s home · ${esc(home.data?.location||'Accra')}</p><div class="guest-room-preview"><div class="room-window"><span></span><span></span><span></span></div><div class="room-floor"></div><div class="room-sofa">🛋️</div><div class="room-plant">🪴</div>${pieces}</div><p class="hire-modal-sub">You're visiting another player's apartment in Accra Life.</p><button class="primary full" id="closeApartmentVisit">Leave apartment</button></div>`;document.body.appendChild(overlay);overlay.querySelector('#closeApartmentVisit').onclick=()=>overlay.remove();overlay.addEventListener('click',ev=>{if(ev.target===overlay)overlay.remove();});return;}
    const joinParty=e.target.closest('[data-join-party]');if(joinParty){const partyId=joinParty.dataset.joinParty;const result=await sb.from('house_party_attendees').upsert({party_id:partyId,player_id:user.id},{onConflict:'party_id,player_id',ignoreDuplicates:true});if(result.error){toast(errorText(result.error));return;}const partyTitle=joinParty.dataset.partyTitle||'House party';const party=await sb.from('house_parties').select('starts_at').eq('id',partyId).maybeSingle();const zone=`House Party: ${partyTitle}`;localStorage.setItem('accraLifeLocation',zone);$('locationText').textContent=zone.toUpperCase();$('sceneZone').textContent=zone.toUpperCase();await sb.from('player_locations').upsert({player_id:user.id,zone,x:0.5,y:0.5,updated_at:new Date().toISOString()},{onConflict:'player_id'});toast('You’re on the guest list! Have fun at the house party.');await renderHouseParty(partyId);return;}
    const leaveParty=e.target.closest('[data-leave-party]')?.dataset.leaveParty;if(leaveParty){const result=await sb.from('house_party_attendees').delete().eq('party_id',leaveParty).eq('player_id',user.id);if(result.error){toast(errorText(result.error));return;}toast('You left the party guest list.');await openTab('map');return;}
    const cancelParty=e.target.closest('[data-cancel-party]')?.dataset.cancelParty;if(cancelParty){if(!confirm('Cancel this house party?'))return;const result=await sb.from('house_parties').update({status:'cancelled'}).eq('id',cancelParty).eq('host_id',user.id);if(result.error){toast(errorText(result.error));return;}toast('House party cancelled.');await openTab('map');return;}
    const refreshParty=e.target.closest('[data-refresh-party]')?.dataset.refreshParty;if(refreshParty){await renderHouseParty(refreshParty);return;}
    const partyMessage=e.target.closest('[data-party-message]');if(partyMessage){const recipient=partyMessage.dataset.partyMessage,name=partyMessage.dataset.personName||'this player';const body=window.prompt(`Say hello to ${name}:`,'Hi! I’m at the house party too.');if(body&&body.trim()){const sent=await sb.from('messages').insert({sender_id:user.id,recipient_id:recipient,body:body.trim().slice(0,1000)});if(sent.error)toast(errorText(sent.error));else toast(`Message sent to ${name}!`);}return;}
    const refreshCrowd=e.target.closest('[data-refresh-crowd]')?.dataset.refreshCrowd;if(refreshCrowd){await refreshVenueCrowd(refreshCrowd);return;}
    const venueMessage=e.target.closest('[data-venue-message]');if(venueMessage){const recipient=venueMessage.dataset.venueMessage;const name=venueMessage.dataset.personName||'this player';const body=window.prompt(`Say hello to ${name}:`,'Hey! I saw you here in Accra Life. Want to chill?');if(body&&body.trim()){const sent=await sb.from('messages').insert({sender_id:user.id,recipient_id:recipient,body:body.trim().slice(0,1000)});if(sent.error)toast(errorText(sent.error));else toast(`Message sent to ${name}!`);}return;}
    const activity=e.target.closest('[data-place-activity]');if(activity){const p=ACCRA_PLACES.find(x=>x.id===activity.dataset.placeId);const item=p?.activities[Number(activity.dataset.placeActivity)];if(item)toast(`${item}! You’re hanging out at ${p.name}. Check the crowd below to meet other players.`);return;}
    const friend=e.target.closest('[data-friend]')?.dataset.friend;if(friend){const r=await sb.from('friendships').insert({requester_id:user.id,addressee_id:friend,status:'pending'});if(r.error)toast(errorText(r.error));else{toast('Friend request sent.');if(activeTab==='map')await renderVenue(ACCRA_PLACES.find(p=>`${p.name}, Accra`===(localStorage.getItem('accraLifeLocation')||''))?.id);else await openTab('social');}return;}
    const accept=e.target.closest('[data-accept-friend]')?.dataset.acceptFriend;if(accept){const r=await sb.from('friendships').update({status:'accepted',updated_at:new Date().toISOString()}).eq('id',accept).eq('addressee_id',user.id);if(r.error)toast(errorText(r.error));else{toast('Friend request accepted.');await openTab('social');}return;}
    const action=e.target.closest('[data-action]')?.dataset.action;if(!action)return;
    if(action==='create-house-party'){
      const propertyId=$('partyProperty')?.value,title=$('partyTitle')?.value?.trim(),theme=$('partyTheme')?.value||'House party',startsRaw=$('partyStarts')?.value,description=$('partyDescription')?.value?.trim()||'';
      const startsAt=startsRaw?new Date(startsRaw):null;
      if(!propertyId){toast('Choose a property you own.');return;}if(!title||title.length<3){toast('Give your party a name with at least 3 characters.');return;}if(!startsAt||Number.isNaN(startsAt.getTime())||startsAt.getTime()<Date.now()-60000){toast('Choose a future date and time for your party.');return;}
      const result=await sb.from('house_parties').insert({host_id:user.id,property_id:propertyId,title,party_theme:theme,starts_at:startsAt.toISOString(),description,status:'open'}).select('id').single();if(result.error){toast(errorText(result.error));return;}toast('Your house party is published! Other players can find and join it on the map.');await openTab('map');return;
    }
    if(action==='salary'){await doRpc('claim_job_salary',{},'Salary claimed!');return;}
    if(action==='transfer'){const recipient=$('recipientSelect')?.value,amount=Number($('transferAmount')?.value),note=$('transferNote')?.value?.trim()||null;if(!recipient||!Number.isFinite(amount)||amount<=0){toast('Choose a player and enter a valid amount.');return;}await doRpc('send_player_money',{p_recipient_id:recipient,p_amount:amount,p_description:note},'Game money sent!');return;}
    if(action==='send-message'){
      const recipient=$('messageRecipient')?.value,body=$('messageBody')?.value?.trim();
      if(!recipient||!body){toast('Choose a player and write a message first.');return;}
      const r=await sb.from('messages').insert({sender_id:user.id,recipient_id:recipient,body}).select('id').single();
      if(r.error){toast(errorText(r.error));return;}
      toast('Message sent.');await openTab('social');return;
    }
    if(action==='save-display-name'){
      const name=$('settingsDisplayName')?.value?.trim();if(!name){toast('Enter a display name.');return;}
      const r=await sb.from('players').update({display_name:name,updated_at:new Date().toISOString()}).eq('id',user.id);
      if(r.error){toast(errorText(r.error));return;}await refreshProfile();toast('Display name updated.');await openTab('settings');return;
    }
    if(action==='change-email'){
      const email=$('settingsEmail')?.value?.trim();if(!email){toast('Enter the new email address.');return;}
      const r=await sb.auth.updateUser({email});if(r.error){toast(errorText(r.error));return;}toast('Email change requested. Check your email for confirmation.');return;
    }
    if(action==='change-password'){
      const password=$('settingsPassword')?.value;if(!password||password.length<6){toast('Use a password with at least 6 characters.');return;}
      const r=await sb.auth.updateUser({password});if(r.error){toast(errorText(r.error));return;}$('settingsPassword').value='';toast('Password updated.');return;
    }
    if(action==='save-settings'){
      const enabled=$('notificationsEnabled')?.checked===true;
      const r=await sb.from('player_settings').upsert({player_id:user.id,notifications_enabled:enabled,updated_at:new Date().toISOString()},{onConflict:'player_id'});
      if(r.error){toast(errorText(r.error));return;}toast(enabled?'In-game notifications are on.':'In-game notifications are off.');await pollNotifications(false);return;
    }
    if(action==='settings-logout'){await sb.auth.signOut();user=null;profile=null;if(notificationPoll)clearInterval(notificationPoll);showLanding();return;}
    if(action==='create-business'){const name=$('bizName')?.value?.trim(),category=$('bizCategory')?.value,location=$('bizLocation')?.value,price=Number($('bizPrice')?.value);if(!name||!Number.isFinite(price)||price<100){toast('Enter a business name and startup cost of at least GH₵100.');return;}await doRpc('create_business',{p_name:name,p_category:category,p_location:location,p_price:price},'Your business is open!');return;}
    if(action==='create-investment'){const name=$('assetName')?.value?.trim(),principal=Number($('investAmount')?.value),rate=Number($('investRate')?.value),days=Number($('investDays')?.value);if(!name||!Number.isFinite(principal)||principal<=0||!Number.isFinite(rate)||rate<0||rate>100){toast('Enter an investment name, amount and return rate from 0 to 100%.');return;}await doRpc('create_investment',{p_asset_name:name,p_principal:principal,p_return_rate:rate,p_days:days},'In-game investment created!');}
  });
  $('logoutBtn').onclick=async()=>{await sb.auth.signOut();user=null;profile=null;if(notificationPoll)clearInterval(notificationPoll);showLanding();};
  sb.auth.getSession().then(({data,error})=>{if(error){console.warn(error);return;}if(data.session)enterGame(data.session.user);}).catch(console.error);
  sb.auth.onAuthStateChange((_event,session)=>{if(session&&!user){setTimeout(()=>enterGame(session.user),0);}else if(!session&&user){user=null;profile=null;if(notificationPoll)clearInterval(notificationPoll);showLanding();}});
})();
