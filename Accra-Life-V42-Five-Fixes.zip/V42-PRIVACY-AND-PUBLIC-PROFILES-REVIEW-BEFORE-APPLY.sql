-- Accra Life V42: PUBLIC PROFILE PRIVACY
-- REVIEW BEFORE APPLYING. This migration is NOT applied by building the ZIP.
-- It does not delete accounts or modify wallet balances.

begin;

alter table public.players add column if not exists is_public boolean not null default false;

-- RLS must enforce visibility. Public/anonymous users can see only public player cards.
-- Signed-in users can also read their own row; accepted friend rows are handled by
-- application queries only after policy review. Admin access should continue through
-- the existing owner-only admin RPC/dashboard, not a blanket public SELECT policy.
alter table public.players enable row level security;

drop policy if exists "authenticated users can discover player profiles" on public.players;
drop policy if exists "players_select_public_or_self_v42" on public.players;
create policy "players_select_public_or_self_v42"
  on public.players for select
  to anon, authenticated
  using (is_public = true or (auth.uid() is not null and id = auth.uid()));

-- Keep account editing owner-only. This policy is intentionally narrow and does not
-- grant public users access to private profiles.
drop policy if exists "players_update_self_v42" on public.players;
create policy "players_update_self_v42"
  on public.players for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

commit;

-- IMPORTANT ADMIN NOTE:
-- The public client must NOT query private rows. The existing admin dashboard should
-- continue to use its existing owner-authorized RPCs. Do not add a public admin SELECT
-- policy. If the dashboard needs a full private-player listing, expose it only through
-- a SECURITY DEFINER RPC that checks the existing admin allowlist.
