ACCRA LIFE V42 — FIVE REQUESTED FIXES

Included in this package:
1. Black #0E0E0E + gold #D4AF37 theme, 8px Kente strip below game header, and requested 1.4k ONLINE display.
2. Public player discovery/search queries now require is_public=true. Review-first SQL migration adds the is_public column and public/self SELECT policy. Existing private profiles default to private. No accounts deleted.
3. Home preview now has View 3D / Flat view controls, and Move items ON/OFF. Existing drag-and-save calls remain dependent on the database move_furniture RPC. The 3D effect is a CSS perspective room preview, not a full WebGL/physics 3D engine.
4. Landing/home scene uses photo backgrounds, including an Accra trotro, Labadi Beach sunset, and a Ghana chop-bar photo, rotating in the game scene. Wikimedia Commons images are used via Special:FilePath; verify live loading and add visible attribution for the CC BY-SA 4.0 images (Trotro Accra.jpg by NanaYawBotar; Sunset at Labadi Beach Accra.jpg by Danieljatuat; Food 0011.jpg by Amuzujoe) before production. The fourth fallback is a generic city image, not verified as Accra.
5. Alerts and Settings use SVG icons in gold/black instead of bell/gear emoji.

IMPORTANT: SQL migration is review-first and has NOT been applied to Supabase. Public profile filtering expects the is_public column to exist; apply the migration only after reviewing current RLS policies and ensuring the admin dashboard continues to use its authorized RPC. Do not run broad DELETEs.

Validation: run node --check app.js and unzip -t on the package. This is not deployed to Cloudflare Pages and not live-tested on an iPhone.
