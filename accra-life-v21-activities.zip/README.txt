ACCRA LIFE V21 — INTERACTIVE LOCATION ACTIVITIES + XP

What changed in V21
- Visiting a place now lets the player start an activity instead of only seeing a toast message.
- Activities run on a visible countdown with a moving activity icon, progress bar, and stop option.
- Gym, church, nightclub, beach, campus, cinema, mall, home and other venues have activity-specific labels, descriptions, durations and XP rewards.
- Completed activities are recorded in the Supabase player_activity_log table and add XP to the player's profile.
- Existing V20 map, public venue meetups, house parties, home/property, furniture, travel and other game sections are retained.

Database
- V21 adds public.player_activity_log with RLS enabled and authenticated users restricted to reading and inserting their own activity records.
- The frontend uses the existing public Supabase configuration in config.js. Never put a service-role key in a public frontend.

Deploying V21
1. Download and extract this ZIP.
2. Open the EXISTING Accra Life site in Netlify.
3. Deploy the extracted site files (index.html, app.js, styles.css, config.js) to that same site. Do not upload only README.txt.
4. Wait until Netlify says the deploy is published, then refresh the site.
5. Sign in, open Map, choose Fitness Centre or Church, select GO TO THIS PLACE, then choose an activity and start it.
6. Keep the activity screen open until the timer completes. Check the XP display at the top afterward.

Test status
- JavaScript syntax checked with Node.js.
- ZIP integrity checked.
- Supabase activity-log table and columns verified.
- A full live browser run and multi-account testing have not been performed in this environment.
- Creating this ZIP does not deploy it to Netlify. The live site changes only after you deploy it.
