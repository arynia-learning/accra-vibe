ACCRA LIFE — V30 LAUNCH-FIXES TEST BUILD

This is a separate test package based on the saved Accra Life Owner Dashboard project. It does not deploy itself and does not overwrite the live site.

INCLUDED IN THIS BUILD
- Settings masks the account email (for example, h***@gmail.com).
- Wallet labels clarify virtual money only / cannot send real money and retains Payment sandbox.
- Player-to-player transfer UI and client actions are disabled until the GH₵200/day limit is implemented.
- Social discovery filters duplicate player IDs and usernames from the displayed list.
- Shared song playback no longer embeds YouTube; an external Open song in YouTube link remains.
- Public song queue does not display the DJ play-next control.

NOT YET COMPLETED — ECONOMY / LIVE OPERATIONS
The V31 work-timer UI is included. Database changes are supplied as a review-first SQL file and have NOT been applied to live Supabase:
- Daily food, mobile data, and rent/upkeep charges with clear warnings and consequences remain unfinished.
- A six-minute work timer is now displayed; the server-enforced six-minute salary cooldown, Starter Worker at GH₵150, and Starter Studio at GH₵2,500 are in ECONOMY-V31-MIGRATION-REVIEW-FIRST.sql. Apply in staging first; not live-tested.
- Starter-house price remains database-driven and will not change on the live site until that SQL is deliberately applied.
- Safely removing duplicate/test accounts while preserving real players and one verified Arria account.
- Global Online now presence (this build must not pretend that same-venue presence means a player is globally online).
- Netlify hosting badge: this is a dashboard setting, not an HTML element. Disable it in Netlify site settings if enabled.
- Consistent GH₵850.00: wallet balance is database-driven and must not be hardcoded over each player's real virtual balance.

SECURITY CHECKS BEFORE PUBLIC LAUNCH
1. Client-side transfer blocking is only a UI guard. Disable/revoke the send_player_money RPC/server function in Supabase until the GH₵200/day limit is enforced server-side.
2. Do not delete accounts based only on display names. Verify account IDs and ownership first.
3. Keep virtual money separate from real payments. This build has no real-money transfer integration.
4. Test in a separate deployment before replacing the live website.

DEPLOYMENT
Keep index.html, app.js, styles.css, config.js and the other package files together. Upload the extracted folder to a separate test site first. Do not replace the live deployment until sign-in, wallet, social, music and job flows are tested.

HONEST TEST STATUS
This package includes the UI/client changes listed above plus a work countdown and a review-first SQL migration for the entry-level economy. It has not been deployed to the live site and has not been end-to-end tested against live Supabase accounts. The migration is supplied but NOT applied; daily bills remain unfinished.
