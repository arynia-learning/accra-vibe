-- ACCRA LIFE V38 MASTER BRIEF MIGRATION — REVIEW BEFORE APPLYING
-- This script changes database behavior. Review it in Supabase SQL Editor before running.
-- Existing wallet balances are not changed. New account starter wallet becomes GH₵200.

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $function$
declare
  base_username text;
  chosen_username text;
  chosen_display_name text;
begin
  chosen_display_name := left(coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'), ''), nullif(split_part(coalesce(new.email, ''), '@', 1), ''), 'New Player'), 80);
  base_username := lower(regexp_replace(coalesce(nullif(trim(new.raw_user_meta_data->>'username'), ''), nullif(split_part(coalesce(new.email, ''), '@', 1), ''), 'player'), '[^a-zA-Z0-9_]', '', 'g'));
  if base_username = '' then base_username := 'player'; end if;
  chosen_username := left(base_username, 24);
  begin
    insert into public.players (id, username, display_name) values (new.id, chosen_username, chosen_display_name) on conflict (id) do nothing;
  exception when unique_violation then
    chosen_username := left(base_username, 15) || '_' || substr(replace(new.id::text, '-', ''), 1, 8);
    insert into public.players (id, username, display_name) values (new.id, chosen_username, chosen_display_name) on conflict (id) do nothing;
  end;
  insert into public.wallets (player_id, balance) values (new.id, 200) on conflict (player_id) do nothing;
  return new;
end;
$function$;

-- The platform fee is virtual-game-currency accounting, not real-money revenue.
create schema if not exists private;
create table if not exists private.game_transfer_fee_ledger (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.players(id),
  recipient_id uuid not null references public.players(id),
  transfer_amount numeric(12,2) not null check (transfer_amount > 0),
  fee_amount numeric(12,2) not null check (fee_amount >= 0),
  created_at timestamptz not null default now()
);
revoke all on private.game_transfer_fee_ledger from public, anon, authenticated;

create or replace function public.send_game_money_with_fee(p_recipient_id uuid, p_amount numeric, p_message text default null)
returns jsonb
language plpgsql
security definer
set search_path = public, private
as $function$
declare
  v_sender uuid := auth.uid();
  v_amount numeric(12,2) := round(p_amount,2);
  v_fee numeric(12,2);
  v_sender_level integer;
  v_daily numeric(12,2);
  v_sender_balance numeric(12,2);
  v_recipient_balance numeric(12,2);
begin
  if v_sender is null then raise exception 'Please log in before sending money.'; end if;
  if p_recipient_id is null or p_recipient_id = v_sender then raise exception 'Choose another player.'; end if;
  if v_amount is null or v_amount < 1 or v_amount > 500 then raise exception 'Send between GH₵1 and GH₵500 per transaction.'; end if;
  select level into v_sender_level from public.players where id=v_sender;
  if coalesce(v_sender_level,1) < 3 then raise exception 'Reach Level 3 before sending game money.'; end if;
  if not exists(select 1 from public.players where id=p_recipient_id) then raise exception 'Player not found.'; end if;
  v_fee := round(v_amount * 0.15,2);
  select coalesce(sum(amount),0) into v_daily from public.player_transfers where sender_id=v_sender and created_at >= date_trunc('day',now());
  if v_daily + v_amount > 1000 then raise exception 'Your daily sending limit is GH₵1,000.'; end if;
  perform 1 from public.wallets where player_id in (v_sender,p_recipient_id) order by player_id for update;
  select balance into v_sender_balance from public.wallets where player_id=v_sender;
  if v_sender_balance is null or v_sender_balance < v_amount + v_fee then raise exception 'Insufficient funds. The transfer plus 15%% fee is GH₵% .', (v_amount+v_fee); end if;
  if not exists(select 1 from public.wallets where player_id=p_recipient_id) then raise exception 'Recipient wallet is not ready.'; end if;
  update public.wallets set balance=balance-(v_amount+v_fee),updated_at=now() where player_id=v_sender;
  update public.wallets set balance=balance+v_amount,updated_at=now() where player_id=p_recipient_id;
  insert into public.player_transfers(sender_id,recipient_id,amount,description) values(v_sender,p_recipient_id,v_amount,left(coalesce(p_message,''),240));
  insert into public.wallet_transactions(player_id,amount,transaction_type,description) values
    (v_sender,-(v_amount+v_fee),'player_transfer','Sent GH₵'||to_char(v_amount,'FM999999990.00')||' plus 15% game fee'),
    (p_recipient_id,v_amount,'player_transfer_received','Received game money');
  insert into private.game_transfer_fee_ledger(sender_id,recipient_id,transfer_amount,fee_amount) values(v_sender,p_recipient_id,v_amount,v_fee);
  select balance into v_sender_balance from public.wallets where player_id=v_sender;
  select balance into v_recipient_balance from public.wallets where player_id=p_recipient_id;
  return jsonb_build_object('sent',v_amount,'fee',v_fee,'sender_balance',v_sender_balance,'recipient_balance',v_recipient_balance);
end;
$function$;
revoke all on function public.send_game_money_with_fee(uuid,numeric,text) from public;
grant execute on function public.send_game_money_with_fee(uuid,numeric,text) to authenticated;

-- Economy price corrections. These update only matching catalogue names and do not touch player ownership.
update public.properties set price=700 where lower(name) in ('starter studio','starter studio apartment');
update public.properties set price=1100 where lower(name)='dome apartment';
update public.properties set price=1800 where lower(name) like 'oyarifa%';
update public.properties set price=1500 where lower(name)='east legon apartment';
update public.properties set price=7500 where lower(name) like 'airport city%plot%';
update public.properties set price=10000 where lower(name) like 'cantonments%';
update public.cars set price=1200 where lower(name) like '%city hatch%';
-- Review trailer catalogue location before changing trailer prices; trailers may be stored in inventory_items, not cars.
