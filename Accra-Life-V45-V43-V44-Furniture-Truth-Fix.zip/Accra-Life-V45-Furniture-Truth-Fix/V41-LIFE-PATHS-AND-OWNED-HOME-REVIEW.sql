-- ACCRA LIFE V41: Life paths, starter homes, weekly allowance and job tiers.
-- REVIEW BEFORE APPLYING. This migration DOES NOT delete accounts or alter existing wallet balances.
-- The live project uses public.players and public.player_properties (not public.profiles/user_houses).

begin;

alter table public.players
  add column if not exists life_path text not null default 'semi-rich',
  add column if not exists allowance_last_claim timestamptz;

-- Validate supported path values for existing and new player records.
do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'players_life_path_check') then
    alter table public.players add constraint players_life_path_check
      check (life_path in ('lapo','semi-rich','nepo'));
  end if;
end $$;

-- Prevent ordinary client updates from changing a chosen life path. A future verified
-- Paystack webhook / ad-reward server function must explicitly handle paid Nepo unlocks.
create or replace function public.prevent_life_path_change()
returns trigger language plpgsql set search_path = public as $$
begin
  if new.life_path is distinct from old.life_path
     and coalesce(current_setting('app.allow_life_path_change', true), '') <> 'on' then
    raise exception 'Life path changes require a verified server-side unlock';
  end if;
  return new;
end $$;
drop trigger if exists protect_player_life_path on public.players;
create trigger protect_player_life_path before update of life_path on public.players
for each row execute function public.prevent_life_path_change();

-- New account setup only. Existing balances and existing player houses remain untouched.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  base_username text;
  chosen_username text;
  chosen_display_name text;
  chosen_path text;
  starting_balance numeric;
begin
  chosen_display_name := left(coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'), ''), nullif(split_part(coalesce(new.email, ''), '@', 1), ''), 'New Player'), 80);
  base_username := lower(regexp_replace(coalesce(nullif(trim(new.raw_user_meta_data->>'username'), ''), nullif(split_part(coalesce(new.email, ''), '@', 1), ''), 'player'), '[^a-zA-Z0-9_]', '', 'g'));
  if base_username = '' then base_username := 'player'; end if;
  chosen_username := left(base_username, 24);
  -- Until payment/ad verification exists, the only self-service choices are Lapo and Semi-rich.
  chosen_path := case when new.raw_user_meta_data->>'life_path' = 'lapo' then 'lapo' else 'semi-rich' end;
  starting_balance := case when chosen_path = 'lapo' then 100 else 1000 end;

  begin
    insert into public.players (id, username, display_name, life_path)
    values (new.id, chosen_username, chosen_display_name, chosen_path)
    on conflict (id) do nothing;
  exception when unique_violation then
    chosen_username := left(base_username, 15) || '_' || substr(replace(new.id::text, '-', ''), 1, 8);
    insert into public.players (id, username, display_name, life_path)
    values (new.id, chosen_username, chosen_display_name, chosen_path)
    on conflict (id) do nothing;
  end;

  insert into public.wallets (player_id, balance)
  values (new.id, starting_balance)
  on conflict (player_id) do nothing;

  -- Semi-rich starts with Starter Studio (Osu), without deducting the starter wallet.
  if chosen_path = 'semi-rich' then
    insert into public.player_properties (player_id, property_id)
    select new.id, p.id from public.properties p where p.name = 'Starter Studio'
    on conflict (player_id, property_id) do nothing;
  end if;
  return new;
end;
$$;

-- Path-specific jobs. Existing job pay is mapped to the requested normal/high tiers.
alter table public.jobs add column if not exists life_path text not null default 'semi-rich';
update public.jobs set life_path = 'semi-rich' where life_path is null or life_path = '';
update public.jobs set life_path = 'nepo', salary = 1200 where name = 'Banking Officer';
update public.jobs set life_path = 'semi-rich' where name in ('Content Creator','Fashion Entrepreneur','Marketing Executive','Software Developer');

insert into public.jobs (name, category, salary, description, life_path)
select v.name, v.category, v.salary, v.description, v.life_path
from (values
  ('Hawker','Entry-level',50::numeric,'Sell goods on the streets of Accra. Hard-mode starting work.','lapo'),
  ('Trotro Mate','Transport',100::numeric,'Help passengers and collect fares on a trotro route.','lapo'),
  ('Cleaner','Services',150::numeric,'Earn your first income through cleaning shifts.','lapo'),
  ('Shop Attendant','Retail',250::numeric,'Serve customers and keep a shop running.','semi-rich'),
  ('Driver','Transport',350::numeric,'Drive customers around Accra.','semi-rich'),
  ('Waiter','Hospitality',300::numeric,'Serve guests at a restaurant.','semi-rich'),
  ('Real Estate Connector','Real Estate',800::numeric,'Use family connections to close property deals.','nepo'),
  ('Influencer','Media',1200::numeric,'Build a public profile and earn through campaigns.','nepo'),
  ('Investment Banker','Finance',2000::numeric,'A high-paying role available through elite connections.','nepo')
) as v(name,category,salary,description,life_path)
where not exists (select 1 from public.jobs j where lower(j.name)=lower(v.name));

-- Enforce job tier server-side; filtering cards in the browser alone is not security.
create or replace function public.hire_for_job(p_job_id uuid)
returns public.player_jobs language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_result public.player_jobs;
  v_path text;
  v_job_path text;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  select life_path into v_path from public.players where id = v_uid;
  if v_path is null then raise exception 'Player profile not found'; end if;
  select life_path into v_job_path from public.jobs where id = p_job_id;
  if v_job_path is null then raise exception 'Job not found'; end if;
  if v_job_path <> 'all' and v_job_path <> v_path then
    raise exception 'This job is not available for your life path';
  end if;
  insert into public.player_jobs(player_id,job_id,last_salary_at)
  values(v_uid,p_job_id,null)
  on conflict(player_id) do update set job_id=excluded.job_id,hired_at=now(),last_salary_at=null
  returning * into v_result;
  return v_result;
end;
$$;
revoke all on function public.hire_for_job(uuid) from public, anon;
grant execute on function public.hire_for_job(uuid) to authenticated;

-- Weekly family allowance. Locks the player and wallet rows and records the credit atomically.
create or replace function public.claim_family_allowance()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_path text;
  v_last timestamptz;
  v_amount numeric;
  v_balance numeric;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  select life_path, allowance_last_claim into v_path, v_last
  from public.players where id = v_uid for update;
  if v_path is null then raise exception 'Player profile not found'; end if;
  if v_path = 'lapo' then raise exception 'Lapo has no family allowance'; end if;
  v_amount := case when v_path = 'nepo' then 1000 else 200 end;
  if v_last is not null and v_last > now() - interval '7 days' then
    raise exception 'Your next family allowance is available after 7 days';
  end if;
  update public.wallets set balance = balance + v_amount, updated_at = now()
  where player_id = v_uid returning balance into v_balance;
  if not found then raise exception 'Wallet not found'; end if;
  update public.players set allowance_last_claim = now() where id = v_uid;
  insert into public.wallet_transactions(player_id, amount, transaction_type, description)
  values(v_uid, v_amount, 'family_allowance', 'Weekly family allowance · ' || v_path);
  return jsonb_build_object('success', true, 'amount', v_amount, 'balance', v_balance, 'next_claim_at', now() + interval '7 days');
end;
$$;
revoke all on function public.claim_family_allowance() from public, anon;
grant execute on function public.claim_family_allowance() to authenticated;

commit;

-- NOTES:
-- 1. This migration intentionally does not create/modify a `profiles` or `user_houses` table:
--    the live app's real schema is `players` and `player_properties`.
-- 2. Nepo Baby stays locked until a secure Paystack webhook or verified ad reward is built.
-- 3. No fake online count is added. Show actual presence counts or a non-numeric community label.
-- 4. No existing account is deleted. Review account IDs and backups before any deletion.
