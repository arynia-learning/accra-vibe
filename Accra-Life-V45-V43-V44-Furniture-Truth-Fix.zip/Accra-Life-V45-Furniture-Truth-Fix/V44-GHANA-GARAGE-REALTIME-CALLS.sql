-- ACCRA LIFE V44: remove US-style trailers, normalize Ghana vehicle catalogue,
-- make public-player invite dropdown work, and add secure 1-to-1 call signalling.
-- Review and run AFTER the V43 migration. Does not alter existing wallet balances.
begin;

-- Remove trailer entries and their game ownership records; these are the unwanted US-style assets.
delete from public.player_cars pc
using public.cars c
where pc.car_id=c.id and (c.name ilike '%trailer%' or coalesce(c.brand,'') ilike '%trailer%');
delete from public.cars
where name ilike '%trailer%' or coalesce(brand,'') ilike '%trailer%';

-- Normalize the canonical catalogue rows seeded in V43, rather than creating duplicate vehicles.
update public.cars set name='Toyota Corolla', brand='Toyota', price=12000,
  image_url='https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=900&q=82'
where lower(name) in ('corolla','toyota corolla') and lower(coalesce(brand,''))='toyota';
update public.cars set name='Range Rover', brand='Range Rover', price=40000,
  image_url='https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=900&q=82'
where lower(name) in ('sport','range rover') and lower(coalesce(brand,''))='range rover';
update public.cars set price=200, image_url='https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&w=900&q=82'
where lower(name)='bicycle';
update public.cars set price=2500, image_url='https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=900&q=82'
where lower(name)='okada';
update public.cars set price=5000, image_url='https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=900&q=82'
where lower(name)='trotro';

insert into public.cars(brand,name,price,image_url)
select v.brand,v.name,v.price,v.image_url
from (values
 ('Accra Cycles','Bicycle',200,'https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&w=900&q=82'),
 ('Accra Motors','Okada',2500,'https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=900&q=82'),
 ('Accra Transit','Trotro',5000,'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=900&q=82'),
 ('Toyota','Toyota Corolla',12000,'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=900&q=82'),
 ('Range Rover','Range Rover',40000,'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=900&q=82')
) as v(brand,name,price,image_url)
where not exists (select 1 from public.cars c where lower(c.name)=lower(v.name));

-- Only the five requested Ghanaian vehicles are shown in the Garage shop UI.
-- Other owned vehicles (if any) are retained in player_cars and are not deleted.

-- Call signalling. Media itself uses Agora Web SDK; set ACCRA_LIFE_CONFIG.agoraAppId in config.js.
create table if not exists public.calls (
  id uuid primary key default gen_random_uuid(),
  from_user uuid not null references public.players(id) on delete cascade,
  to_user uuid not null references public.players(id) on delete cascade,
  type text not null check (type in ('audio','video')),
  status text not null default 'ringing' check (status in ('ringing','connected','declined','ended')),
  room_id text not null unique,
  created_at timestamptz not null default now(),
  connected_at timestamptz,
  ended_at timestamptz,
  constraint calls_no_self_call check (from_user <> to_user)
);
create index if not exists calls_to_status_created_idx on public.calls(to_user,status,created_at desc);
create index if not exists calls_from_created_idx on public.calls(from_user,created_at desc);
alter table public.calls enable row level security;
drop policy if exists calls_participant_select_v44 on public.calls;
create policy calls_participant_select_v44 on public.calls for select to authenticated
  using ((select auth.uid())=from_user or (select auth.uid())=to_user);
revoke all on public.calls from anon,authenticated;
grant select on public.calls to authenticated;

create or replace function public.start_player_call(p_to_user uuid,p_type text,p_room_id text)
returns public.calls language plpgsql security definer set search_path=public,auth as $$
declare v_uid uuid:=auth.uid(); v_call public.calls%rowtype;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  if p_to_user is null or p_to_user=v_uid then raise exception 'Choose another player to call'; end if;
  if p_type not in ('audio','video') then raise exception 'Call type must be audio or video'; end if;
  if p_room_id is null or length(p_room_id)<8 or length(p_room_id)>100 then raise exception 'Invalid call room'; end if;
  if not exists(select 1 from public.players p where p.id=p_to_user) then raise exception 'Player not found'; end if;
  if exists(select 1 from public.blocks b where (b.blocker_id=v_uid and b.blocked_id=p_to_user) or (b.blocker_id=p_to_user and b.blocked_id=v_uid)) then raise exception 'Calls are unavailable for this player connection'; end if;
  if exists(select 1 from public.calls c where (c.from_user=v_uid or c.to_user=v_uid or c.from_user=p_to_user or c.to_user=p_to_user) and c.status in ('ringing','connected') and c.created_at>now()-interval '2 hours') then
    raise exception 'One of these players is already in a call';
  end if;
  insert into public.calls(from_user,to_user,type,status,room_id)
  values(v_uid,p_to_user,p_type,'ringing',p_room_id) returning * into v_call;
  begin
    insert into public.notifications(player_id,title,body,type)
    values(p_to_user,case when p_type='video' then 'Incoming video call' else 'Incoming audio call' end,
      (select coalesce(nullif(display_name,''),username,'A player') from public.players where id=v_uid)||' is calling you on Accra Life. Open Social to answer.','update');
  exception when undefined_table or undefined_column then null;
  end;
  return v_call;
end;
$$;

create or replace function public.respond_player_call(p_call_id uuid,p_accept boolean)
returns public.calls language plpgsql security definer set search_path=public,auth as $$
declare v_uid uuid:=auth.uid(); v_call public.calls%rowtype;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  update public.calls set status=case when p_accept then 'connected' else 'declined' end,
    connected_at=case when p_accept then now() else null end,
    ended_at=case when p_accept then null else now() end
  where id=p_call_id and to_user=v_uid and status='ringing'
  returning * into v_call;
  if not found then raise exception 'This incoming call is no longer available'; end if;
  return v_call;
end;
$$;

create or replace function public.end_player_call(p_call_id uuid)
returns public.calls language plpgsql security definer set search_path=public,auth as $$
declare v_uid uuid:=auth.uid(); v_call public.calls%rowtype;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  update public.calls set status='ended',ended_at=now()
  where id=p_call_id and (from_user=v_uid or to_user=v_uid) and status in ('ringing','connected')
  returning * into v_call;
  if not found then
    select * into v_call from public.calls where id=p_call_id and (from_user=v_uid or to_user=v_uid);
    if not found then raise exception 'Call not found'; end if;
  end if;
  return v_call;
end;
$$;

revoke all on function public.start_player_call(uuid,text,text) from public,anon;
revoke all on function public.respond_player_call(uuid,boolean) from public,anon;
revoke all on function public.end_player_call(uuid) from public,anon;
grant execute on function public.start_player_call(uuid,text,text) to authenticated;
grant execute on function public.respond_player_call(uuid,boolean) to authenticated;
grant execute on function public.end_player_call(uuid) to authenticated;

commit;

-- Verification after applying:
-- select brand,name,price from public.cars where lower(name) like '%trailer%'; -- expected 0 rows
-- select brand,name,price from public.cars where lower(name) in ('bicycle','okada','trotro','toyota corolla','range rover') order by price;
-- select column_name,data_type from information_schema.columns where table_schema='public' and table_name='calls';
