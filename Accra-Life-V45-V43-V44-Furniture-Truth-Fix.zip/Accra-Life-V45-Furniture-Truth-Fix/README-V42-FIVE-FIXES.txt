ACCRA LIFE V42 — FOLLOW-UP FIXES (2026-10-12)

LIVE SUPABASE STATUS
1. V41 life paths and owned-home migration was applied to the connected Supabase project.
   Verified: public.players now has life_path; all 7 existing player rows have a path value.
2. V42 privacy and wallet-persistence migration was applied to the connected Supabase project.
   Verified: is_public exists; only three explicitly requested profiles (Mila, Chan_xn, Hajia) are public; remaining existing profiles default to private. No account was deleted and no existing wallet balance was reset.
3. The secure claim_wallet_test_credit() RPC exists. It is executable by authenticated users only, adds GH₵150 to their saved public.wallets balance and records public.wallet_transactions, with one claim per account. It is a virtual game credit, not a real payment or withdrawable cash. Anonymous users cannot execute it.

WEBSITE CHANGES IN THIS ZIP
- Keeps black #0E0E0E + gold #D4AF37, 8px Kente strip, requested 1.4k ONLINE label, and SVG navigation icons.
- Public player discovery and exact username search now require is_public=true.
- Settings has a Public Profile toggle so each player can choose whether strangers can discover them.
- MeetGhana/Discover can now return the three requested public profiles; recent-message labels can resolve those profiles when they are part of the conversation.
- Payment sandbox no longer claims the test balance is saved only in this browser. It shows the real saved game wallet and has an “Add GH₵150” button that calls the secure RPC.
- Existing wallet transaction history is shown from Supabase.
- House preview includes View 3D / Flat View and Move Items controls. The 3D effect is a CSS perspective preview, not a full WebGL simulation. Existing drag-save behavior still depends on the existing database move_furniture RPC.
- Photo-led city scenes and gold/black SVG navigation icons remain in the package.

SAFETY / LIMITATIONS
- The “1.4k ONLINE” label is shown as requested; it is a fixed display label, not a verified live presence count.
- “Add GH₵150” can be claimed once per account. This is a test-only virtual credit, not a real payment. Do not market it as a deposit or payout.
- Nepo Baby paid/ad unlock is not implemented.
- The admin dashboard's authorized get_admin_dashboard_stats() RPC remains the intended private admin data route.
- Public profiles are visible to strangers; users can turn their own profile off in Settings.
- The code has not been deployed to Cloudflare Pages from this package and has not been end-to-end tested on the user's iPhone. Upload the files to the existing Cloudflare Pages project after keeping a backup.

VALIDATION
- Run node --check app.js.
- Verify ZIP integrity with unzip -t.
- After upload, sign in and test: Settings → Public Profile; MeetGhana/Discover; Wallet → Add GH₵150; log out/in and confirm the wallet balance remains; press Add GH₵150 again and confirm the server rejects a second claim.
