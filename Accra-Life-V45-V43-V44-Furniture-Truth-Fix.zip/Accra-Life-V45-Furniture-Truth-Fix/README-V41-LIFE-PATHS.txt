ACCRA LIFE V41 — LIFE PATHS + OWNED HOME STATUS

The V41 migration was applied to the connected Supabase project on 2026-10-12 and verified. The live schema uses public.players and public.player_properties (not public.profiles or public.user_houses).

- Adds life_path and allowance_last_claim to public.players.
- New account trigger gives Lapo GH₵100 or Semi-rich GH₵1,000, without overwriting existing wallets.
- New Semi-rich accounts receive Starter Studio ownership through public.player_properties.
- Adds life-path job tiers and enforces job eligibility in hire_for_job().
- Adds claim_family_allowance(), with weekly allowance rules.
- Existing player balances and ownership were not reset; no accounts were deleted.
- Nepo Baby remains locked until secure Paystack/ad reward verification is implemented.

The migration SQL is included for reference. Do not reapply it without reviewing the current schema and migration history.
