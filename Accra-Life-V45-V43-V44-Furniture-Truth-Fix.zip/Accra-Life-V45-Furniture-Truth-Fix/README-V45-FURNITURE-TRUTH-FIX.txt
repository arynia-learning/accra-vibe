ACCRA LIFE V45 — FURNITURE TRUTH FIX

This package is based on the V44 Expanded Home Shop build and preserves the included V43/V44 site files and features. It adds a product-specific photo map for the reported mismatches, plus two locally bundled product illustrations (wall AC and Kente-pattern L-shaped sofa). It does not replace the project with a demo.

WHAT CHANGED
- Furniture cards now use product-specific photo mappings for the reported items before considering a legacy database image_url.
- A TV stand uses a stand-only image; the 43-inch TV and 65-inch QLED TV use separate image sources.
- Added distinct images for mattress, curtains, rug, plastic chair, clothes rack, fan, dressing tables, refrigerator, kitchen sink, wardrobes, kitchen cabinet, TVs, and jacuzzi/hot tub items.
- Added locally bundled SVG illustrations for the wall AC and Kente-pattern L-shaped sofa.
- The app no longer invents a generic living-room photo when a product has no usable image. If a third-party image fails, it shows the existing product-specific fallback icon rather than a misleading photo.
- Added SQL migration V45-FURNITURE-TRUTH-FIX.sql. It clears duplicated and specifically reported mismatched stored image URLs, gives the reported products relevant icons, and moves jacuzzis/hot tubs into the existing Comfort category.
- Preserves product rows, prices, IDs, purchases, wallets, and owned furniture. It does not use a nonexistent is_active column. The 3-door wooden wardrobe remains GH₵1,500.

IMPORTANT IMAGE NOTE
Most mapped product photos are hosted by third-party retailers/image hosts and are loaded over the internet. Their availability and licensing/hotlink policies may change. Check permissions before commercial use. The Kente sofa and AC use locally bundled SVG illustrations, not photographs. Other products whose image hosts block loading will use a fallback icon until a licensed, reliable photo is installed.

DEPLOYMENT ORDER
1. Extract the ZIP. Upload the extracted root folder's contents to a PREVIEW deployment first; do not upload the ZIP itself.
2. Confirm the preview loads and test login, Furniture Shop, purchase flow, wallet, garage, and call screens.
3. Only after the V45 front-end is deployed, review and apply V45-FURNITURE-TRUTH-FIX.sql in the Supabase SQL Editor for project kpyugkfbkzkuumcpkzkb. The migration has NOT been executed by this package-building step.
4. Check the migration's final verification query for repeated stored image URLs and review any results.
5. Do not replace the current live site until the preview tests pass.

STATUS
- Package built from the existing V44 Expanded Home Shop files, retaining the included V43/V44 files/features.
- JavaScript syntax check passed during packaging.
- Not deployed to Cloudflare; database migration not executed.
