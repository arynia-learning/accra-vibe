-- ACCRA LIFE V42: applied to the connected Supabase project on 2026-10-12.
-- Adds opt-in public profiles and a one-time persistent GH₵150 virtual test credit.
-- No existing wallet balances were reset and no accounts were deleted.
begin;
alter table public.players add column if not exists is_public boolean not null default false;
alter table public.players enable row level security;
drop policy if exists "authenticated users can discover player profiles" on public.players;
drop policy if exists "players_select_public_or_self_v42" on public.players;
create policy "players_select_public_or_self_v42"
  on public.players for select to anon, authenticated
  using (is_public = true or (auth.uid() is not null and id = auth.uid()));
drop policy if exists "players_update_self_v42" on public.players;
create policy "players_update_self_v42" on public.players for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());
update public.players set is_public = true
where lower(username) in ('mila','chan_xn','hajia');
create schema if not exists private;
create table if not exists private.wallet_test_credits (
  player_id uuid primary key references public.players(id) on delete cascade,
  credited_at timestamptz not null default now(),
  amount numeric not null default 150 check (amount = 150)
);
alter table private.wallet_test_credits enable row level security;
revoke all on private.wallet_test_credits from anon, authenticated, public;
create or replace function public.claim_wallet_test_credit()
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_balance numeric;
begin
  if v_uid is null then raise exception 'Sign in to add the test credit' using errcode = '28000'; end if;
  insert into private.wallet_test_credits(player_id, amount) values (v_uid, 150)
  on conflict (player_id) do nothing;
  if not found then raise exception 'The GH₵150 test credit has already been claimed on this account'; end if;
  update public.wallets set balance = balance + 150, updated_at = now()
  where player_id = v_uid returning balance into v_balance;
  if not found then
    delete from private.wallet_test_credits where player_id = v_uid;
    raise exception 'Wallet not found for this account';
  end if;
  insert into public.wallet_transactions(player_id, amount, transaction_type, description)
  values (v_uid, 150, 'test_credit', 'One-time GH₵150 virtual wallet test credit');
  return jsonb_build_object('success', true, 'amount', 150, 'balance', v_balance);
end;
$$;
revoke all on function public.claim_wallet_test_credit() from public, anon;
grant execute on function public.claim_wallet_test_credit() to authenticated;
commit;
