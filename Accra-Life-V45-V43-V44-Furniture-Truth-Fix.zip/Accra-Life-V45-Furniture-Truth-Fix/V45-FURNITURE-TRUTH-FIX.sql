-- ACCRA LIFE V45 — Furniture Shop truthful-image fix
-- Safe, repeatable migration. Does not delete products, prices, IDs, purchases, wallets, or owned furniture.
-- Apply only when the V45 app.js/styles.css package is deployed, so blank image_url values render as emoji placeholders.

begin;

-- Clear any image URL shared by multiple catalogue items: shared photos are not reliable product evidence.
update public.furniture_items fi
set image_url = null
where fi.image_url is not null
  and fi.image_url in (
    select image_url from public.furniture_items
    where image_url is not null
    group by image_url having count(*) > 1
  );

-- Clear known screenshot mismatches so the app shows the product-specific emoji, not a misleading photo.
update public.furniture_items
set image_url = null
where lower(name) in (
  'student mattress on floor', 'student mattress floor', 'curtains', 'rug', 'plastic chair',
  'clothes rack + box', 'table fan', 'tv stand', 'standard dressing table', 'refrigerator',
  'premium granite kitchen sink', 'large 3-door wooden wardrobe', 'large wall kitchen cabinet',
  '43-inch smart tv', 'luxury dressing table with lights', '65-inch qled smart tv',
  '4-person family jacuzzi', '6-person luxury jacuzzi', 'outdoor hot tub', '1.0 hp wall ac',
  'premium sliding-door wardrobe', 'l-shaped kente sofa', 'plastic chair + gaming table'
);

-- Correct category placement to match the available Comfort category, not Bathroom/Living Room.
update public.furniture_items
set category = 'Comfort', icon = '🛁', image_url = null
where lower(name) in ('2-person jacuzzi','4-person family jacuzzi','6-person luxury jacuzzi','outdoor hot tub');

-- Product-specific emoji fallbacks. These remain useful even when verified product photos are added later.
update public.furniture_items
set icon = case
  when lower(name) like '%mattress%' or lower(name) like '%bed%' then '🛏️'
  when lower(name) like '%curtain%' then '🪟'
  when lower(name) like '%rug%' then '🧶'
  when lower(name) like '%fan%' then '💨'
  when lower(name) like '%tv%' or lower(name) like '%television%' then '📺'
  when lower(name) like '%fridge%' or lower(name) like '%refrigerator%' then '🧊'
  when lower(name) like '%jacuzzi%' or lower(name) like '%hot tub%' then '🛁'
  when lower(name) like '%air conditioner%' or lower(name) like '%wall ac%' or lower(name) like '% ac%' then '❄️'
  when lower(name) like '%sink%' or lower(name) like '%kitchen cabinet%' or lower(name) like '%kitchen%' then '🍳'
  when lower(name) like '%wardrobe%' or lower(name) like '%closet%' then '🚪'
  when lower(name) like '%dressing table%' then '🪞'
  when lower(name) like '%clothes rack%' then '🧥'
  when lower(name) like '%chair%' then '🪑'
  when lower(name) like '%sofa%' or lower(name) like '%couch%' then '🛋️'
  else icon end
where lower(name) in (
  'student mattress on floor','student mattress floor','curtains','rug','plastic chair',
  'clothes rack + box','table fan','tv stand','standard dressing table','refrigerator',
  'premium granite kitchen sink','large 3-door wooden wardrobe','large wall kitchen cabinet',
  '43-inch smart tv','luxury dressing table with lights','65-inch qled smart tv',
  '4-person family jacuzzi','6-person luxury jacuzzi','outdoor hot tub','1.0 hp wall ac',
  'premium sliding-door wardrobe','l-shaped kente sofa','plastic chair + gaming table',
  '2-person jacuzzi'
);

-- Explicit correction from the screenshot review.
update public.furniture_items set price = 1500
where lower(name) = 'large 3-door wooden wardrobe';

commit;

-- Verification: repeated non-null photos should be zero after migration.
select image_url, count(*) as item_count, array_agg(name order by name) as products
from public.furniture_items where image_url is not null
group by image_url having count(*) > 1;
