ACCRA LIFE V44 — GHANAIAN GARAGE + CALLS

CONTENTS
- index.html, app.js, styles.css, config.js: site frontend
- V43-BOUTIQUE-GARAGE-STARTING-WALLET-INVITES.sql: existing Boutique/Garage migration (apply only if not already applied)
- V44-GHANA-GARAGE-REALTIME-CALLS.sql: removes trailer vehicles, normalizes the Ghana vehicle list, and adds secure call signalling
- Existing V41/V42 SQL and README files are retained for reference.

APPLY ORDER
1. If V43 has NOT been applied, review and run V43 first. If already applied, do not re-run unrelated migrations just to apply V44.
2. Review and run V44-GHANA-GARAGE-REALTIME-CALLS.sql in Supabase SQL Editor. It does not change existing wallet balances. It removes trailer catalogue rows and their player_cars ownership rows.
3. Deploy index.html, app.js, styles.css, config.js and the existing supporting pages to Cloudflare Pages together.

GARAGE FIX
The Garage shop now only displays Bicycle (GH₵200), Okada (GH₵2,500), Trotro (GH₵5,000), Toyota Corolla (GH₵12,000), and Range Rover (GH₵40,000). The migration deletes trailer catalogue rows and the frontend filters the shop to those five Ghanaian options. Existing non-trailer vehicle ownership rows are retained.

CALL FEATURE STATUS / REQUIRED SETUP
The package includes call buttons, incoming-call signalling, accept/decline, in-call controls, incoming-call polling, and Agora Web SDK integration. The actual audio/video media will NOT connect until the site owner configures an Agora App ID in config.js: window.ACCRA_LIFE_CONFIG.agoraAppId='YOUR_AGORA_APP_ID'. For an Agora project with App Certificate/token enforcement, add a server-side token endpoint and update the join flow to request tokens. Never put an Agora App Certificate or other secret in frontend config.js. Microphone/camera permissions and HTTPS are required. The call UI is not a claim of verified live media until tested with two separate signed-in accounts and real devices.

TEST CHECKLIST
- Confirm no car name contains Trailer in public.cars.
- Confirm the five requested vehicle rows and prices.
- Sign in as two accounts; ensure each can see public Discover players.
- Start a call from one account and accept it on the other; test audio, video, mute, camera toggle, decline, and end.
- Test on HTTPS iPhone Safari and desktop browsers.
- If calls fail, check Agora App ID/token configuration, microphone/camera permissions, and Supabase RPC errors.
