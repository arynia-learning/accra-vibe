-- Accra Life V44: expanded home shop catalogue
-- Apply this in Supabase SQL Editor after the V43/V44 migrations.
-- Every newly seeded listing has a distinct image_url and realistic in-game Ghana cedi price.
with items(name,category,price,icon,tier,image_url) as (values
 ('Student Mattress — Nima','Bedroom',200,'🟦','Budget','https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&w=900&q=82'),
 ('Simple Wooden Single Bed','Bedroom',600,'🪵','Budget','https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=82'),
 ('Double Bed — Osu','Bedroom',1200,'🛏️','Middle','https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=901&q=82'),
 ('Luxury King Bed — East Legon','Bedroom',3500,'👑','Luxury','https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=900&q=82'),
 ('Two-Door Wardrobe','Bedroom',850,'🚪','Middle','https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=900&q=82'),
 ('Three-Door Wardrobe','Bedroom',1000,'🚪','Middle','https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=901&q=82'),
 ('Large Sliding-Door Wardrobe','Bedroom',2000,'🚪','Luxury','https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=902&q=82'),
 ('Fabric 2-Seater Sofa','Living Room',1200,'🛋️','Middle','https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=900&q=82'),
 ('L-Shaped Sofa','Living Room',2500,'🛋️','Luxury','https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=901&q=82'),
 ('Leather 3-Seater Sofa','Living Room',3500,'🛋️','Luxury','https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=902&q=82'),
 ('Velvet Premium Sofa','Living Room',4200,'🛋️','Luxury','https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=903&q=82'),
 ('Recliner Sofa','Living Room',4800,'🛋️','Luxury','https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=904&q=82'),
 ('32-inch LED TV','Comfort',1500,'📺','Middle','https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=900&q=82'),
 ('43-inch Smart TV','Comfort',2800,'📺','Luxury','https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=901&q=82'),
 ('55-inch 4K UHD TV','Comfort',4500,'📺','Luxury','https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=902&q=82'),
 ('65-inch OLED TV','Comfort',7500,'📺','Luxury','https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=903&q=82'),
 ('1.0 HP Air Conditioner','Comfort',2800,'❄️','Luxury','https://images.unsplash.com/photo-1631545806609-7e7c3b7c5d8b?auto=format&fit=crop&w=900&q=82'),
 ('1.5 HP Air Conditioner','Comfort',3800,'❄️','Luxury','https://images.unsplash.com/photo-1631545806609-7e7c3b7c5d8b?auto=format&fit=crop&w=901&q=82'),
 ('2.0 HP Air Conditioner','Comfort',5200,'❄️','Luxury','https://images.unsplash.com/photo-1631545806609-7e7c3b7c5d8b?auto=format&fit=crop&w=902&q=82'),
 ('Portable Air Conditioner','Comfort',2200,'❄️','Luxury','https://images.unsplash.com/photo-1631545806609-7e7c3b7c5d8b?auto=format&fit=crop&w=903&q=82'),
 ('Ceiling Fan','Comfort',450,'🌀','Middle','https://images.unsplash.com/photo-1581276169990-1a1b6d9a9b7b?auto=format&fit=crop&w=900&q=82'),
 ('Standing Fan','Comfort',350,'🌀','Middle','https://images.unsplash.com/photo-1581276169990-1a1b6d9a9b7b?auto=format&fit=crop&w=901&q=82'),
 ('Table Fan','Comfort',250,'🌀','Middle','https://images.unsplash.com/photo-1581276169990-1a1b6d9a9b7b?auto=format&fit=crop&w=902&q=82'),
 ('Rechargeable Fan','Comfort',400,'🔋','Middle','https://images.unsplash.com/photo-1581276169990-1a1b6d9a9b7b?auto=format&fit=crop&w=903&q=82'),
 ('Round Wall Mirror','Bedroom',150,'🪞','Budget','https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=900&q=82'),
 ('Full-Length Mirror','Bedroom',350,'🪞','Middle','https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=901&q=82'),
 ('LED Vanity Mirror','Bedroom',600,'🪞','Middle','https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=902&q=82'),
 ('Decorative Gold Mirror','Bedroom',900,'🪞','Middle','https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=903&q=82'),
 ('2-Person Jacuzzi','Comfort',5500,'🛁','Luxury','https://images.unsplash.com/photo-1620626011761-996317b8d101?auto=format&fit=crop&w=900&q=82'),
 ('4-Person Jacuzzi','Comfort',8500,'🛁','Luxury','https://images.unsplash.com/photo-1620626011761-996317b8d101?auto=format&fit=crop&w=901&q=82'),
 ('6-Person Jacuzzi','Comfort',12000,'🛁','Luxury','https://images.unsplash.com/photo-1620626011761-996317b8d101?auto=format&fit=crop&w=902&q=82'),
 ('Outdoor Hot Tub','Comfort',15000,'🛁','Luxury','https://images.unsplash.com/photo-1620626011761-996317b8d101?auto=format&fit=crop&w=903&q=82'),
 ('Small Wall Kitchen Cabinet','Kitchen',800,'🗄️','Middle','https://images.unsplash.com/photo-1556911220-e15b29be8f8c?auto=format&fit=crop&w=900&q=82'),
 ('Large Wall Kitchen Cabinet','Kitchen',1500,'🗄️','Middle','https://images.unsplash.com/photo-1556911220-e15b29be8f8c?auto=format&fit=crop&w=901&q=82'),
 ('L-Shaped Kitchen Cabinet Set','Kitchen',3500,'🍽️','Luxury','https://images.unsplash.com/photo-1556911220-e15b29be8f8c?auto=format&fit=crop&w=902&q=82'),
 ('Full Kitchen Cabinet Set','Kitchen',6500,'🍽️','Luxury','https://images.unsplash.com/photo-1556911220-e15b29be8f8c?auto=format&fit=crop&w=903&q=82'),
 ('Single Kitchen Sink','Kitchen',450,'🚰','Middle','https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=900&q=82'),
 ('Double Kitchen Sink','Kitchen',750,'🚰','Middle','https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=901&q=82'),
 ('Granite Kitchen Sink','Kitchen',1200,'🚰','Middle','https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=902&q=82'),
 ('Sink with Drainer','Kitchen',1800,'🚰','Luxury','https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=903&q=82'),
 ('Kitchen Base Cabinet','Kitchen',1000,'🗄️','Middle','https://images.unsplash.com/photo-1556911220-e15b29be8f8c?auto=format&fit=crop&w=904&q=82'),
 ('Tall Kitchen Cabinet','Kitchen',1800,'🗄️','Luxury','https://images.unsplash.com/photo-1556911220-e15b29be8f8c?auto=format&fit=crop&w=905&q=82'),
 ('Corner Kitchen Cabinet','Kitchen',2500,'🗄️','Luxury','https://images.unsplash.com/photo-1556911220-e15b29be8f8c?auto=format&fit=crop&w=906&q=82'),
 ('Pantry Storage Cabinet','Kitchen',4000,'🗄️','Luxury','https://images.unsplash.com/photo-1556911220-e15b29be8f8c?auto=format&fit=crop&w=907&q=82')
)
insert into public.furniture_items(name,category,price,icon,image_url,tier)
select i.name,i.category,i.price,i.icon,i.image_url,i.tier
from items i
where not exists (select 1 from public.furniture_items f where lower(f.name)=lower(i.name));

-- Ensure legacy rows have a non-null URL (new rows above have their own URLs).
update public.furniture_items
set image_url = case
 when lower(name) like '%wardrobe%' then 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=900&q=82'
 when lower(name) like '%sofa%' then 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=900&q=82'
 when lower(name) like '%tv%' or lower(name) like '%television%' then 'https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=900&q=82'
 when lower(name) like '%fan%' then 'https://images.unsplash.com/photo-1581276169990-1a1b6d9a9b7b?auto=format&fit=crop&w=900&q=82'
 when lower(name) like '%mirror%' then 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=900&q=82'
 when lower(name) like '%jacuzzi%' or lower(name) like '%hot tub%' then 'https://images.unsplash.com/photo-1620626011761-996317b8d101?auto=format&fit=crop&w=900&q=82'
 when lower(name) like '%sink%' then 'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=900&q=82'
 when lower(name) like '%cabinet%' or lower(name) like '%kitchen%' then 'https://images.unsplash.com/photo-1556911220-e15b29be8f8c?auto=format&fit=crop&w=900&q=82'
 else coalesce(image_url,'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=900&q=82') end
where image_url is null;

-- Verification queries: the new listings should have non-empty URLs.
select category, name, price, image_url from public.furniture_items
where name in ('Two-Door Wardrobe','Three-Door Wardrobe','Large Sliding-Door Wardrobe','Fabric 2-Seater Sofa','32-inch LED TV','2-Person Jacuzzi','Small Wall Kitchen Cabinet','Single Kitchen Sink')
order by category, price;
