-- ACCRA LIFE V43: Boutique tiers, garage parking, invitation alerts, GH₵500 new-user wallet.
-- Review before applying. Uses existing canonical tables furniture_items/player_furniture and cars/player_cars.
-- Existing user balances are never changed by this migration.

begin;

-- Enrich the existing furniture catalogue rather than creating a second shop that can drift out of sync.
alter table public.furniture_items add column if not exists image_url text;
alter table public.furniture_items add column if not exists tier text;
alter table public.cars add column if not exists image_url text;
alter table public.player_cars add column if not exists garage_x numeric not null default 50;
alter table public.player_cars add column if not exists garage_y numeric not null default 50;

-- Seed the requested three-tier furniture catalogue. Re-running this seed does not duplicate named products.
with items(name, category, price, icon, tier, image_url) as (values
 ('Student Mattress on Floor','Bedroom',80,'🛏️','Budget','https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=82'),
 ('Simple Metal Bed','Bedroom',350,'🛏️','Middle','https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=82'),
 ('Wooden Bed + Grey Headboard','Bedroom',800,'🛏️','Middle','https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=82'),
 ('Luxury King Bed + LED','Bedroom',2500,'🛏️','Luxury','https://images.unsplash.com/photo-1616594039964-ae9021a400a0?auto=format&fit=crop&w=900&q=82'),
 ('Clothes Rack + Box','Bedroom',50,'👗','Budget','https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=900&q=82'),
 ('Small 2-Door Wardrobe','Bedroom',350,'👗','Middle','https://images.unsplash.com/photo-1631679706909-1844bbd07221?auto=format&fit=crop&w=900&q=82'),
 ('Large 3-Door Wooden Wardrobe','Bedroom',650,'👗','Middle','https://images.unsplash.com/photo-1631679706909-1844bbd07221?auto=format&fit=crop&w=900&q=82'),
 ('Walk-in Closet','Bedroom',3000,'👗','Luxury','https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=900&q=82'),
 ('Small Mirror + Stool','Bedroom',100,'🪞','Budget','https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=900&q=82'),
 ('Standard Dressing Table','Bedroom',450,'🪞','Middle','https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=900&q=82'),
 ('Luxury Dressing Table with Lights','Bedroom',1200,'🪞','Luxury','https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=900&q=82'),
 ('Bedside Table','Bedroom',180,'🪑','Budget','https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=82'),
 ('Plastic Chair','Living Room',60,'🪑','Budget','https://images.unsplash.com/photo-1503602642458-232111445657?auto=format&fit=crop&w=900&q=82'),
 ('2-Seater Fabric Sofa','Living Room',450,'🛋️','Middle','https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=900&q=82'),
 ('L-Shaped Kente Sofa','Living Room',1200,'🛋️','Middle','https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=900&q=82'),
 ('Luxury Leather Sectional','Living Room',4500,'🛋️','Luxury','https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=900&q=82'),
 ('Small 24-inch Television','Living Room',300,'📺','Middle','https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?auto=format&fit=crop&w=900&q=82'),
 ('43-inch Smart Television','Living Room',900,'📺','Middle','https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?auto=format&fit=crop&w=900&q=82'),
 ('65-inch OLED Television','Living Room',2800,'📺','Luxury','https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?auto=format&fit=crop&w=900&q=82'),
 ('TV Stand','Living Room',250,'🪑','Middle','https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?auto=format&fit=crop&w=900&q=82'),
 ('Curtains','Living Room',120,'🪟','Budget','https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=900&q=82'),
 ('Rug','Living Room',150,'🟫','Budget','https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=900&q=82'),
 ('Coffee Table','Living Room',280,'🪑','Middle','https://images.unsplash.com/photo-1499933374294-4584851497cc?auto=format&fit=crop&w=900&q=82'),
 ('Refrigerator','Kitchen',1200,'🧊','Middle','https://images.unsplash.com/photo-1584568694244-14fbdf83bd30?auto=format&fit=crop&w=900&q=82'),
 ('Cooker','Kitchen',650,'🍳','Middle','https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=900&q=82'),
 ('Microwave','Kitchen',300,'🍲','Middle','https://images.unsplash.com/photo-1585659722983-3a675dabf23d?auto=format&fit=crop&w=900&q=82'),
 ('Kitchen Cabinets','Kitchen',1800,'🗄️','Luxury','https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=900&q=82'),
 ('Standing Fan','Comfort',120,'❄️','Budget','https://images.unsplash.com/photo-1620626011761-996317b8d101?auto=format&fit=crop&w=900&q=82'),
 ('1 HP Air Conditioner','Comfort',1500,'❄️','Middle','https://images.unsplash.com/photo-1620626011761-996317b8d101?auto=format&fit=crop&w=900&q=82'),
 ('Luxury AC + Jacuzzi Package','Comfort',3500,'🛁','Luxury','https://images.unsplash.com/photo-1620626011761-996317b8d101?auto=format&fit=crop&w=900&q=82'),
 ('Plastic Chair + Gaming Table','Gaming',150,'🎮','Budget','https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=900&q=82'),
 ('Gaming Chair','Gaming',600,'🎮','Middle','https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=900&q=82'),
 ('Gaming Desk','Gaming',450,'🖥️','Middle','https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=900&q=82'),
 ('Console','Gaming',900,'🎮','Middle','https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=900&q=82'),
 ('Full Gaming Setup: Desk + Chair + Console','Gaming',3500,'🎮','Luxury','https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=900&q=82')
)
insert into public.furniture_items(name,category,price,icon,image_url,tier)
select i.name,i.category,i.price,i.icon,i.image_url,i.tier
from items i
where not exists (select 1 from public.furniture_items f where lower(f.name)=lower(i.name));

-- Populate tier/image metadata on pre-existing furniture with safe defaults.
update public.furniture_items set tier=coalesce(tier,case when price<200 then 'Budget' when price<1500 then 'Middle' else 'Luxury' end) where tier is null;

-- Seed the requested Garage items into the existing vehicle catalogue.
with vehicles(brand,name,price,image_url) as (values
 ('Accra Cycles','Bicycle',200,'https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&w=900&q=82'),
 ('Accra Motors','Okada',2500,'https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=900&q=82'),
 ('Accra Transit','Trotro',5000,'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=900&q=82'),
 ('Toyota','Corolla',12000,'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=900&q=82'),
 ('Range Rover','Sport',40000,'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=900&q=82')
)
insert into public.cars(brand,name,price,image_url)
select v.brand,v.name,v.price,v.image_url from vehicles v
where not exists (select 1 from public.cars c where lower(c.name)=lower(v.name) and lower(coalesce(c.brand,''))=lower(v.brand));

-- Persist garage positions only for a vehicle owned by the authenticated player.
create or replace function public.move_garage_vehicle(p_car_id uuid,p_x numeric,p_y numeric)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_uid uuid:=auth.uid();
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  if p_x is null or p_y is null or p_x<2 or p_x>82 or p_y<5 or p_y>68 then raise exception 'Garage position is outside the allowed area'; end if;
  update public.player_cars set garage_x=p_x,garage_y=p_y where player_id=v_uid and car_id=p_car_id;
  if not found then raise exception 'You do not own this vehicle'; end if;
  return jsonb_build_object('success',true,'car_id',p_car_id,'x',p_x,'y',p_y);
end;
$$;
revoke all on function public.move_garage_vehicle(uuid,numeric,numeric) from public,anon;
grant execute on function public.move_garage_vehicle(uuid,numeric,numeric) to authenticated;

-- Send an in-app notification whenever an apartment visit invitation is created.
create or replace function public.notify_apartment_invite()
returns trigger language plpgsql security definer set search_path=public as $$
declare v_sender text; v_home text; v_location text;
begin
  if auth.uid() is not null and new.owner_id <> auth.uid() then
    raise exception 'You can only send an invitation from your own account';
  end if;
  select coalesce(nullif(p.display_name,''),p.username,'A player') into v_sender from public.players p where p.id=new.owner_id;
  select coalesce(pr.name,'Starter Studio'),coalesce(pr.location,'Osu') into v_home,v_location from public.properties pr where pr.id=new.property_id;
  insert into public.notifications(player_id,title,body,type)
  values(new.guest_id,'House invitation',coalesce(v_sender,'A player')||' invited you to '||coalesce(v_home,'Starter Studio')||' in '||coalesce(v_location,'Osu')||'. Open Homes & Cars to accept or decline.','update');
  return new;
end;
$$;
drop trigger if exists apartment_invite_notification on public.apartment_visits;
create trigger apartment_invite_notification after insert on public.apartment_visits
for each row when (new.status='pending') execute function public.notify_apartment_invite();

-- New accounts start with GH₵500. Existing balances are untouched.
-- This replaces the V41 auth trigger function while preserving username, life path and starter-home setup.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  base_username text;
  chosen_username text;
  chosen_display_name text;
  chosen_path text;
  starting_balance numeric;
begin
  chosen_display_name := left(coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'), ''), nullif(split_part(coalesce(new.email, ''), '@', 1), ''), 'New Player'), 80);
  base_username := lower(regexp_replace(coalesce(nullif(trim(new.raw_user_meta_data->>'username'), ''), nullif(split_part(coalesce(new.email, ''), '@', 1), ''), 'player'), '[^a-zA-Z0-9_]', '', 'g'));
  if base_username = '' then base_username := 'player'; end if;
  chosen_username := left(base_username, 24);
  chosen_path := case when new.raw_user_meta_data->>'life_path' = 'lapo' then 'lapo' else 'semi-rich' end;
  starting_balance := 500;
  begin
    insert into public.players (id, username, display_name, life_path)
    values (new.id, chosen_username, chosen_display_name, chosen_path)
    on conflict (id) do nothing;
  exception when unique_violation then
    chosen_username := left(base_username, 15) || '_' || substr(replace(new.id::text, '-', ''), 1, 8);
    insert into public.players (id, username, display_name, life_path)
    values (new.id, chosen_username, chosen_display_name, chosen_path)
    on conflict (id) do nothing;
  end;
  insert into public.wallets (player_id, balance) values (new.id, starting_balance)
  on conflict (player_id) do nothing;
  if chosen_path = 'semi-rich' then
    insert into public.player_properties (player_id, property_id)
    select new.id, p.id from public.properties p where p.name = 'Starter Studio'
    on conflict (player_id, property_id) do nothing;
  end if;
  return new;
end;
$$;

commit;

-- After applying, verify:
-- select name,category,price,tier,image_url from public.furniture_items order by category,price;
-- select brand,name,price,image_url from public.cars where name in ('Bicycle','Okada','Trotro','Corolla','Sport');
-- Existing wallet balances remain unchanged; only future accounts start with GH₵500.
