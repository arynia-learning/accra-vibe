window.ACCRA_LIFE_CONFIG={supabaseUrl:'https://kpyugkfbkzkuumcpkzkb.supabase.co',supabaseKey:'sb_publishable_XcbbBjF7GpTrAwCcX65Bvw_8o2vmlEm',agoraAppId:'55c1c1507b834ee1a3de3201c4174c4f'};
