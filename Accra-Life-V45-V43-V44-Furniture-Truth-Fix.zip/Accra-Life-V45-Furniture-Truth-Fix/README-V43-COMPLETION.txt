ACCRA LIFE V43 — BOUTIQUE + GARAGE + INVITATION NOTIFICATIONS

This package is based on the existing V42 project and preserves the existing pages, authentication, wallet display, Apartment Life, house view controls, furniture drag UI, and existing property/car purchase RPCs.

Frontend changes:
- Adds Boutique and Garage navigation tabs.
- Boutique displays the existing furniture catalogue with realistic photo URLs, category tabs, Budget/Middle/Luxury filters, and GH₵ prices.
- Existing purchase_furniture RPC is reused so purchases flow into player_furniture and the existing apartment room.
- Garage lists existing cars, uses the existing purchase_car RPC, displays owned vehicles in a garage view, and supports touch/mouse dragging with saved coordinates.
- The front end expects V43 SQL migration to be applied before new tier/photo and garage position features can work fully.

Database migration:
- Adds furniture tier/image_url metadata and seeds the requested furniture categories/prices.
- Adds image_url to cars and seeds Bicycle, Okada, Trotro, Corolla, and Range Rover Sport at the requested prices.
- Adds saved garage positions and secure move_garage_vehicle RPC.
- Creates apartment invitation notifications using the existing apartment_visits flow.
- Changes the new-account starting wallet to GH₵500 without changing existing balances.

IMPORTANT:
- V43 SQL has NOT been applied to the live Supabase project from this package. Review and run V43-BOUTIQUE-GARAGE-STARTING-WALLET-INVITES.sql in Supabase SQL Editor before deploying the frontend.
- The existing user's wallet balance is never overwritten by the migration.
- Images are illustrative remote photo URLs, not the exact bedroom photo previously supplied. Add that reference photo to the project assets if you want the exact matching bed/wardrobe photo.
- This package has not been deployed to Cloudflare Pages or tested against live Supabase end-to-end. JavaScript syntax and ZIP integrity should be checked before use.
