ACCRA LIFE V36 — ROOT-LEVEL DEPLOY PACKAGE

WHY THIS PACKAGE EXISTS
The prior V35 ZIP placed every website file inside an accra_v35_work/ subfolder. Some drag-and-drop hosting flows deploy that nested folder incorrectly or do not replace the existing site root. This package puts index.html, app.js, styles.css, config.js, and the other website files directly at the ZIP root.

WHAT IS INCLUDED
- Premium Ghana-inspired landing page markup and styles in index.html/styles.css.
- Homes & Cars property/vehicle card redesign in app.js/styles.css.
- Enzo Lounge premium visual improvements and safer music-request UI in app.js/styles.css.
- Admin DJ review page: admin-dj.html.
- Proposed SQL migrations and review-first instructions.

DEPLOY SAFELY
1. Extract this ZIP on your device.
2. Open the extracted folder and confirm index.html is immediately visible (not inside another accra_v36 folder).
3. In your existing hosting project's deployment/upload screen, upload ALL extracted files and folders together so index.html is at the site root. Do not upload just the ZIP as a regular website asset.
4. Deploy to the same project/domain that currently serves your live Accra Life site. If using Cloudflare Pages Direct Upload, select the extracted folder whose first level contains index.html. If your host asks for a build output directory, use the extracted folder/root containing index.html.
5. After deployment, hard refresh or open the site in a private tab. Check that the landing page background is cream/green with the Ghana flag and East Legon apartment illustration.

IMPORTANT LIMITATIONS
- This is a deployment package, not proof of a successful live deployment.
- Supabase SQL files are NOT applied automatically. Review them first and back up data.
- No user accounts are deleted.
- Do not claim wallet deduction works until a real test purchase confirms a GH₵1,000 balance becomes GH₵300 after a GH₵700 purchase.
- The package cannot disable a host-injected Netlify badge through website CSS. Disable that in the correct hosting dashboard if it appears.
- Use the exact project/domain currently hosting your site; uploading to a different project will not change the live site.

QUICK PACKAGE CHECK
The archive is arranged with index.html at the ZIP root. It also includes app.js, styles.css, config.js, admin.html, admin-dj.html, reset-password.html, and the supporting SQL/readme files.
