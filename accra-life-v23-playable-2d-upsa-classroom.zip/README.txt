ACCRA LIFE — V23: PLAYABLE 2D WORLD + UPSA LECTURE HALL

WHAT THIS BUILD ADDS
- A visible, populated 2D world scene at the UPSA lecture hall, church, nightclub, gym, cinema, beach and other public locations.
- Clearly labelled NPCs (computer-controlled characters) so public venues do not look abandoned when no real players are online.
- An UPSA classroom scene with a lecture board, lecturer, desks and students seated/listening/taking notes.
- A visible player character that can move around the room using the on-screen direction pad or keyboard arrows / WASD.
- A Sit at a desk action that moves the character to a desk and switches to a seated pose; Study / attend lecture keeps the character seated and changes the visible action.
- Stand, walk, worship, dance, work out, talk and leave-location actions, with the character's visible state updated in the scene.
- Smooth position movement, visible action labels, and live character position metadata sent through Supabase Realtime Presence when available.
- Other real players are drawn into the same venue only while they are currently present in that venue's realtime channel. NPCs are labelled NPC so they are not mistaken for real players.
- House-party scenes include visible party NPCs as well as the host and joined players.
- Existing map, wallet, career, travel, social, furniture, property, settings, notification and activity systems are retained.

IMPORTANT LIMITS
- This is a 2D web-game prototype, not a full 3D game.
- NPCs are local client-side characters; their movement/AI is decorative at this stage. Real-player presence depends on Supabase Realtime being enabled and players using the deployed version of this app.
- Real-time position updates use the existing player_locations table and Realtime Presence; no database schema change is required.
- XP/activity logging and other existing database functions retain their previous implementation and security limitations.
- JavaScript syntax and ZIP integrity were checked. This environment blocked browser-based local preview, so the updated build has not been fully end-to-end tested against the live Supabase project or across multiple real player accounts.

DEPLOY TO YOUR EXISTING NETLIFY SITE
1. Download and unzip this package.
2. Ensure index.html, app.js, styles.css, config.js and README.txt are together in one folder.
3. Open your existing Netlify site dashboard: https://app.netlify.com/
4. Deploy the extracted folder (not the ZIP file itself) to the existing site's manual deploy area. Do not create a new site.
5. Wait for deployment to finish, then open your existing Accra Life public link and refresh. If an old version remains cached, open the link in a private browser tab.

Keep config.js with the other files. It contains the public Supabase client configuration. Never place a Supabase service-role key in a public game package.
