ACCRA VIBE V53 — FRONTEND POLISH PACKAGE

This package builds forward from V52 and preserves the existing app.

Implemented in this package:
- Visible landing/auth branding changed from Accra Life to Accra Vibe.
- Bright cream/white home landing restored; existing illustrated apartment elements are shown again.
- Rebuilt AV PWA icons as clean green-and-gold monograms and updated manifest theme.
- Bumped manifest URL and service-worker cache to V53; icons added to offline shell.
- Ghana flag animation disabled to prevent visual flicker/double-line appearance.
- Map pins/cards explicitly retain tap-friendly behavior.
- Existing Ghana clock uses Africa/Accra; existing map destinations are Accra-specific; existing DJ request writes youtube_video_id:null.

IMPORTANT: this is not a claim that all V53 roadmap systems are live. Wallet deductions, Police/Jail/Court, EOCO, investments/passive income, advanced bank products, live leaderboard, and realtime online count require verified Supabase schema/functions and policies. The frontend currently purchases furniture through the purchase_furniture RPC. Confirm that RPC is deployed and deducts the wallet atomically before considering wallet purchase bugs resolved.

DEPLOY:
1. Upload the contents of this ZIP to the Cloudflare Pages project, replacing the prior frontend files.
2. Hard-refresh the site or remove the installed PWA and reinstall it to refresh icons/cache.
3. In Supabase, verify the V52 SQL migration has been applied (youtube_video_id nullable). Do not run any SQL blindly on production without checking the current schema/backups.
4. Test: sign in, inspect wallet balance, buy one low-cost item, verify both balance and wallet_transactions changed once; submit a DJ request; tap several map pins; install the PWA and check its icon.
