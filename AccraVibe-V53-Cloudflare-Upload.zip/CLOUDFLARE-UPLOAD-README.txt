ACCRA LIFE V50 — CLOUDFLARE PAGES PACKAGE

This ZIP is arranged with index.html, app.js, styles.css, config.js and the other site files at the ZIP ROOT (not inside another enclosing folder). That root layout is important for static-site deployment.

BEFORE DEPLOYING
1. Keep your current Cloudflare deployment. Do not delete the project.
2. Extract this ZIP in the iPhone Files app or on a computer.
3. Upload the CONTENTS of the extracted folder as one Cloudflare Pages deployment. Make sure index.html is at the deployment root.
4. Deploy, then open the site and test sign-in, creating an account, Home, Homes & Cars, Boutique, Garage, music/travel and other tabs.

IMPORTANT LIMITS
- This package does not automatically publish itself to Cloudflare. You must deploy it in the Cloudflare dashboard.
- This code uses the existing Accra Life Supabase project configured in config.js.
- The live-player count is for signed-in sessions connected to Supabase Realtime; it is not a visitor counter. The total joined number uses the accra_total_joined_count() RPC. If Realtime or the RPC is not available, the page shows a dash instead of inventing a number.
- JavaScript syntax was checked with Node.js. This is not the same as a full browser/device test or a successful live Cloudflare deployment.
