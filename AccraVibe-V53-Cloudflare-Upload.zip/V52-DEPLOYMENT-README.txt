ACCRA VIBE V52 — CLOUDFLARE DIRECT UPLOAD

This package starts from the working V51 combined site. It keeps the existing routes, game, accounts, music queue, assets, and Supabase configuration.

WHAT CHANGED
1. Supabase: youtube_video_id is nullable; audio_url and player_settings.preferences exist. DJ review RPCs enforce the configured owner email. The unsafe broad queue update policy was narrowed.
2. PWA: manifest.webmanifest now uses Accra Vibe / AV and new assets/av-icon-192.png + av-icon-512.png. index.html links the manifest and Apple touch icon.
3. Live online count uses the existing Supabase Realtime Presence channel; it is not a fabricated number.
4. Wallet header starts as an em dash until the signed-in account wallet loads from Supabase. Wallet balance stays virtual game currency.
5. Accra clock updates every second using Africa/Accra time.
6. Preferences save locally and try to sync JSON preferences to the signed-in player's player_settings row, with toast feedback.
7. Howler.js is loaded. For licensed direct HTTPS audio files, the DJ console accepts MP3/M4A/OGG/WAV/AAC/OPUS URLs and the player provides tap-to-play/stop controls. YouTube embeds remain available. iPhone playback requires a user tap.
8. Visible branding updated to Accra Vibe. Database names, Supabase config identifiers, and local-storage compatibility keys are intentionally preserved.

DEPLOY
Upload the CONTENTS of this folder (not the containing folder) to Cloudflare Pages Direct Upload as a new Production deployment. Do not delete the old deployment. Test login, wallet, settings, venue requests, and add-to-home-screen before treating the release as fully verified.

IMPORTANT
The actual artwork provided by the user was not attached in this thread, so the AV icon here is a generated text-mark using AV. Replace it with the supplied artwork if that is a different icon. Direct audio URLs must be licensed/authorized; YouTube audio cannot be extracted by Howler, so YouTube stays in its normal embedded player.
