ACCRA LIFE — V44 + HOME SHOP UPDATE

This package preserves the V43/V44 application files and adds a frontend improvement to the Apartment Life furniture section. The Boutique shop and Garage remain in the app; the Apartment Life shop now uses product photo cards, category labels, Ghana-cedi prices, and clear Buy & add to room buttons.

INCLUDED CORE WEBSITE FILES
- index.html
- app.js (updated)
- styles.css
- config.js
- admin.html, admin-dj.html, reset-password.html
- accra-life-games.html

IMPORTANT
- The furniture catalogue is stored in the existing Supabase furniture_items table. The app reads that catalogue and uses the existing purchase_furniture RPC. Existing wallet balances and owned items are not reset by this frontend change.
- The V43 and V44 SQL files and V41/V42 reference SQL are included for traceability. Do not rerun migrations blindly if already applied.
- The existing V44 call setup requires valid Agora configuration; test calls with two accounts/devices before relying on them.

DEPLOY SAFELY TO CLOUDFLARE PAGES
1. Keep a copy of the currently deployed site or use a preview deployment first.
2. Upload/deploy the package's site files together, preserving the root structure. At minimum: index.html, app.js, styles.css, config.js, and supporting HTML files.
3. Do not upload the ZIP itself as the website root; extract it first.
4. After deployment, sign in and test Boutique, Apartment Life, furniture purchase, wallet deduction, furniture ownership/placement, Garage vehicle purchase/parking, and V43/V44 features.

This package has not been deployed to Cloudflare from this environment. Deploy only after you have checked the preview.
