-- ACCRA LIFE V35 MIGRATION — REVIEW BEFORE APPLYING TO LIVE SUPABASE
-- Apply in Supabase SQL Editor only after checking the project and taking a backup.
-- This migration does NOT delete player accounts or change existing wallet balances.

begin;

-- 1) Requested virtual property prices. Name matching is case-insensitive.
update public.properties set price=700 where lower(name) in ('starter studio','starter studio osu');
update public.properties set price=850 where lower(name) in ('madina starter apartment','madina starter');
update public.properties set price=1100 where lower(name)='dome apartment';
update public.properties set price=1400 where lower(name)='haatso apartment';
update public.properties set price=1800 where lower(name)='oyarifa estate townhouse';
update public.properties set price=1500 where lower(name)='east legon apartment';
update public.properties set price=3500 where lower(name) in ('east legon residential plot','east legon plot');
update public.properties set price=3800 where lower(name) in ('ashomman estate house','ashomman estate');
update public.properties set price=4500 where lower(name) in ('sakumono estate home','sakumono estate');
update public.properties set price=5500 where lower(name) in ('mountain view estate villa','mountain view villa');
update public.properties set price=7500 where lower(name)='osu luxury apartment';
update public.properties set price=7500 where lower(name) in ('airport city development plot','airport city plot');
update public.properties set price=10000 where lower(name) in ('cantonments residence','cantonments');

-- Trailer prices are intentionally above entry-level home prices.
update public.cars set price=2500 where lower(name)='utility trailer';
update public.cars set price=4500 where lower(name) in ('cargo trailer','covered cargo trailer');
update public.cars set price=1200 where lower(name) in ('city hatch','accra motors city hatch');
update public.cars set price=1800 where lower(name) in ('compact sedan','accra motors compact sedan');

-- 2) Admin-only review of player song requests. Existing table is used to avoid
-- a parallel request table. Approval requires a valid YouTube ID supplied by admin.
create or replace function public.admin_review_club_song_request(
  p_request_id uuid,
  p_action text,
  p_youtube_video_id text default null
) returns void
language plpgsql
security definer
set search_path = ''
as $function$
declare v_email text := lower(coalesce(auth.jwt() ->> 'email',''));
begin
  if v_email <> 'adwoashowgirl0242@gmail.com' then
    raise exception 'Administrator access required' using errcode='42501';
  end if;
  if p_action not in ('approve','reject') then raise exception 'Action must be approve or reject'; end if;
  if p_action='approve' then
    if p_youtube_video_id is null or p_youtube_video_id !~ '^[A-Za-z0-9_-]{11}$' then raise exception 'Valid YouTube video ID required'; end if;
    update public.club_song_requests set status='played'
      where venue_id='enzo' and status='playing' and id<>p_request_id;
    update public.club_song_requests set youtube_video_id=p_youtube_video_id,status='playing',accepted_at=now()
      where id=p_request_id and venue_id='enzo' and status='pending';
  else
    update public.club_song_requests set status='rejected'
      where id=p_request_id and venue_id='enzo' and status='pending';
  end if;
  if not found then raise exception 'Pending Enzo request not found or already reviewed'; end if;
end;
$function$;
revoke all on function public.admin_review_club_song_request(uuid,text,text) from public,anon;
grant execute on function public.admin_review_club_song_request(uuid,text,text) to authenticated;

-- 3) Keep player-to-player transfers disabled. If already revoked, this is a no-op.
revoke all on function public.send_player_money(uuid,numeric,text) from public,anon,authenticated;

commit;

-- POST-MIGRATION CHECKS (read-only)
select name,location,price from public.properties order by price;
select name,category,price from public.cars order by price;
select has_function_privilege('authenticated','public.admin_review_club_song_request(uuid,text,text)','EXECUTE') as signed_in_can_call_review_rpc;
select has_function_privilege('authenticated','public.send_player_money(uuid,numeric,text)','EXECUTE') as signed_in_can_transfer_game_money;

-- IMPORTANT: the RPC purchase_property must remain the only purchase path. Test with a
-- disposable account and a non-owned property; do not manually edit wallet balances.
-- The requested GH₵700 purchase from GH₵1,000 should leave GH₵300 only if the live
-- Starter Studio record is priced at 700 and purchase_property deducts that price atomically.

-- Account audit only; no account deletions are performed by this migration.
select id,username,display_name,level,experience,created_at from public.players
where lower(coalesce(username,'')) in ('arria','arria.00','mila','chan_xn','hajia','hassan')
order by lower(username),created_at;
