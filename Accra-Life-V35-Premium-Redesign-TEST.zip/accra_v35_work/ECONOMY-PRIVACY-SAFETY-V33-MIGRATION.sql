-- ACCRA LIFE V33 REVIEW-FIRST MIGRATION
-- Review the account-audit query before manually deleting any player records.
-- This script does NOT delete player accounts or modify the live project by itself.

begin;

-- 1) Economy: keep the entry-level studio cheaper than any trailer.
update public.properties
set price = 500, description = coalesce(description, 'Starter home in Accra.')
where lower(name) = 'starter studio';

update public.cars set price = 2500 where lower(name) = 'utility trailer';
update public.cars set price = 4500 where lower(name) = 'cargo trailer';

-- 2) Safe song requests: normal players submit title + artist only.
-- Existing requests can still retain a valid video ID; new requests may omit it.
alter table public.club_song_requests alter column youtube_video_id drop not null;

-- Replace the known test/demo US song request with a Ghanaian demo track.
-- These matching rows were attributed to the demo username Arria; no other requests are changed.
update public.club_song_requests
   set song_title = 'Kwaku the Traveller',
       artist_name = 'Black Sherif',
       youtube_video_id = null
 where lower(song_title) = 'upgrade'
   and lower(artist_name) = 'jessie murph'
   and lower(coalesce(requester_name,'')) = 'arria';

-- 3) DJ queue: disable direct queue updates from all client roles until staff
-- authorization exists. The private owner console can use admin_set_song_link().
drop policy if exists "Signed-in players can operate demo venue queues" on public.club_song_requests;
drop policy if exists "Signed-in Enzo visitors can operate demo DJ queue" on public.club_song_requests;
revoke update on table public.club_song_requests from authenticated;
revoke update on table public.club_song_requests from anon;

-- 3b) Disable the server-side player-to-player transfer RPC too. Hiding the
-- frontend button alone is not a security control. Re-enable only after a
-- server-enforced daily limit and fee have been implemented and tested.
revoke all on function public.send_player_money(uuid, numeric, text) from public, anon, authenticated;

-- Owner-only RPC uses the same owner-email allowlist as the existing dashboard RPC.
create or replace function public.admin_set_song_link(p_request_id uuid, p_youtube_video_id text)
returns void
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_email text := lower(coalesce(auth.jwt() ->> 'email', ''));
begin
  if v_email <> 'adwoashowgirl0242@gmail.com' then
    raise exception 'Administrator access required' using errcode = '42501';
  end if;
  if p_youtube_video_id is null or p_youtube_video_id !~ '^[A-Za-z0-9_-]{11}$' then
    raise exception 'Enter a valid YouTube video ID';
  end if;
  update public.club_song_requests
     set youtube_video_id = p_youtube_video_id
   where id = p_request_id and status in ('pending','playing');
  if not found then raise exception 'Pending or playing song request not found'; end if;
end;
$function$;
revoke all on function public.admin_set_song_link(uuid, text) from public, anon;
grant execute on function public.admin_set_song_link(uuid, text) to authenticated;

commit;

-- ACCOUNT AUDIT (read-only). Review usernames, IDs, and timestamps first.
-- Do NOT delete accounts solely because they are Level 1 / 0 XP; real new users
-- can have those values. Confirm with the owner that each row is a test account.
select id, username, display_name, level, experience, created_at
from public.players
where lower(coalesce(username,'')) in ('arria','arria.00','mila','chan_xn','hajia','hassan')
order by lower(username), created_at;

-- OPTIONAL, DESTRUCTIVE CLEANUP — DO NOT UNCOMMENT UNTIL YOU VERIFY the IDs
-- above are disposable test accounts and confirm you intend to permanently
-- delete Arria, Arria.00, Mila and Chan_xn while preserving Hajia and Hassan.
-- Deleting auth.users will cascade to public.players and dependent game rows.
-- delete from auth.users u
-- using public.players p
-- where u.id = p.id
--   and lower(coalesce(p.username,'')) in ('arria','arria.00','mila','chan_xn');

-- WALLET / PURCHASE VERIFICATION (read-only).
-- purchase_property(uuid) was inspected and already atomically deducts the
-- property price, writes player_properties, and inserts wallet_transactions.
-- Test with a non-owned property in a test account; never manually update balance.
select name, price from public.properties where lower(name) = 'starter studio';
select name, category, price from public.cars where lower(name) in ('utility trailer','cargo trailer');
select policyname, cmd, roles from pg_policies
where schemaname='public' and tablename='club_song_requests' and cmd='UPDATE';
select has_table_privilege('authenticated','public.club_song_requests','UPDATE') as authenticated_can_update_dj_queue;
select has_function_privilege('authenticated','public.send_player_money(uuid,numeric,text)','EXECUTE') as authenticated_can_send_player_money;

-- 4) Respect blocks on the server: a blocked pair cannot start new messages.
create or replace function public.can_message_player(p_recipient_id uuid)
returns boolean
language plpgsql
security definer
set search_path = ''
as $function$
declare v_sender_id uuid := auth.uid();
begin
  if v_sender_id is null or p_recipient_id is null or v_sender_id = p_recipient_id then return false; end if;
  return not exists (
    select 1 from public.blocks b
    where (b.blocker_id = v_sender_id and b.blocked_id = p_recipient_id)
       or (b.blocker_id = p_recipient_id and b.blocked_id = v_sender_id)
  );
end;
$function$;
revoke all on function public.can_message_player(uuid) from public, anon;
grant execute on function public.can_message_player(uuid) to authenticated;
drop policy if exists "players send messages" on public.messages;
drop policy if exists "players send messages unless blocked" on public.messages;
create policy "players send messages unless blocked"
  on public.messages for insert to authenticated
  with check ((select auth.uid()) = sender_id and public.can_message_player(recipient_id));
