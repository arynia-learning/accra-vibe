ACCRA LIFE V35 — PREMIUM REDESIGN & FIXES (TEST PACKAGE)

WHAT'S INCLUDED
- Premium Ghana-first landing page (keeps existing Create/Login account flow IDs working).
- Homes & Cars redesigned as photo cards with current database prices and real purchase buttons.
- Premium Enzo Lounge visual and safer approved YouTube embed (playsinline=1, enablejsapi=1); unapproved requests stay as text and are not embedded.
- Player song requests accept title + artist only (existing UI behavior retained); the private DJ console is available at /admin/dj after the migration and administrator login.
- Netlify badge DOM-removal script was removed. A website script cannot reliably remove a hosting-platform injected badge. Disable it in the actual hosting dashboard if it remains.
- Price and admin-review SQL is included but NOT applied to live Supabase.
- No user accounts were deleted and no live balances were modified.

DEPLOY
1. Download and extract this ZIP.
2. Upload the CONTENTS of the `accra_v35_work` folder to the same hosting project that currently serves your Accra Life website. Keep index.html, app.js, styles.css, config.js, admin-dj.html, and _redirects together.
3. Do not upload only index.html; the site depends on the other files.
4. Confirm the deployment URL is the same live URL you normally use. If the site is on Cloudflare Pages, upload/deploy there; if on Netlify, deploy there. Do not switch platforms by accident.
5. To enable the admin DJ review page, open Supabase SQL Editor for the existing Accra Life project, review `V35-SUPABASE-MIGRATION-REVIEW-FIRST.sql`, and run it only after checking that the owner email allowlist matches the actual admin account. The SQL is staged and has not been run by this package build.
6. After deployment, open `https://YOUR-DOMAIN/admin/dj`, sign in with the configured admin account, and test one request. If the admin email differs, update the allowlist in the SQL function before applying it.

IMPORTANT LIMITATIONS / TESTS REQUIRED
- This package was edited offline. It has not been deployed to your host and has not been browser-tested against your live Supabase data.
- Property photos use remote Unsplash URLs and need internet access. Prices shown on cards come from the database; run the SQL migration to change stored prices. Do not rely on a visual-only price override.
- The live wallet purchase must be verified after migration with a disposable test account. A GH₵700 purchase from GH₵1,000 should leave GH₵300 only if the server RPC and actual property price are correct.
- The admin console uses the existing `club_song_requests` table, not a separate `dj_requests` table, to stay compatible with the existing site schema. Requests are title/artist-only; only the administrator supplies the video ID.
- This migration intentionally does not delete Arria, Arria.00, Mila, Chan_xn or any other account. Low XP alone is not proof an account is fake.
- The visual crowd/rating figures in the brief were not hard-coded as real analytics. The scene says Accra nightlife rather than inventing actual visit counts.
- Host-injected Netlify badges must be turned off in the hosting dashboard; code-only hiding is unreliable and was removed to avoid deleting unrelated page elements.

CHECKS PERFORMED DURING PACKAGE BUILD
- JavaScript syntax checks (Node.js) are run after build.
- ZIP archive integrity check is run after packaging.
- These checks do not replace live deployment, DB migration, or wallet purchase testing.
