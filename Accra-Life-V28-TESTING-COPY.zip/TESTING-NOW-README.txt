ACCRA LIFE V28 — SEPARATE TESTING COPY

Purpose
This is a separate copy for testing username search, profiles, private messaging, and virtual game-money shortcuts. It does not replace the existing Netlify website.

Files
The archive preserves the V28 website files and existing site assets.

Before testing
1. Host this ZIP as a NEW project/site (do not upload over the existing Netlify site). Cloudflare Pages supports direct-upload ZIP files for static sites.
2. Sign in using two separate Accra Life test accounts.
3. Test Find People, open a profile, share a profile, send/reply to a message, and send a small amount of virtual game money.
4. Check both accounts to confirm the messages and balances update.

Important
- This is a testing copy, not a verified production release. JavaScript syntax was checked, but a full browser test with two accounts has not been completed.
- Messaging and transfers depend on the existing Supabase backend and policies.
- Game money is simulated in-game currency only. No real money, MTN MoMo, or Telecel Cash is used.
- Do not publish over the existing Accra Life Netlify site until the test succeeds.
