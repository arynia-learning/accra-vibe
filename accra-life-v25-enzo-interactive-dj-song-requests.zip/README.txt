ACCRA LIFE — V24: PLAYABLE UPSA CLASSROOM

FOCUS OF THIS BUILD
This version improves the UPSA lecture-hall experience instead of adding more unrelated menus.

- The classroom has a lecture board, lecturer, door, room sign and two rows of desks.
- Eight named student NPCs are visible in the classroom and have seated poses and listening / note-taking states.
- Your character starts by the classroom door, rather than in the middle of the room.
- Movement controls animate the character walking to the new position; on a computer, use arrow keys or WASD.
- “Sit at a desk” makes the character walk to the nearest desk before sitting.
- “Attend lecture” moves the character to a desk if needed, then changes the character to a seated studying pose with a writing animation.
- “Stand up” visibly changes the character's pose.
- “Leave location” walks the character to the classroom door before returning to the map.
- Clicking a student NPC gives a short contextual dialogue line.
- Other venue scenes and the existing Accra Life systems are retained.
- Realtime presence still depends on Supabase Realtime being available and other real players using the same deployed version.

HONEST TEST STATUS
JavaScript syntax and ZIP integrity checks are performed on this package. A full browser session and a multi-account live multiplayer test are not available in this build environment, so deploy to a test site or your existing site and verify the in-game behavior.

DEPLOY TO YOUR EXISTING NETLIFY SITE
1. Download and unzip this package.
2. Keep index.html, app.js, styles.css and config.js together in one folder.
3. Open your existing site in the Netlify dashboard: https://app.netlify.com/
4. Deploy the extracted folder to the existing site's manual deploy area. Do not create a new site.
5. Open your existing Accra Life public link and refresh. If the old version remains cached, try a private browser tab.

The Supabase client key in config.js is a public publishable key. Never add a service-role key to a public game package.


V25 — ENZO LOUNGE INTERACTIVE DJ & SONG REQUESTS

NEW FEATURES
- The map destination is labelled Enzo Lounge (Osu, Accra).
- Song request form asks for song title, artist, and a YouTube link.
- A shared request queue is stored in Supabase and refreshes every 3.5 seconds.
- A demo DJ control can start the next pending request; all clients see the shared now-playing state.
- Players tap “Play song here” to open the accepted YouTube video in an embedded player with sound. Mobile browsers may block autoplay, so each player may need to tap to start playback. Some videos do not allow embedding.
- The player does not download or host copyrighted songs. Use official/authorized uploads and respect rights-holder restrictions.
- DJ controls are intentionally open to all authenticated players for this prototype; production should restrict them to authorized DJ/staff roles and use an atomic server-side queue RPC.

REQUIRED SUPABASE SETUP
1. Open Supabase Dashboard for project kpyugkfbkzkuumcpkzkb.
2. Go to SQL Editor and run supabase-v25-enzo-song-requests.sql.
3. Deploy the five web files to your EXISTING Netlify site: index.html, app.js, styles.css, config.js, README.txt.
4. Sign in, open the map, enter Enzo Lounge, submit a song request with a valid YouTube link, then tap DJ play next.
5. To test shared queue, open the game in a second signed-in account/browser and visit Enzo. It should see the queue and now-playing track; tap Play song here on that device to hear it.

LIMITATIONS / TEST STATUS
- The song request data and status synchronize through Supabase polling, not frame-perfect audio synchronization.
- Audio playback is YouTube embedded playback; availability, embedding, ads, and autoplay are controlled by YouTube and browser settings. This does not guarantee every submitted song will play.
- This package has JavaScript syntax and ZIP integrity checks. No authenticated end-to-end browser test or real two-account test was available during build.
- No database changes were applied automatically. Run the SQL migration above before testing the request queue.
