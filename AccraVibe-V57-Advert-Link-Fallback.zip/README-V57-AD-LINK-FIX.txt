ACCRA VIBE V57 — MINIMAL AD LINK FALLBACK

This package is based on V56 and changes only the ad destination handling in index.html and app.js. All other website files and features are preserved.

If an ad's saved destination begins with http://accravibe.app or https://accravibe.app (including www), its Open advert / Visit business link temporarily redirects to the current Cloudflare Pages site: https://jamila-dnm.pages.dev, preserving any path after the domain. Other ad links are unchanged.

IMPORTANT: This is a temporary code fallback. It does NOT make accr avibe.app itself resolve in Safari. The custom domain still needs to be connected to the existing Cloudflare Pages project and its DNS records corrected in the domain DNS provider. Do not set this up on Vercel unless the site is actually hosted there.

Deployment: upload the extracted files to the existing Cloudflare Pages project (jamila-dnm), Production. Do not create a new project.
