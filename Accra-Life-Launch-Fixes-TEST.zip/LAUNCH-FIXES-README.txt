ACCRA LIFE — LAUNCH FIXES TEST BUILD

This is a separate upload package based on the previously saved Accra-Life-Owner-Dashboard-Password-Reset-Fix-CLEAN project. It does not overwrite the live Netlify site by itself.

Included code changes:
- Settings masks the account email (for example, j***@gmail.com).
- Wallet keeps the wording “virtual money only, cannot send real money” and “Payment sandbox.”
- Player-to-player transfers are disabled in the wallet UI and guarded in the client action/profile flow until the GH₵200/day limit is implemented.
- Social discovery removes duplicate player IDs and duplicate usernames from the displayed list.
- Shared song playback no longer embeds YouTube; the external “Open song in YouTube” link remains.
- Public song queue no longer displays the DJ “play next” control.

Important deployment/security notes:
- This package has not been deployed to the live site.
- Client-side transfer blocking is a launch UI guard, not a substitute for disabling the send_player_money RPC/server-side database function. Disable/revoke that RPC at the database level before public launch.
- Duplicate backend/test accounts have NOT been deleted, because the source alone cannot safely identify which records are test users versus real users. Remove test accounts only after checking account IDs and protecting real users; keep exactly one Arria only if verified as the intended account.
- “Online now” is currently shown for players whose presence is detected at the same venue. A reliable global online indicator would need global heartbeat/presence support; this build does not falsely label all players as globally online.
- “Powered by Netlify” is a hosting dashboard badge, not an HTML element in these source files. Disable it in Netlify site settings if enabled.
- The wallet balance is database-driven and is not hardcoded to GH₵850.00, so each user's real virtual balance is not overwritten.

Upload all package files together to a separate test deployment first. Do not replace the live deployment until the test site has been checked.
