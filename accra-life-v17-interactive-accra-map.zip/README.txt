ACCRA LIFE V17 — INTERACTIVE ACCRA MAP + PLACE PAGES

This update adds a dedicated Map tab with an illustrated, clickable game-style map of Accra and destination cards for:
- UPSA
- University of Ghana, Legon
- Hostels & Student Homes
- Accra Mall
- Osu Oxford Street
- Labadi Beach
- East Legon Lounges
- Apartments & Homes

Players can tap a map pin or a place card to open its place page, view an illustrative photo, read about the destination, see available game activities, and choose GO TO THIS PLACE. The game then updates the current location labels and attempts to save the location in the existing player_locations table. The selected location is restored on later logins when the database read is available.

IMPORTANT NOTES
- This is a game-style schematic map, not a live GPS or road-navigation map.
- Place photos are illustrative images loaded from Unsplash; they are not guaranteed to be photographs of the exact named Ghana location.
- This is a front-end package. The public Netlify website does not change until the files are deployed there.
- JavaScript syntax was checked locally. Full browser and live-account testing has not been performed from this workspace.

DEPLOY
1. Download and extract this ZIP.
2. Upload index.html, app.js, styles.css and config.js together to the root of the existing Netlify site.
3. Keep config.js connected to the same Supabase project; never place a service-role or secret key in public frontend code. This package uses the project's publishable key.
4. Deploy the CONTENTS of the extracted folder to the site publish root—not the ZIP file itself.
5. Open the public site in a private/incognito browser or on a second phone and sign in with a test account.
6. Open Map, tap a pin, open a place page, and select GO TO THIS PLACE. Confirm the header location updates and that no permission/database errors appear in the browser console.
