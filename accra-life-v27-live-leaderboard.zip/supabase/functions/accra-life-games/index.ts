import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
function reply(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}
Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return reply({ error: "Use POST." }, 405);
  try {
    const url = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const authHeader = req.headers.get("Authorization") ?? "";
    const token = authHeader.replace(/^Bearer\s+/i, "");
    if (!url || !serviceKey) return reply({ error: "Game service is not configured." }, 500);
    if (!token || token === authHeader) return reply({ error: "Please sign in to play." }, 401);
    const db = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
    const { data: userData, error: userError } = await db.auth.getUser(token);
    const user = userData?.user;
    if (userError || !user) return reply({ error: "Your session is invalid or expired. Please sign in again." }, 401);
    const metadata = user.user_metadata ?? {};
    const displayName = String(metadata.full_name ?? metadata.name ?? user.email?.split("@")[0] ?? "New Player").slice(0, 80);
    const username = String(metadata.username ?? user.email?.split("@")[0] ?? "").toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 30);
    const { data: player, error: playerLookupError } = await db.from("players").select("id").eq("id", user.id).maybeSingle();
    if (playerLookupError) throw playerLookupError;
    if (!player) {
      const { error: createPlayerError } = await db.from("players").upsert({ id: user.id, username: username || null, display_name: displayName }, { onConflict: "id", ignoreDuplicates: true });
      if (createPlayerError) throw createPlayerError;
    }
    const body = await req.json().catch(() => ({}));
    const action = body?.action;
    const playerId = user.id;

    if (action === "games") {
      const { data, error } = await db.from("games").select("id,slug,title,description,game_type,difficulty,points_per_correct").eq("is_active", true).order("title");
      if (error) throw error;
      return reply({ games: data ?? [] });
    }
    if (action === "start") {
      const slug = String(body?.slug ?? "").trim();
      if (!slug || slug.length > 80) return reply({ error: "Choose a valid game." }, 400);
      const { data: game, error: gameError } = await db.from("games").select("id,slug,title,description,game_type,difficulty").eq("slug", slug).eq("is_active", true).maybeSingle();
      if (gameError) throw gameError;
      if (!game) return reply({ error: "That game is unavailable." }, 404);
      const { data: questions, error: questionError } = await db.from("game_questions").select("id,prompt,options,difficulty,points,question_order").eq("game_id", game.id).eq("is_active", true).order("question_order");
      if (questionError) throw questionError;
      if (!questions?.length) return reply({ error: "This game has no questions yet." }, 409);
      const { data: attempt, error: attemptError } = await db.from("game_attempts").insert({ player_id: playerId, game_id: game.id, status: "started", score: 0, questions_answered: 0, correct_answers: 0 }).select("id,started_at").single();
      if (attemptError) throw attemptError;
      return reply({ game, attempt_id: attempt.id, started_at: attempt.started_at, questions });
    }
    if (action === "answer") {
      const attemptId = String(body?.attempt_id ?? "");
      const questionId = String(body?.question_id ?? "");
      const selectedAnswer = String(body?.selected_answer ?? "");
      if (!attemptId || !questionId || !selectedAnswer || selectedAnswer.length > 300) return reply({ error: "Select an answer before submitting." }, 400);
      const { data, error } = await db.rpc("submit_game_answer", { p_player_id: playerId, p_attempt_id: attemptId, p_question_id: questionId, p_selected_answer: selectedAnswer });
      if (error) return reply({ error: error.message || "Could not submit your answer." }, 400);
      return reply(data);
    }
    if (action === "finish") {
      const attemptId = String(body?.attempt_id ?? "");
      if (!attemptId) return reply({ error: "Game attempt is missing." }, 400);
      const { data, error } = await db.rpc("finish_game_attempt", { p_player_id: playerId, p_attempt_id: attemptId });
      if (error) return reply({ error: error.message || "Could not finish the game." }, 400);
      return reply(data);
    }
    if (action === "history") {
      const { data, error } = await db.from("game_attempts").select("id,game_id,score,questions_answered,correct_answers,duration_seconds,status,started_at,completed_at,games(title,slug)").eq("player_id", playerId).eq("status", "completed").order("completed_at", { ascending: false }).limit(20);
      if (error) throw error;
      return reply({ history: data ?? [] });
    }
    if (action === "live_leaderboard") {
      const slug = String(body?.slug ?? "").trim();
      if (!slug || slug.length > 80) return reply({ error: "Choose a valid game." }, 400);
      const { data: game, error: gameError } = await db.from("games").select("id,slug,title").eq("slug", slug).eq("is_active", true).maybeSingle();
      if (gameError) throw gameError;
      if (!game) return reply({ error: "That game is unavailable." }, 404);
      // A recent started attempt is considered active; old abandoned attempts naturally expire.
      const activeSince = new Date(Date.now() - 30 * 60 * 1000).toISOString();
      const { data: attempts, error: attemptsError } = await db.from("game_attempts")
        .select("id,player_id,score,correct_answers,questions_answered,started_at,players(username,display_name)")
        .eq("game_id", game.id).eq("status", "started").gte("started_at", activeSince)
        .order("score", { ascending: false }).order("correct_answers", { ascending: false }).order("started_at", { ascending: true }).limit(50);
      if (attemptsError) throw attemptsError;
      const players = (attempts ?? []).map((row: any) => ({
        username: row.players?.username || row.players?.display_name || "Player",
        score: row.score ?? 0, correct_answers: row.correct_answers ?? 0,
        questions_answered: row.questions_answered ?? 0, started_at: row.started_at,
        is_you: row.player_id === playerId,
      }));
      return reply({ game: game.title, active_players: players.length, players });
    }
    if (action === "leaderboard") {
      const { data, error } = await db.from("game_attempts").select("player_id,score,correct_answers,questions_answered,duration_seconds,completed_at,games(title,slug),players(username,display_name)").eq("status", "completed").order("score", { ascending: false }).order("duration_seconds", { ascending: true }).limit(100);
      if (error) throw error;
      const best = new Map<string, unknown>();
      for (const row of (data ?? []) as any[]) if (!best.has(row.player_id)) best.set(row.player_id, {
        username: row.players?.username ?? row.players?.display_name ?? "Player", score: row.score,
        correct_answers: row.correct_answers, questions_answered: row.questions_answered,
        duration_seconds: row.duration_seconds, game: row.games?.title ?? "Game", completed_at: row.completed_at,
      });
      return reply({ leaderboard: Array.from(best.values()).slice(0, 20) });
    }
    return reply({ error: "Unknown game action." }, 400);
  } catch (err) {
    console.error("accra-life-games error", err);
    return reply({ error: "Something went wrong while processing the game. Please try again." }, 500);
  }
});
