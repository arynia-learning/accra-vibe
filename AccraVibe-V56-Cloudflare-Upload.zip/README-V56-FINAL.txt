ACCRA VIBE V56 — PHONE / THEME / ADS POLISH

Included:
- Accra Phone has 28 Ghana-themed app icons in a four-column, seven-row grid.
- Phone status uses live Africa/Accra time plus 4G, signal and battery indicators; black rounded phone frame, notch, purple-to-orange gradient and Accra skyline.
- Settings Off/On/Auto applies a persistent light/dark/system theme using localStorage and html data-theme.
- Sound, music, data saver and lite graphics controls apply the available browser-level effects.
- My Ads uses the existing Supabase ad_slots table and city_create_ad_slot RPC. Billboard GH₵1,500 and sea-plot GH₵50 are virtual-wallet charges for seven days.
- Active adverts are shown in the existing city-map ad list and a new Home spotlight carousel. /my-ads opens the SPA to My Ads; /advertise is a public information page.
- DJ song duplicate checks already exist in the current app and were preserved.

Not enabled / still requiring more work:
- Real-money Paystack/MoMo/card checkout is NOT enabled. It requires the owner's payment-provider credentials, verified payment webhooks, reconciliation and production review.
- The public advertise page is informational; it does not yet accept external business submissions or real payments.
- Secure image file upload and self-service image replacement are not implemented; the in-game advert form currently accepts an image URL.
- A 3D billboard model placed into the map world is not implemented; adverts are shown in the map ad list and Home carousel.
- Some phone icons route to existing related sections; not every icon is a unique, fully developed application.
- Theme and ad flows still need live-browser testing after Cloudflare deployment.

The Supabase ad_slots table and city_create_ad_slot RPC were created in the V55 database migration. This ZIP includes the existing V55 base plus V56 front-end polish. Deploy to the existing Cloudflare project; do not create a new project.
