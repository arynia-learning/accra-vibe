ACCRA LIFE V16 — PUBLIC LOAD SAFETY + VISIBLE FLIGHT JOURNEY

This update preserves the V15 animated flight experience and improves the public page when a script or game service fails to load. The landing page is forced to remain visible, and a readable retry message appears instead of silently failing.
- Select Economy, Premium Economy, Business or First Class.
- The selected fare is paid through the existing Supabase book_travel function.
- A flight screen shows the class, ticket fare, destination, route, clouds and a visibly moving aircraft.
- Status changes through takeoff, cruising and descent; players can skip the animation.
- At arrival, the screen shows a landing message and updates the visible location labels before returning to Travel.

DEPLOY
1. Extract this ZIP.
2. Upload index.html, app.js, styles.css and config.js together to the root of the existing Netlify site.
3. Keep config.js connected to the same Supabase project; do not replace it with a different project's configuration.
4. In Netlify, deploy the CONTENTS of the extracted folder to the site publish root—not the ZIP file itself. Make sure all four files are uploaded together and the published site is the same URL you send to your friend.
5. Open the published URL in a private/incognito browser or on a second phone before sharing it. Test sign-up with a test account and then test a flight using enough virtual game currency.

The aircraft animation is a game visual, not a real-time flight tracker. It runs after the game successfully books the trip. JavaScript syntax is checked locally. The live Netlify deployment cannot be verified from this workspace; publishing these files is still required before the public link changes.
