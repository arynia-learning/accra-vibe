(() => {
  'use strict';
  const cfg = window.ACCRA_LIFE_CONFIG || {};
  if (!window.supabase || typeof window.supabase.createClient !== 'function') { const m=document.getElementById('loadFallback'); if(m)m.style.display='block'; return; }
  if (!cfg.supabaseUrl || !cfg.supabaseKey) { const m=document.getElementById('loadFallback'); if(m)m.style.display='block'; return; }
  const sb = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseKey);
  const $ = id => document.getElementById(id);
  let mode = 'signup', user = null, profile = null, activeTab = 'home', selectedRecipient = null, notificationPoll = null, lastNotificationId = null;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const money = value => Number(value || 0).toLocaleString('en-GH', {minimumFractionDigits:2, maximumFractionDigits:2});
  const toast = message => { const t=$('toast'); t.textContent=message; t.classList.add('show'); clearTimeout(toast.timer); toast.timer=setTimeout(()=>t.classList.remove('show'),3200); };
  const errorText = error => error?.message || 'Something went wrong. Please try again.';
  const setBusy = (button, busy, label) => { if (!button) return; button.disabled=busy; if (busy) {button.dataset.oldLabel=button.textContent;button.textContent=label||'Please wait…';} else if(button.dataset.oldLabel){button.textContent=button.dataset.oldLabel;delete button.dataset.oldLabel;} };
  function showAuth(next='signup') { mode=next; $('landing').classList.add('hidden'); $('game').classList.add('hidden'); $('auth').classList.remove('hidden'); $('authTitle').textContent=mode==='signup'?'Create your life':'Welcome back'; $('authSub').textContent=mode==='signup'?'Choose a name. Start your story.':'Your Accra story is waiting.'; $('usernameWrap').classList.toggle('hidden',mode!=='signup'); $('password').autocomplete=mode==='signup'?'new-password':'current-password'; $('authSubmit').textContent=mode==='signup'?'Create my Accra Life':'Log in'; $('switchAuth').textContent=mode==='signup'?'I already have an account':'Create a new account'; $('authMsg').textContent=''; $('authMsg').className='msg'; }
  function showLanding(){ $('auth').classList.add('hidden'); $('game').classList.add('hidden'); $('landing').classList.remove('hidden'); }
  async function loadProfile(u){
    const result=await sb.from('players').select('*').eq('id',u.id).maybeSingle();
    if(result.error) throw result.error;
    if(result.data){profile=result.data;return profile;}
    const raw=(u.user_metadata?.display_name||u.user_metadata?.username||u.email?.split('@')[0]||'New Player').trim();
    const username=raw.toLowerCase().replace(/[^a-z0-9_]/g,'').slice(0,24)||('player_'+u.id.slice(0,8));
    const inserted=await sb.from('players').insert({id:u.id,username,display_name:raw.slice(0,80)}).select('*').single();
    if(inserted.error){const retry=await sb.from('players').select('*').eq('id',u.id).maybeSingle();if(retry.error||!retry.data)throw inserted.error;profile=retry.data;}else profile=inserted.data;
    return profile;
  }
  async function enterGame(u){
    user=u;
    try { await loadProfile(u); $('landing').classList.add('hidden');$('auth').classList.add('hidden');$('game').classList.remove('hidden');$('welcome').textContent=`Welcome, ${profile.display_name||'Player'}`; $('level').textContent=profile.level||1; $('xp').textContent=`${profile.experience||0} XP`; $('footerStatus').textContent='CONNECTED'; await refreshWallet(); await openTab('home'); startNotificationPolling(); }
    catch(e){console.error(e);$('game').classList.add('hidden');$('auth').classList.remove('hidden');$('authMsg').textContent=`We couldn't load your player profile: ${errorText(e)}`;$('authMsg').className='msg';}
  }
  async function refreshWallet(){ if(!user)return; const r=await sb.from('wallets').select('balance').eq('player_id',user.id).maybeSingle(); if(r.error){$('balance').textContent='—';console.warn(r.error);return;} $('balance').textContent=money(r.data?.balance); }
  async function refreshProfile(){ if(!user)return; const r=await sb.from('players').select('*').eq('id',user.id).maybeSingle();if(r.data){profile=r.data;$('welcome').textContent=`Welcome, ${profile.display_name||'Player'}`;$('level').textContent=profile.level||1;$('xp').textContent=`${profile.experience||0} XP`;} }
  function panel(html){$('panel').innerHTML=html;}
  function header(kicker,title,subtitle,side=''){return `<div class="panel-head"><div><div class="section-label">${esc(kicker)}</div><h2>${esc(title)}</h2><p class="sub">${esc(subtitle)}</p></div>${side}</div>`;}
  function empty(text){return `<div class="empty">${esc(text)}</div>`;}
  async function openTab(tab){
    activeTab=tab;document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));panel('<div class="loading">Loading your Accra story…</div>');
    try {
      if(tab==='home') return await renderHome();
      if(tab==='work') return await renderWork();
      if(tab==='travel') return await renderTravel();
      if(tab==='assets') return await renderAssets();
      if(tab==='social') return await renderSocial();
      if(tab==='wallet') return await renderWallet();
      if(tab==='business') return await renderBusiness();
      if(tab==='notifications') return await renderNotifications();
      if(tab==='settings') return await renderSettings();
    } catch(e){console.error(e);panel(`${header('A LITTLE SETBACK','Could not load this section',errorText(e))}<button class="action-btn" data-reload="${esc(tab)}">Try again</button>`);}
  }
  async function renderHome(){
    const [wallet,job,home,car,travel]=await Promise.all([
      sb.from('wallets').select('balance').eq('player_id',user.id).maybeSingle(),
      sb.from('player_jobs').select('job_id,jobs(name,salary)').eq('player_id',user.id).maybeSingle(),
      sb.from('player_properties').select('property_id').eq('player_id',user.id),
      sb.from('player_cars').select('car_id').eq('player_id',user.id),
      sb.from('travel_bookings').select('id').eq('player_id',user.id)
    ]);
    panel(`${header('YOUR LIFE IN ACCRA','Your Accra, your rules','Start small, build your reputation, and make your next move.')}<div class="grid"><div class="feature-card" data-tab="work"><div class="feature-icon">💼</div><h3>Build a career</h3><p>${job.data?.jobs?.name?`Current role: ${esc(job.data.jobs.name)}`:'Find your first job and earn a salary.'}</p><span class="card-link">EXPLORE WORK ↗</span></div><div class="feature-card" data-tab="assets"><div class="feature-icon">🏡</div><h3>Own your space</h3><p>${home.data?.length||0} home(s) · ${car.data?.length||0} car(s). Work toward the life you want.</p><span class="card-link">HOMES & CARS ↗</span></div><div class="feature-card" data-tab="travel"><div class="feature-icon">🌍</div><h3>See the world</h3><p>${travel.data?.length||0} trip(s) booked. Explore Ghana and destinations beyond.</p><span class="card-link">PLAN A TRIP ↗</span></div><div class="feature-card" data-tab="social"><div class="feature-icon">🤝</div><h3>Meet your people</h3><p>Discover other players and grow your circle.</p><span class="card-link">GO SOCIAL ↗</span></div><div class="feature-card" data-tab="wallet"><div class="feature-icon">₵</div><h3>Manage your money</h3><p>Your current game balance is GH₵ ${money(wallet.data?.balance)}.</p><span class="card-link">OPEN WALLET ↗</span></div><div class="feature-card" data-tab="business"><div class="feature-icon">📈</div><h3>Think bigger</h3><p>Start a business or explore in-game investments.</p><span class="card-link">BUILD WEALTH ↗</span></div></div>`);
  }
  async function renderWork(){
    const [jobs,chosen]=await Promise.all([sb.from('jobs').select('*').order('salary',{ascending:false}),sb.from('player_jobs').select('job_id,jobs(name,salary,last_salary_at)').eq('player_id',user.id).maybeSingle()]);
    if(jobs.error)throw jobs.error;
    const current=chosen.data?.jobs;
    panel(`${header('CAREER & INCOME','Work in Accra','Choose a path, then claim your game salary when it becomes available.',`<button class="action-btn" data-action="salary">Claim salary</button>`)}${current?`<div class="stat-card" style="margin-bottom:14px"><span class="label">YOUR CURRENT JOB</span><strong>${esc(current.name)}</strong><p class="sub">GH₵ ${money(current.salary)} per hour in game</p></div>`:''}<div class="grid">${(jobs.data||[]).map(j=>`<article class="item-card"><span class="pill">${esc(j.category||'Career')}</span><h3>${esc(j.name)}</h3><p>${esc(j.description||'Work hard and grow your career in Accra.')}</p><div class="price">GH₵ ${money(j.salary)} <small style="color:var(--muted);font-size:10px">/ hour</small></div><button data-hire="${j.id}" ${chosen.data?.job_id===j.id?'disabled':''}>${chosen.data?.job_id===j.id?'Current job':'Choose this job'}</button></article>`).join('')||empty('No jobs are available yet.')}</div>`);
  }
  async function renderTravel(){
    const [destinations,bookings]=await Promise.all([sb.from('travel_destinations').select('*').order('base_fare'),sb.from('travel_bookings').select('id,travel_class,fare,status,booked_at,travel_destinations(name,country,city)').eq('player_id',user.id).order('booked_at',{ascending:false}).limit(6)]);
    if(destinations.error)throw destinations.error;
    const classes=['Economy','Premium Economy','Business','First Class'];
    panel(`${header('GET OUT THERE','Explore beyond Accra','Pick a destination and travel class. Fares are paid from your in-game wallet.')}<div class="field-inline"><label for="travelClass" class="sub">Travel class</label><select id="travelClass">${classes.map(c=>`<option>${c}</option>`).join('')}</select></div><div class="grid">${(destinations.data||[]).map(d=>`<article class="item-card"><span class="pill">${esc(d.region||'International')}</span><h3>✈ ${esc(d.city||d.name)}</h3><p>${esc(d.country||'Destination')} ${d.airport_code?`· ${esc(d.airport_code)}`:''}<br>${Number(d.distance_km||0).toLocaleString()} km from home</p><div class="price">From GH₵ ${money(d.base_fare)}</div><button data-dest="${d.id}">Book this trip</button></article>`).join('')||empty('Destinations are being prepared.')}</div><h3 style="margin:24px 0 8px;font-size:15px">Your recent trips</h3><div class="tx-list">${(bookings.data||[]).map(b=>`<div class="tx"><div><b>${esc(b.travel_destinations?.city||b.travel_destinations?.name||'Trip')}</b><small>${esc(b.travel_class)} · ${esc(b.status)} · ${b.booked_at?new Date(b.booked_at).toLocaleDateString():''}</small></div><strong class="negative">−GH₵ ${money(b.fare)}</strong></div>`).join('')||empty('Your booked trips will appear here.')}</div>`);
  }
  async function renderAssets(){
    const [properties,cars,ownedP,ownedC,furniture,ownedFurniture,visits,players]=await Promise.all([
      sb.from('properties').select('*').order('price'),
      sb.from('cars').select('*').order('price'),
      sb.from('player_properties').select('property_id,properties(name,location,property_type)').eq('player_id',user.id),
      sb.from('player_cars').select('car_id').eq('player_id',user.id),
      sb.from('furniture_items').select('*').order('price'),
      sb.from('player_furniture').select('id,item_id,quantity,pos_x,pos_y,furniture_items(name,category,icon)').eq('player_id',user.id),
      sb.from('apartment_visits').select('*').or(`owner_id.eq.${user.id},guest_id.eq.${user.id}`).order('created_at',{ascending:false}).limit(30),
      sb.from('players').select('id,display_name,username').neq('id',user.id).order('display_name').limit(100)
    ]);
    if(properties.error)throw properties.error;if(cars.error)throw cars.error;
    const pids=new Set((ownedP.data||[]).map(x=>x.property_id)),cids=new Set((ownedC.data||[]).map(x=>x.car_id));
    const props=ownedP.data||[], guests=players.data||[], visitRows=visits.data||[];
    const hostIds=[...new Set(visitRows.map(v=>v.owner_id).filter(id=>id!==user.id))];
    const guestIds=[...new Set(visitRows.map(v=>v.guest_id).filter(id=>id!==user.id))];
    const allIds=[...new Set([...hostIds,...guestIds])];
    let nameMap={};
    if(allIds.length){const names=await sb.from('players').select('id,display_name,username').in('id',allIds);(names.data||[]).forEach(p=>nameMap[p.id]=p.display_name||p.username||'Player');}
    const propIds=[...new Set(visitRows.map(v=>v.property_id))];let propMap={};
    if(propIds.length){const names=await sb.from('properties').select('id,name,location').in('id',propIds);(names.data||[]).forEach(p=>propMap[p.id]=p);}
    const ownedRoom=props[0];
    const roomFurniture=(ownedFurniture.data||[]).map((f,i)=>`<span class="room-piece" style="left:${Math.min(82,12+(i%5)*17)}%;bottom:${12+Math.floor(i/5)*16}px" title="${esc(f.furniture_items?.name||'Furniture')}">${esc(f.furniture_items?.icon||'🪑')}</span>`).join('');
    const incoming=visitRows.filter(v=>v.guest_id===user.id&&v.status==='pending');
    const outgoing=visitRows.filter(v=>v.owner_id===user.id&&v.status==='pending');
    const accepted=visitRows.filter(v=>(v.owner_id===user.id||v.guest_id===user.id)&&v.status==='accepted');
    const apartmentHtml=`<section class="apartment-section"><div class="section-label">YOUR PRIVATE SPACE</div><h3 style="font-size:18px;margin:0 0 7px">🏡 Apartment life</h3><p class="sub" style="margin-bottom:14px">Buy a home, furnish your room, then invite friends over. Invitations appear in their notifications.</p>
      ${ownedRoom?`<div class="apartment-room"><div class="room-window"><span></span><span></span><span></span></div><div class="room-wall-art">ACCRA<br><small>HOME</small></div><div class="room-floor"></div><div class="room-sofa">🛋️</div><div class="room-plant">🪴</div>${roomFurniture}<div class="room-label"><b>${esc(ownedRoom.properties?.name||'Your apartment')}</b><small>${esc(ownedRoom.properties?.location||'Accra')} · Your home</small></div></div>
      <div class="two-col" style="margin-top:12px"><div class="stat-card"><span class="label">INVITE SOMEONE OVER</span><div class="field"><label for="guestSelect-${ownedRoom.property_id}">Choose a player</label><select id="guestSelect-${ownedRoom.property_id}" class="control"><option value="">Choose a friend</option>${guests.map(g=>`<option value="${g.id}">${esc(g.display_name||g.username||'Player')}</option>`).join('')}</select></div><button class="action-btn" data-invite-property="${ownedRoom.property_id}">Send apartment invitation</button></div><div class="stat-card"><span class="label">MAKE IT YOURS</span><p class="sub" style="margin:10px 0">Furniture owned: ${(ownedFurniture.data||[]).reduce((n,f)=>n+Number(f.quantity||1),0)}. Add pieces to make your apartment feel like home.</p><div class="room-inventory">${(ownedFurniture.data||[]).map(f=>`<span class="pill">${esc(f.furniture_items?.icon||'🪑')} ${esc(f.furniture_items?.name||'Furniture')} ×${f.quantity||1}</span>`).join('')||'<span class="sub">Your room is waiting for its first furniture.</span>'}</div></div></div>
      <h4 style="font-size:14px;margin:22px 0 10px">Furniture shop</h4><div class="grid">${(furniture.data||[]).map(f=>`<article class="item-card"><div class="feature-icon">${esc(f.icon||'🪑')}</div><h3>${esc(f.name)}</h3><p>${esc(f.category||'Home decor')}</p><div class="price">GH₵ ${money(f.price)}</div><button data-buy-furniture="${f.id}">Buy & add to room</button></article>`).join('')||empty('More furniture is coming soon.')}</div>`:`<div class="empty">You need to own an apartment before you can furnish it or invite guests.</div><p class="sub">Purchase a property above to unlock your private apartment.</p>`}
      <h4 style="font-size:14px;margin:22px 0 10px">Apartment invitations</h4>
      ${incoming.map(v=>`<div class="tx"><div><b>🏡 ${esc(nameMap[v.owner_id]||'A player')} invited you over</b><small>${esc(propMap[v.property_id]?.name||'Apartment')} · ${new Date(v.created_at).toLocaleString()}</small></div><div class="invite-actions"><button class="action-btn" data-visit-response="accepted" data-visit-id="${v.id}">Accept</button><button class="action-btn" data-visit-response="declined" data-visit-id="${v.id}">Decline</button></div></div>`).join('')||'<p class="sub">No incoming apartment invitations.</p>'}
      ${outgoing.map(v=>`<div class="tx"><div><b>Invitation sent to ${esc(nameMap[v.guest_id]||'Player')}</b><small>${esc(propMap[v.property_id]?.name||'Apartment')} · Waiting for a response</small></div><span class="pill">Pending</span></div>`).join('')}
      ${accepted.map(v=>{const other=v.owner_id===user.id?nameMap[v.guest_id]:nameMap[v.owner_id];return `<div class="tx"><div><b>🏠 ${v.owner_id===user.id?'Your guest: ':'You can visit: '}${esc(other||'Player')}</b><small>${esc(propMap[v.property_id]?.name||'Apartment')} · Invitation accepted</small></div><button class="action-btn" data-open-apartment="${v.id}">Visit apartment</button></div>`}).join('')}
      </section>`;
    panel(`${header('BUILD YOUR DREAM LIFE','Homes & cars','Buy a place, make it your own, and invite other players over.')}<h3 style="font-size:15px;margin:12px 0">🏡 Properties</h3><div class="grid">${(properties.data||[]).map(x=>`<article class="item-card"><span class="pill">${esc(x.property_type)}</span><h3>${esc(x.name)}</h3><p>${esc(x.location||'Accra')}<br>${esc(x.description||'A place to call your own.')}</p><div class="price">GH₵ ${money(x.price)}</div><button data-buy-property="${x.id}" ${pids.has(x.id)?'disabled':''}>${pids.has(x.id)?'Owned':'Purchase property'}</button></article>`).join('')||empty('Properties coming soon. ')} </div><h3 style="font-size:15px;margin:25px 0 12px">🚘 Cars</h3><div class="grid">${(cars.data||[]).map(x=>`<article class="item-card"><span class="pill">${esc(x.category||'Vehicle')}</span><h3>${esc(x.brand||'')} ${esc(x.name)}</h3><p>Get around Accra in style.</p><div class="price">GH₵ ${money(x.price)}</div><button data-buy-car="${x.id}" ${cids.has(x.id)?'disabled':''}>${cids.has(x.id)?'Owned':'Purchase car'}</button></article>`).join('')||empty('Cars coming soon.')}</div>${apartmentHtml}`);
  }
  async function renderSocial(){
    const [players,friends]=await Promise.all([sb.from('players').select('id,display_name,username,level,experience').neq('id',user.id).order('level',{ascending:false}).limit(30),sb.from('friendships').select('id,requester_id,addressee_id,status,requester:players!friendships_requester_id_fkey(display_name,username),addressee:players!friendships_addressee_id_fkey(display_name,username)').or(`requester_id.eq.${user.id},addressee_id.eq.${user.id}`).order('created_at',{ascending:false}).limit(30)]);
    const rels=friends.data||[];const related=new Set(rels.map(f=>f.requester_id===user.id?f.addressee_id:f.requester_id));
    const recentMessages=await sb.from('messages').select('id,sender_id,recipient_id,body,created_at,read_at').or(`sender_id.eq.${user.id},recipient_id.eq.${user.id}`).order('created_at',{ascending:false}).limit(12);
    const messagePlayers=players.data||[];
    panel(`${header('PEOPLE & COMMUNITY','Your social circle','Meet players, send friend requests and message each other.')}<div class="stat-card message-compose"><span class="label">SEND A MESSAGE</span><div class="field"><label for="messageRecipient">Choose a player</label><select id="messageRecipient" class="control"><option value="">Choose a player</option>${messagePlayers.map(p=>`<option value="${p.id}">${esc(p.display_name||p.username||'Player')}</option>`).join('')}</select></div><div class="field"><label for="messageBody">Your message</label><textarea id="messageBody" class="control" maxlength="1000" rows="3" placeholder="Write a message…"></textarea></div><button class="action-btn" data-action="send-message">Send message</button></div><h3 style="font-size:15px;margin:24px 0 10px">Recent messages</h3><div class="tx-list">${(recentMessages.data||[]).map(m=>{const other=messagePlayers.find(p=>p.id===(m.sender_id===user.id?m.recipient_id:m.sender_id));return `<div class="tx"><div><b>${m.sender_id===user.id?'You → ':''}${esc(other?.display_name||other?.username||'Player')}</b><small>${esc(m.body)}<br>${m.created_at?new Date(m.created_at).toLocaleString():''}</small></div><span class="pill">${m.sender_id===user.id?'Sent':(m.read_at?'Read':'Received')}</span></div>`}).join('')||empty('Your conversations will appear here.')}</div><h3 style="font-size:15px;margin:24px 0 10px">Discover players</h3><div class="grid">${messagePlayers.map(p=>{const rel=rels.find(f=>f.requester_id===p.id||f.addressee_id===p.id);let label='Add friend',disabled=false;if(rel){if(rel.status==='accepted'){label='Friends';disabled=true;}else if(rel.status==='pending'){label=rel.requester_id===user.id?'Request sent':'Respond in requests';disabled=true;}}return `<article class="item-card"><div class="feature-icon">👤</div><h3>${esc(p.display_name||p.username||'Player')}</h3><p>@${esc(p.username||'player')}<br>Level ${p.level||1} · ${p.experience||0} XP</p><button data-friend="${p.id}" ${disabled?'disabled':''}>${label}</button></article>`}).join('')||empty('You are one of the first players here. Invite a friend to join you!')}</div><h3 style="font-size:15px;margin:24px 0 10px">Friend requests & connections</h3><div class="tx-list">${rels.map(f=>{const incoming=f.addressee_id===user.id&&f.status==='pending';const name=f.requester_id===user.id?(f.addressee?.display_name||f.addressee?.username):(f.requester?.display_name||f.requester?.username);return `<div class="tx"><div><b>${esc(name||'Player')}</b><small>${esc(f.status)}${incoming?' · incoming request':''}</small></div>${incoming?`<button class="action-btn" data-accept-friend="${f.id}">Accept</button>`:''}</div>`}).join('')||empty('No friend requests yet.')}</div>`);
  }
  async function renderWallet(){
    const [wallet,tx]=await Promise.all([sb.from('wallets').select('balance').eq('player_id',user.id).maybeSingle(),sb.from('wallet_transactions').select('*').eq('player_id',user.id).order('created_at',{ascending:false}).limit(20)]);
    if(wallet.error)throw wallet.error;
    const players=await sb.from('players').select('id,display_name,username').neq('id',user.id).order('display_name').limit(100);
    panel(`${header('YOUR MONEY','Game wallet','This balance is virtual game currency. It is not real cash and cannot currently be withdrawn.')}<div class="two-col"><div class="stat-card"><span class="label">AVAILABLE GAME BALANCE</span><strong>GH₵ ${money(wallet.data?.balance)}</strong><p class="sub" style="margin-top:8px">Earn in-game salary, manage spending and keep track of your moves.</p></div><div class="stat-card"><span class="label">PLAYER-TO-PLAYER TRANSFER</span><div class="field" style="margin:12px 0"><label for="recipientSelect">Send to a player</label><select id="recipientSelect" class="control"><option value="">Choose a player</option>${(players.data||[]).map(p=>`<option value="${p.id}">${esc(p.display_name||p.username)}</option>`).join('')}</select></div><div class="field-inline"><input id="transferAmount" type="number" min="0.01" step="0.01" placeholder="Amount (GH₵)"><input id="transferNote" maxlength="100" placeholder="Note (optional)"></div><button class="action-btn" data-action="transfer">Send game money</button></div></div><h3 style="font-size:15px;margin:24px 0 8px">Recent transactions</h3><div class="tx-list">${(tx.data||[]).map(t=>`<div class="tx"><div><b>${esc(t.description||t.transaction_type||'Transaction')}</b><small>${t.created_at?new Date(t.created_at).toLocaleString():''}</small></div><strong class="${Number(t.amount)>=0?'positive':'negative'}">${Number(t.amount)>=0?'+':'−'}GH₵ ${money(Math.abs(Number(t.amount)))}</strong></div>`).join('')||empty('Your game transactions will appear here.')}</div>`);
  }
  async function renderNotifications(){
    const r=await sb.from('notifications').select('*').eq('player_id',user.id).order('created_at',{ascending:false}).limit(50);
    if(r.error) throw r.error;
    const rows=r.data||[];
    const unread=rows.filter(n=>!n.read_at).map(n=>n.id);
    if(unread.length){const upd=await sb.from('notifications').update({read_at:new Date().toISOString()}).in('id',unread).eq('player_id',user.id);if(upd.error)console.warn(upd.error);}
    updateNotificationBadge(0);
    panel(`${header('YOUR ACTIVITY','Notifications','Messages, money transfers, friend requests and other important updates.')}<div class="tx-list">${rows.map(n=>`<div class="tx notification-row ${n.read_at?'':'unread'}"><div><b>${esc(n.title||'Accra Life update')}</b><small>${esc(n.body||'')}<br>${n.created_at?new Date(n.created_at).toLocaleString():''}</small></div><span class="pill">${esc(n.type||'update')}</span></div>`).join('')||empty('You’re all caught up. New messages and money transfers will appear here.')}</div>`);
  }
  async function renderSettings(){
    const r=await sb.from('player_settings').select('notifications_enabled').eq('player_id',user.id).maybeSingle();
    if(r.error)throw r.error;
    const enabled=r.data?.notifications_enabled!==false;
    panel(`${header('YOUR ACCOUNT','Settings','Manage your profile, security and in-game notification preferences.')}<div class="two-col"><div class="stat-card"><span class="label">PROFILE</span><div class="field"><label for="settingsDisplayName">Display name</label><input id="settingsDisplayName" class="control" maxlength="80" value="${esc(profile?.display_name||'')}" /></div><button class="action-btn" data-action="save-display-name">Save display name</button><div class="field"><label>Email address</label><input class="control" value="${esc(user?.email||'')}" disabled /></div><div class="field"><label for="settingsEmail">Change email address</label><input id="settingsEmail" class="control" type="email" placeholder="New email address" /></div><button class="action-btn" data-action="change-email">Request email change</button><p class="sub" style="margin-top:8px">Supabase may email you a confirmation link before the new address takes effect.</p></div><div class="stat-card"><span class="label">SECURITY & NOTIFICATIONS</span><div class="field"><label for="settingsPassword">New password</label><input id="settingsPassword" class="control" type="password" minlength="6" placeholder="At least 6 characters" /></div><button class="action-btn" data-action="change-password">Update password</button><hr style="border:0;border-top:1px solid var(--line);margin:22px 0"><label class="settings-toggle"><input id="notificationsEnabled" type="checkbox" ${enabled?'checked':''}><span><b>In-game notifications</b><small>Receive alerts for messages, money received and friend requests.</small></span></label><button class="action-btn" data-action="save-settings" style="margin-top:16px">Save notification settings</button><hr style="border:0;border-top:1px solid var(--line);margin:22px 0"><button class="action-btn danger-btn" data-action="settings-logout">Log out of Accra Life</button></div></div>`);
  }
  function updateNotificationBadge(count){const el=$('notificationCount');if(!el)return;el.textContent=String(count);el.classList.toggle('has-count',count>0);}
  async function pollNotifications(showNew=false){
    if(!user)return;
    const settings=await sb.from('player_settings').select('notifications_enabled').eq('player_id',user.id).maybeSingle();
    if(settings.data?.notifications_enabled===false){updateNotificationBadge(0);return;}
    const r=await sb.from('notifications').select('id,title,body,type,created_at').eq('player_id',user.id).is('read_at',null).order('created_at',{ascending:false}).limit(20);
    if(r.error){console.warn(r.error);return;}
    const rows=r.data||[];updateNotificationBadge(rows.length);
    if(showNew&&rows.length){const newest=rows[0];if(lastNotificationId&&newest.id!==lastNotificationId){toast(`${newest.title||'New Accra Life notification'}${newest.body?' — '+newest.body:''}`);}lastNotificationId=newest.id;}
    else if(rows.length&&!lastNotificationId){lastNotificationId=rows[0].id;}
  }
  function startNotificationPolling(){if(notificationPoll)clearInterval(notificationPoll);lastNotificationId=null;pollNotifications(false);notificationPoll=setInterval(()=>pollNotifications(true),12000);}
  async function renderBusiness(){
    const [owned,investments]=await Promise.all([sb.from('businesses').select('*').eq('owner_id',user.id).order('created_at',{ascending:false}),sb.from('investments').select('*').eq('player_id',user.id).order('created_at',{ascending:false})]);
    panel(`${header('ENTREPRENEURSHIP','Build something of your own','Businesses and investments use game currency. Spend carefully; this is a simulation.')}<div class="two-col"><div class="stat-card"><span class="label">START A BUSINESS</span><div class="field"><label for="bizName">Business name</label><input id="bizName" class="control" maxlength="60" placeholder="e.g. Jamilatu’s Boutique"></div><div class="field-inline"><select id="bizCategory" class="control"><option>Fashion</option><option>Food & drink</option><option>Transport</option><option>Beauty</option><option>Technology</option><option>Retail</option><option>Entertainment</option></select><select id="bizLocation" class="control"><option>Osu</option><option>East Legon</option><option>Madina</option><option>Airport</option><option>Labadi</option><option>Accra Central</option></select></div><div class="field"><label for="bizPrice">Startup cost (GH₵)</label><input id="bizPrice" class="control" type="number" min="100" step="50" value="500"></div><button class="action-btn" data-action="create-business">Launch business</button></div><div class="stat-card"><span class="label">IN-GAME INVESTMENT</span><div class="field"><label for="assetName">Investment name</label><input id="assetName" class="control" maxlength="60" placeholder="e.g. Local food venture"></div><div class="field-inline"><input id="investAmount" class="control" type="number" min="10" step="10" placeholder="Principal GH₵"><input id="investRate" class="control" type="number" min="0" max="100" step="1" value="5" placeholder="Return %"></div><div class="field"><label for="investDays">Game holding period</label><select id="investDays" class="control"><option value="1">1 day</option><option value="7" selected>7 days</option><option value="30">30 days</option></select></div><button class="action-btn" data-action="create-investment">Make investment</button><p class="sub" style="margin-top:9px">Returns are game mechanics, not real-world financial advice.</p></div></div><h3 style="font-size:15px;margin:24px 0 10px">Your businesses</h3><div class="grid">${(owned.data||[]).map(b=>`<article class="item-card"><span class="pill">${esc(b.category)}</span><h3>${esc(b.name)}</h3><p>${esc(b.location||'Accra')}<br>Game revenue: GH₵ ${money(b.revenue)}</p><div class="price">Startup: GH₵ ${money(b.price)}</div></article>`).join('')||empty('Your first business could be listed here.')}</div><h3 style="font-size:15px;margin:24px 0 10px">Your investments</h3><div class="tx-list">${(investments.data||[]).map(i=>`<div class="tx"><div><b>${esc(i.asset_name)}</b><small>${esc(i.status)} · ${i.matured_at?`Matures ${new Date(i.matured_at).toLocaleDateString()}`:'Active'}</small></div><strong>GH₵ ${money(i.principal)}</strong></div>`).join('')||empty('No investments yet.')}</div>`);
  }
  async function doRpc(name,args,success,refresh=true){const r=await sb.rpc(name,args);if(r.error){toast(errorText(r.error));return false;}toast(success);if(refresh){await refreshWallet();await refreshProfile();await openTab(activeTab);}return true;}
  function showFlightExperience(destination,travelClass,booking){
    return new Promise(resolve=>{
      document.querySelector('.flight-overlay')?.remove();
      const city=destination.city||booking.destination||destination.name||'your destination';
      const country=destination.country||booking.country||'Destination';
      const fare=booking.fare;
      const overlay=document.createElement('div');
      overlay.className='hire-modal-overlay flight-overlay';
      overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-labelledby','flightTitle');
      overlay.innerHTML=`<div class="flight-modal">
        <div class="flight-topline"><span class="section-label">ACCRA LIFE AIR</span><span class="flight-class">${esc(travelClass)}</span></div>
        <h2 id="flightTitle">Accra <span>→</span> ${esc(city)}</h2>
        <p class="flight-subtitle" id="flightStatus" aria-live="polite">Your flight is preparing for takeoff…</p>
        <div class="flight-scene" id="flightScene"><div class="flight-sun"></div><div class="flight-cloud cloud-one">☁</div><div class="flight-cloud cloud-two">☁</div><div class="flight-cloud cloud-three">☁</div><div class="flight-route-line"></div><div class="flight-plane" aria-label="Animated aircraft">✈</div><div class="flight-airport from-airport"><b>ACC</b><small>ACCRA</small></div><div class="flight-airport to-airport"><b>${esc((destination.airport_code||city.slice(0,3)).toUpperCase())}</b><small>${esc(city.toUpperCase())}</small></div><div class="flight-runway"></div></div>
        <div class="flight-progress"><span id="flightProgress"></span></div>
        <div class="flight-details"><div><small>TRAVEL CLASS</small><b>${esc(travelClass)}</b></div><div><small>TICKET</small><b>GH₵ ${money(fare)}</b></div><div><small>DESTINATION</small><b>${esc(country)}</b></div></div>
        <p class="flight-note" id="flightNote">Please fasten your seat belt. Your journey is underway.</p>
        <button type="button" class="primary full" id="flightContinue" disabled>Flying…</button>
        <button type="button" class="flight-skip" id="flightSkip">Skip animation</button>
      </div>`;
      document.body.appendChild(overlay);
      const status=overlay.querySelector('#flightStatus'),note=overlay.querySelector('#flightNote'),continueBtn=overlay.querySelector('#flightContinue'),plane=overlay.querySelector('.flight-plane'),progress=overlay.querySelector('#flightProgress');
      let ended=false,stageTimer=[];
      const arrive=()=>{
        if(ended)return;ended=true;stageTimer.forEach(clearTimeout);
        overlay.querySelector('#flightScene').classList.add('landed');
        status.textContent=`Welcome to ${city}!`;note.textContent='You have landed safely. Your Accra Life location has been updated.';
        continueBtn.disabled=false;continueBtn.textContent=`Arrive in ${city}`;
        overlay.querySelector('#flightSkip').style.display='none';
        progress.style.width='100%';
      };
      const close=async()=>{
        if(!ended){arrive();}
        overlay.remove();
        $('locationText').textContent=`${city.toUpperCase()}${country&&country!=='Ghana'?', '+country.toUpperCase():''}`;
        $('sceneZone').textContent=`${city.toUpperCase()}, ${country.toUpperCase()}`;
        $('footerStatus').textContent='LANDED';
        await refreshWallet();await refreshProfile();await openTab('travel');resolve();
      };
      continueBtn.addEventListener('click',close);
      overlay.querySelector('#flightSkip').addEventListener('click',arrive);
      overlay.addEventListener('click',e=>{if(e.target===overlay&&ended)close();});
      stageTimer.push(setTimeout(()=>{status.textContent='Taking off from Accra…';note.textContent='The aircraft is lifting off and climbing into the sky.';},900));
      stageTimer.push(setTimeout(()=>{status.textContent=`In the air · En route to ${city}`;note.textContent='Look out the window—your aircraft is moving across the sky.';},2600));
      stageTimer.push(setTimeout(()=>{status.textContent='Beginning descent…';note.textContent=`The crew is preparing to land in ${city}.`;},6500));
      stageTimer.push(setTimeout(arrive,9000));
      // CSS drives the visible aircraft flight; this interval provides a simple progress display.
      const started=Date.now();const progressTimer=setInterval(()=>{if(ended){clearInterval(progressTimer);return;}progress.style.width=Math.min(98,((Date.now()-started)/9000)*100)+'%';},100);
    });
  }
  function showHireConfirmation(jobName,salary){
    document.querySelector('.hire-modal-overlay')?.remove();
    const overlay=document.createElement('div');
    overlay.className='hire-modal-overlay';
    overlay.setAttribute('role','dialog');
    overlay.setAttribute('aria-modal','true');
    overlay.setAttribute('aria-labelledby','hireModalTitle');
    overlay.innerHTML=`<div class="hire-modal"><div class="hire-modal-check">✓</div><div class="section-label">A NEW CHAPTER BEGINS</div><h2 id="hireModalTitle">Congratulations, ${esc(profile?.display_name||'Arria')}!</h2><p>You've been hired as <strong>${esc(jobName)}</strong>.</p><p class="hire-modal-sub">Your career in Accra starts now. Keep building your reputation and growing your wallet.</p>${salary!=null?`<div class="hire-modal-salary">GH₵ ${money(salary)} <small>per hour in game</small></div>`:''}<button type="button" class="primary full" id="hireModalContinue">Continue playing</button></div>`;
    document.body.appendChild(overlay);
    const close=()=>overlay.remove();
    overlay.querySelector('#hireModalContinue').addEventListener('click',close);
    overlay.addEventListener('click',e=>{if(e.target===overlay)close();});
    overlay.querySelector('#hireModalContinue').focus();
  }
  $('loginBtn').onclick=()=>showAuth('login');$('signupBtn').onclick=()=>showAuth('signup');$('backBtn').onclick=showLanding;$('switchAuth').onclick=()=>showAuth(mode==='signup'?'login':'signup');
  $('authForm').onsubmit=async e=>{e.preventDefault();const button=$('authSubmit');setBusy(button,true,mode==='signup'?'Creating your life…':'Logging in…');$('authMsg').textContent='';$('authMsg').className='msg';const email=$('email').value.trim(),password=$('password').value,name=$('username').value.trim();try{let r;if(mode==='signup'){if(!name){$('authMsg').textContent='Choose a player name first.';return;}r=await sb.auth.signUp({email,password,options:{data:{username:name,display_name:name},emailRedirectTo:location.origin}});if(r.error)throw r.error;if(r.data.session&&r.data.user){await enterGame(r.data.user);}else{$('authMsg').className='msg ok';$('authMsg').textContent='Account created. If email confirmation is enabled, confirm your email, then log in.';}}else{r=await sb.auth.signInWithPassword({email,password});if(r.error)throw r.error;await enterGame(r.data.user);}}catch(err){$('authMsg').textContent=errorText(err);}finally{setBusy(button,false);}};
  $('tabs').addEventListener('click',e=>{const b=e.target.closest('[data-tab]');if(b)openTab(b.dataset.tab);});
  $('panel').addEventListener('click',async e=>{
    const tab=e.target.closest('[data-tab]')?.dataset.tab;if(tab){await openTab(tab);return;}
    const reload=e.target.closest('[data-reload]')?.dataset.reload;if(reload){await openTab(reload);return;}
    const hire=e.target.closest('[data-hire]')?.dataset.hire;if(hire){
      const jobResult=await sb.from('jobs').select('name,salary').eq('id',hire).maybeSingle();
      if(jobResult.error){toast(errorText(jobResult.error));return;}
      const jobName=jobResult.data?.name||'your new role';
      const hired=await doRpc('hire_for_job',{p_job_id:hire},'You have been hired!');
      if(hired) showHireConfirmation(jobName,jobResult.data?.salary);
      return;
    }
    const dest=e.target.closest('[data-dest]')?.dataset.dest;if(dest){
      const cls=$('travelClass')?.value||'Economy';
      const button=e.target.closest('[data-dest]');setBusy(button,true,'Booking flight…');
      try{
        const [destinationResult,bookingResult]=await Promise.all([
          sb.from('travel_destinations').select('id,name,city,country,airport_code,base_fare').eq('id',dest).maybeSingle(),
          sb.rpc('book_travel',{p_destination_id:dest,p_travel_class:cls})
        ]);
        if(bookingResult.error)throw bookingResult.error;
        const destination=destinationResult.data||{};
        await showFlightExperience(destination,cls,bookingResult.data||{});
      }catch(err){toast(errorText(err));setBusy(button,false);}
      return;
    }
    const prop=e.target.closest('[data-buy-property]')?.dataset.buyProperty;if(prop){await doRpc('purchase_property',{p_property_id:prop},'Property purchased!');return;}
    const car=e.target.closest('[data-buy-car]')?.dataset.buyCar;if(car){await doRpc('purchase_car',{p_car_id:car},'Car purchased!');return;}
    const inviteProperty=e.target.closest('[data-invite-property]')?.dataset.inviteProperty;
    if(inviteProperty){
      const guestId=$(`guestSelect-${inviteProperty}`)?.value;
      if(!guestId){toast('Choose a player to invite first.');return;}
      const result=await sb.from('apartment_visits').insert({owner_id:user.id,guest_id:guestId,property_id:inviteProperty,status:'pending'});
      if(result.error){toast(errorText(result.error));return;}
      toast('Apartment invitation sent! They will receive a notification.');await openTab('assets');return;
    }
    const visitId=e.target.closest('[data-visit-id]')?.dataset.visitId;
    const visitResponse=e.target.closest('[data-visit-response]')?.dataset.visitResponse;
    if(visitId&&visitResponse){const result=await sb.from('apartment_visits').update({status:visitResponse,responded_at:new Date().toISOString()}).eq('id',visitId).eq('guest_id',user.id);if(result.error){toast(errorText(result.error));return;}toast(visitResponse==='accepted'?'Invitation accepted! You can now visit the apartment.':'Invitation declined.');await openTab('assets');return;}
    const furnitureId=e.target.closest('[data-buy-furniture]')?.dataset.buyFurniture;
    if(furnitureId){const result=await sb.rpc('purchase_furniture',{p_item_id:furnitureId,p_pos_x:15+Math.floor(Math.random()*65),p_pos_y:20+Math.floor(Math.random()*35)});if(result.error){toast(errorText(result.error));return;}toast('Furniture purchased and added to your apartment!');await refreshWallet();await openTab('assets');return;}
    const openVisit=e.target.closest('[data-open-apartment]')?.dataset.openApartment;
    if(openVisit){const r=await sb.from('apartment_visits').select('*').eq('id',openVisit).in('status',['accepted']).maybeSingle();if(r.error||!r.data){toast('This apartment visit is no longer available.');return;}const v=r.data;if(v.owner_id!==user.id&&v.guest_id!==user.id){toast('You are not part of this invitation.');return;}const hostId=v.owner_id;const [host,home,decor]=await Promise.all([sb.from('players').select('display_name,username').eq('id',hostId).maybeSingle(),sb.from('properties').select('name,location').eq('id',v.property_id).maybeSingle(),sb.from('player_furniture').select('quantity,furniture_items(name,icon)').eq('player_id',hostId)]);const hostName=host.data?.display_name||host.data?.username||'Your friend';const pieces=(decor.data||[]).map(f=>`<span class="room-piece" style="position:static;display:inline-block;margin:8px;font-size:30px">${esc(f.furniture_items?.icon||'🪑')}<small style="display:block;font-size:10px">${esc(f.furniture_items?.name||'Furniture')} ×${f.quantity||1}</small></span>`).join('');document.querySelector('.apartment-visit-overlay')?.remove();const overlay=document.createElement('div');overlay.className='hire-modal-overlay apartment-visit-overlay';overlay.innerHTML=`<div class="hire-modal apartment-visit-modal"><div class="section-label">YOU'RE VISITING</div><h2>${esc(home.data?.name||'Apartment')}</h2><p>${esc(hostName)}'s home · ${esc(home.data?.location||'Accra')}</p><div class="guest-room-preview"><div class="room-window"><span></span><span></span><span></span></div><div class="room-floor"></div><div class="room-sofa">🛋️</div><div class="room-plant">🪴</div>${pieces}</div><p class="hire-modal-sub">You're visiting another player's apartment in Accra Life.</p><button class="primary full" id="closeApartmentVisit">Leave apartment</button></div>`;document.body.appendChild(overlay);overlay.querySelector('#closeApartmentVisit').onclick=()=>overlay.remove();overlay.addEventListener('click',ev=>{if(ev.target===overlay)overlay.remove();});return;}
    const friend=e.target.closest('[data-friend]')?.dataset.friend;if(friend){const r=await sb.from('friendships').insert({requester_id:user.id,addressee_id:friend,status:'pending'});if(r.error)toast(errorText(r.error));else{toast('Friend request sent.');await openTab('social');}return;}
    const accept=e.target.closest('[data-accept-friend]')?.dataset.acceptFriend;if(accept){const r=await sb.from('friendships').update({status:'accepted',updated_at:new Date().toISOString()}).eq('id',accept).eq('addressee_id',user.id);if(r.error)toast(errorText(r.error));else{toast('Friend request accepted.');await openTab('social');}return;}
    const action=e.target.closest('[data-action]')?.dataset.action;if(!action)return;
    if(action==='salary'){await doRpc('claim_job_salary',{},'Salary claimed!');return;}
    if(action==='transfer'){const recipient=$('recipientSelect')?.value,amount=Number($('transferAmount')?.value),note=$('transferNote')?.value?.trim()||null;if(!recipient||!Number.isFinite(amount)||amount<=0){toast('Choose a player and enter a valid amount.');return;}await doRpc('send_player_money',{p_recipient_id:recipient,p_amount:amount,p_description:note},'Game money sent!');return;}
    if(action==='send-message'){
      const recipient=$('messageRecipient')?.value,body=$('messageBody')?.value?.trim();
      if(!recipient||!body){toast('Choose a player and write a message first.');return;}
      const r=await sb.from('messages').insert({sender_id:user.id,recipient_id:recipient,body}).select('id').single();
      if(r.error){toast(errorText(r.error));return;}
      toast('Message sent.');await openTab('social');return;
    }
    if(action==='save-display-name'){
      const name=$('settingsDisplayName')?.value?.trim();if(!name){toast('Enter a display name.');return;}
      const r=await sb.from('players').update({display_name:name,updated_at:new Date().toISOString()}).eq('id',user.id);
      if(r.error){toast(errorText(r.error));return;}await refreshProfile();toast('Display name updated.');await openTab('settings');return;
    }
    if(action==='change-email'){
      const email=$('settingsEmail')?.value?.trim();if(!email){toast('Enter the new email address.');return;}
      const r=await sb.auth.updateUser({email});if(r.error){toast(errorText(r.error));return;}toast('Email change requested. Check your email for confirmation.');return;
    }
    if(action==='change-password'){
      const password=$('settingsPassword')?.value;if(!password||password.length<6){toast('Use a password with at least 6 characters.');return;}
      const r=await sb.auth.updateUser({password});if(r.error){toast(errorText(r.error));return;}$('settingsPassword').value='';toast('Password updated.');return;
    }
    if(action==='save-settings'){
      const enabled=$('notificationsEnabled')?.checked===true;
      const r=await sb.from('player_settings').upsert({player_id:user.id,notifications_enabled:enabled,updated_at:new Date().toISOString()},{onConflict:'player_id'});
      if(r.error){toast(errorText(r.error));return;}toast(enabled?'In-game notifications are on.':'In-game notifications are off.');await pollNotifications(false);return;
    }
    if(action==='settings-logout'){await sb.auth.signOut();user=null;profile=null;if(notificationPoll)clearInterval(notificationPoll);showLanding();return;}
    if(action==='create-business'){const name=$('bizName')?.value?.trim(),category=$('bizCategory')?.value,location=$('bizLocation')?.value,price=Number($('bizPrice')?.value);if(!name||!Number.isFinite(price)||price<100){toast('Enter a business name and startup cost of at least GH₵100.');return;}await doRpc('create_business',{p_name:name,p_category:category,p_location:location,p_price:price},'Your business is open!');return;}
    if(action==='create-investment'){const name=$('assetName')?.value?.trim(),principal=Number($('investAmount')?.value),rate=Number($('investRate')?.value),days=Number($('investDays')?.value);if(!name||!Number.isFinite(principal)||principal<=0||!Number.isFinite(rate)||rate<0||rate>100){toast('Enter an investment name, amount and return rate from 0 to 100%.');return;}await doRpc('create_investment',{p_asset_name:name,p_principal:principal,p_return_rate:rate,p_days:days},'In-game investment created!');}
  });
  $('logoutBtn').onclick=async()=>{await sb.auth.signOut();user=null;profile=null;if(notificationPoll)clearInterval(notificationPoll);showLanding();};
  sb.auth.getSession().then(({data,error})=>{if(error){console.warn(error);return;}if(data.session)enterGame(data.session.user);}).catch(console.error);
  sb.auth.onAuthStateChange((_event,session)=>{if(session&&!user){setTimeout(()=>enterGame(session.user),0);}else if(!session&&user){user=null;profile=null;if(notificationPoll)clearInterval(notificationPoll);showLanding();}});
})();
