ACCRA LIFE V38 — MASTER BRIEF BUILD (MANUAL CLOUDFLARE PAGES ZIP)

WHAT IS INCLUDED
- Root-level website files for manual Cloudflare Pages upload.
- Landing page now has a single account-summary card. Guests see “Guest · GH₵200 starter · Level 1”; signed-in players' name, wallet balance, and level are loaded from Supabase. Continue opens the game for a signed-in user or login for a guest; New life opens registration for a guest.
- Registration includes unique-name availability check, password confirmation, and a confirmation-email note. Supabase remains responsible for real email verification.
- Adds an Accra Phone screen with the Ghana app grid. Apps route to existing game sections where possible; unbuilt services are clearly marked coming soon rather than pretending to work.
- Includes a review-first SQL migration for GH₵200 new-account starter wallet, economy catalogue corrections, and secure server-side transfers with Level 3, GH₵500 per transaction, GH₵1,000 daily transfer amount, and 15% virtual-game-currency fee.
- Existing property/car/furniture purchase RPCs already deduct wallet balance server-side in the source database; the migration does not modify ownership or existing balances.

IMPORTANT BEFORE PUBLISHING
1. Extract this ZIP and upload the contents at the Cloudflare Pages root (index.html, app.js, styles.css, config.js, etc.). Do not upload the ZIP itself as a single file.
2. The SQL migration is NOT applied automatically by Cloudflare Pages. Review it first in Supabase SQL Editor. Do not run it until you have a backup and have reviewed the SQL.
3. The Send Money UI is not enabled in this package until the SQL RPC is applied and tested. The secure RPC is supplied in the migration; this avoids a front-end-only fake transfer.
4. Paystack real-money purchase is not activated. It requires a server-side checkout initializer, verified webhook/callback, and secret keys configured as server secrets. Never put a Paystack secret key in config.js.
5. No player accounts were deleted. Do not delete Arria, Mila, Chan_xn, or any other account using display names alone; verify IDs and get explicit approval first.
6. Online counts are not fabricated. This package does not claim fake concurrent users or fake visits.
7. Email-only authentication is retained; no phone number or SMS provider is added. Supabase email confirmation settings must be enabled in Authentication settings.

TEST CHECKLIST AFTER DEPLOY
- Open the public URL in a private Safari tab.
- Guest card should say Guest / GH₵200 starter / Level 1.
- Tap Continue: should open login.
- Tap New life: should open registration. Enter a new unique player name, email, password and matching confirmation; confirm email if required.
- Log in, return to landing, verify actual saved name/wallet/level appears, then tap Continue to enter game.
- Open Phone and test Jobs, Messages, Houses/Cars, Bank and Settings.
- Verify existing player balance is unchanged. Existing accounts are not reset to GH₵200.

VERIFICATION LIMITATION
JavaScript syntax and ZIP structure are checked locally. The package has not been deployed to your Cloudflare site or tested in your live iPhone browser. The SQL migration is review-first and has not been applied to the live database.
