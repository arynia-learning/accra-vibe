ACCRA LIFE — V48 FURNITURE VISUALS PATCH

This patch adds nine local, offline-capable SVG product illustrations and maps them to exact catalogue item names in app.js:
- Standing Fan
- Microwave
- Dining Set
- Small Mirror + Stool
- Round Wall Mirror
- Full-Length Standing Mirror
- Simple Metal Bed
- Bedside Table
- Small 2-Door Wardrobe

The illustrations are stored in assets/furniture/ and are loaded locally, so these products do not depend on third-party image hosts. Existing product-specific mappings and the existing Kente sofa / wall AC assets are preserved.

Validation performed:
- node --check app.js passed.
- SVG files parsed as XML.

Important limitations:
- This patch updates the local source bundle only. It has NOT been deployed to accralife.app.
- The new visuals are custom vector illustrations, not photographs of specific retail products.
- Furniture purchase, move, and sell RPCs were checked separately in Supabase; they require authentication and are not executable by anon.
