-- ACCRA LIFE V45 PATCH — runtime fallback and temporary furniture hiding
-- Repeatable. Does not delete product rows, alter prices, IDs, purchases, wallets, or owned furniture.
-- The live database has already had these changes applied directly; review before rerunning.

begin;

-- Add a real catalogue visibility switch (the original schema did not have is_active).
alter table public.furniture_items
  add column if not exists is_active boolean not null default true;

-- Hide products reported as broken or visibly mismatched until proper images are ready.
update public.furniture_items
set is_active = false,
    icon = case
      when lower(trim(name)) = 'rug' then '🧶'
      when lower(trim(name)) = 'standing fan' then '💨'
      when lower(trim(name)) = 'microwave' then '🍲'
      when lower(trim(name)) = 'dining set' then '🍽️'
      when lower(trim(name)) in ('small mirror + stool','round wall mirror','full-length standing mirror') then '🪞'
      when lower(trim(name)) in ('simple metal bed','bedside table') then '🛏️'
      when lower(trim(name)) = 'plastic chair + gaming table' then '🪑'
      else icon
    end
where lower(trim(name)) in (
  'rug', 'standing fan', 'microwave', 'dining set', 'small mirror + stool',
  'round wall mirror', 'full-length standing mirror', 'simple metal bed',
  'bedside table', 'plastic chair + gaming table'
);

commit;

-- Verification: expected 10 rows below, all with is_active=false.
select name, price, is_active
from public.furniture_items
where lower(trim(name)) in (
  'rug', 'standing fan', 'microwave', 'dining set', 'small mirror + stool',
  'round wall mirror', 'full-length standing mirror', 'simple metal bed',
  'bedside table', 'plastic chair + gaming table'
)
order by name;
