ACCRA LIFE V46 — MOVING WEDDING + POLITICS SCENES

Based on the V45 furniture crash/hide patch bundle. Existing V45 files and features are retained; this adds a Live Events tab.

WHAT'S ADDED
- East Legon wedding build scene with moving delivery trucks, workers carrying chairs/flowers, venue setup progress, and a night Kotoka jet/van sequence.
- Black Star Square green-party rally with waving flags, moving crowd, four police bikes, black V8, green leader car, and rally shout captions.
- Makola scene with moving crowd and community-support distribution point.
- Event switcher and replay control. CSS-only motion; no external animation/image dependency.
- Reduced-motion accessibility override.

FILES CHANGED
- index.html (Live Events tab)
- app.js (events route, scene renderer, controls)
- styles.css (animated scene styles)

IMPORTANT
This is a source bundle for the website, not a claim that the live hosting site has been deployed. Upload the complete bundle to the same hosting project as a coordinated update (keep index.html, app.js, styles.css, config.js and all other existing files together). Do not upload only a single HTML file. Existing Supabase project settings in config.js are preserved unchanged.
