ACCRA LIFE V49 — STARTING WALLET & WORLD CONTROLS

Included in this source bundle:
- New account database trigger now initializes a GH₵100,000 virtual wallet. Existing wallet balances are intentionally preserved.
- Dada Bee / Hustler start cards both display GH₵100,000.
- Existing venue world supports WASD and arrow movement, Shift/run mode, Q/R camera turns, E/Space interaction, on-screen directional controls, a touch joystick, and camera drag gestures.
- Mobile control styling was added.
- Existing V47/V48 pages, config.js, event scenes, furniture visuals, admin pages, and games page are retained.

IMPORTANT LIMITATIONS
- This is still the existing browser game with animated 2D/CSS scenes, not a true 3D game engine.
- The requested full driving simulation, car theft/police chase, airplane terminal gameplay, voice chat push-to-talk, and true 3D residents are not implemented by this version. Existing garage/travel/social features remain as they were.
- Dada Bee and Hustler start selection saves to new-account metadata. The current database schema does not have a distinct Nima starter-room property in the catalogue, so the Hustler room is still represented by the existing path/UI rather than a verified dedicated Nima property.
- The database migration was applied to Supabase project kpyugkfbkzkuumcpkzkb. It affects newly created accounts only; it does not grant GH₵100,000 to existing accounts.
- Frontend has not been deployed to any live host. Upload the full site folder as one deployment after reviewing/testing. Do not replace config.js.
