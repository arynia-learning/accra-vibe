-- ACCRA LIFE V47 core start + live presence migration
-- Safe for existing accounts: does not alter current balances, homes or paths.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare base_username text; chosen_username text; chosen_display_name text; chosen_path text; starting_balance numeric;
begin
 chosen_display_name := left(coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'), ''), nullif(split_part(coalesce(new.email, ''), '@', 1), ''), 'New Player'), 80);
 base_username := lower(regexp_replace(coalesce(nullif(trim(new.raw_user_meta_data->>'username'), ''), nullif(split_part(coalesce(new.email, ''), '@', 1), ''), 'player'), '[^a-zA-Z0-9_]', '', 'g'));
 if base_username = '' then base_username := 'player'; end if; chosen_username := left(base_username,24);
 chosen_path := case when new.raw_user_meta_data->>'life_path'='lapo' then 'lapo' when new.raw_user_meta_data->>'life_path'='nepo' then 'nepo' else 'semi-rich' end;
 starting_balance := case when chosen_path='lapo' then 50 when chosen_path='nepo' then 5000 else 500 end;
 begin insert into public.players(id,username,display_name,life_path) values(new.id,chosen_username,chosen_display_name,chosen_path) on conflict(id) do nothing;
 exception when unique_violation then chosen_username := left(base_username,15)||'_'||substr(replace(new.id::text,'-',''),1,8); insert into public.players(id,username,display_name,life_path) values(new.id,chosen_username,chosen_display_name,chosen_path) on conflict(id) do nothing; end;
 insert into public.wallets(player_id,balance) values(new.id,starting_balance) on conflict(player_id) do nothing;
 if chosen_path='semi-rich' then insert into public.player_properties(player_id,property_id) select new.id,p.id from public.properties p where p.name='Starter Studio' on conflict(player_id,property_id) do nothing;
 elsif chosen_path='nepo' then insert into public.player_properties(player_id,property_id) select new.id,p.id from public.properties p where lower(p.name) like '%east legon%' and (lower(p.name) like '%mansion%' or lower(p.name) like '%estate%') order by p.price desc nulls last limit 1 on conflict(player_id,property_id) do nothing; end if;
 return new;
end; $$;
create table if not exists public.player_presence(visitor_id uuid primary key,user_id uuid references auth.users(id) on delete cascade,last_seen_at timestamptz not null default now());
create index if not exists player_presence_last_seen_idx on public.player_presence(last_seen_at desc);
alter table public.player_presence enable row level security; revoke all on public.player_presence from anon,authenticated;
create or replace function public.accra_presence_heartbeat(p_visitor_id uuid) returns void language plpgsql security definer set search_path=public as $$ begin if p_visitor_id is null then raise exception 'Presence visitor ID required'; end if; insert into public.player_presence(visitor_id,user_id,last_seen_at) values(p_visitor_id,auth.uid(),now()) on conflict(visitor_id) do update set user_id=excluded.user_id,last_seen_at=now(); end; $$;
revoke all on function public.accra_presence_heartbeat(uuid) from public; grant execute on function public.accra_presence_heartbeat(uuid) to anon,authenticated;
create or replace function public.accra_live_player_count() returns integer language sql stable security definer set search_path=public as $$ select count(distinct coalesce(user_id::text,visitor_id::text))::integer from public.player_presence where last_seen_at>now()-interval '5 minutes'; $$;
revoke all on function public.accra_live_player_count() from public; grant execute on function public.accra_live_player_count() to anon,authenticated;

-- Ghanaian launch jobs; idempotent and safe to re-run.
insert into public.jobs(name,category,salary,description,life_path)
select v.name,v.category,v.salary,v.description,'all' from (values
 ('Waiter','Hospitality',120::numeric,'Serve guests at an Accra restaurant and earn a shift wage.'),
 ('Driver','Transport',180::numeric,'Drive passengers around Accra and build your transport reputation.'),
 ('Trader at Makola','Trading',150::numeric,'Buy and sell market goods at Makola Market.'),
 ('Security Officer','Security',160::numeric,'Keep a venue or business safe during your shift.'),
 ('Content Creator','Media',220::numeric,'Create short-form content and grow your local audience.'),
 ('DJ','Entertainment',240::numeric,'Play music at a lounge and keep the crowd moving.'),
 ('Rally Setup Crew','Special Events',300::numeric,'Coordinate stage, flags and chair deliveries at Black Star Square.'),
 ('Motorcade Driver','Special Events',450::numeric,'Drive the campaign motorcade with police escort through the square.'),
 ('Makola Community Desk','Special Events',250::numeric,'Coordinate volunteer support distribution at Makola.'),
 ('Wedding Event Coordinator','Special Events',350::numeric,'Finish the East Legon wedding venue and coordinate VIP arrivals.')
) as v(name,category,salary,description)
where not exists(select 1 from public.jobs j where lower(j.name)=lower(v.name));
