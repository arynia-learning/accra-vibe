ACCRA LIFE V47 — CORE EXPANSION

This is a browser-hosted source bundle, not a live deployment. Keep the existing Supabase config.js and all current site pages.

Included in this bundle:
- 18+ confirmation before choosing a starting story.
- Hustler start (Nima, GH₵50) and Dada Bee start (East Legon, GH₵5,000) in the UI.
- Ghana-time clock and PWA manifest, icons, and a shell service worker for Add to Home Screen.
- Fake “1.4k online” removed; a real five-minute presence heartbeat/count integration is included.
- Phone menu with Jobs, Houses, Bank, Transport, Relationships, Inventory and Shop.
- Added Accra destinations: Kotoka Airport, Makola Market, Black Star Square, Circle, Jamestown, Accra Mall and Enzo Lounge.
- Map place panel lets the player choose Walk, Trotro, Taxi, Okada, Bicycle or Car before Go.
- Wedding/rally/Makola scenes use CSS-built animated people, chairs, tables, trucks, flags and cars. Event task buttons respond and record local task state.
- Local-device hunger, energy and sleep bars with eat/rest actions.
- Expanded settings controls and safer image fallbacks.
- Ghanaian job catalogue seeds are included in the SQL migration.

REQUIRED BACKEND STEP
Review and apply V47-CORE-START-PRESENCE-PWA.sql to the correct Supabase project before deploying the frontend. It only changes new-account setup and adds presence/jobs; it does not alter existing wallet balances. The Dada Bee/Hustler starting amounts and the online counter require this migration.

IMPORTANT LIMITATIONS
- This bundle has not been deployed to accralife.app or tested against the live host from this environment.
- Needs and event-task progress are currently stored locally in this browser, not synced to the player database.
- Settings like “who can message me” are local preferences and are not yet enforced by server-side messaging rules.
- Daily rent, food purchasing, billboards/ad revenue, governor announcements and campaign money distribution still need server-side gameplay/economy RPCs before they can safely change real saved game balances.
- The scenes are CSS-built animated/isometric-style graphics, not a full 3D engine.

Deploy the contents of this folder together at the website root: index.html, app.js, styles.css, config.js, manifest.webmanifest, sw.js, assets/, and the existing admin/game pages. Do not replace config.js with a placeholder.
