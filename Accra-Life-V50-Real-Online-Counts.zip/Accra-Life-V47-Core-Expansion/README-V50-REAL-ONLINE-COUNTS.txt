ACCRA LIFE V50 — REAL ONLINE COUNTS

Changes in this version:
- Replaced any static/fake online number with Supabase Realtime Presence.
- Only connected, signed-in game sessions are counted; multiple tabs for the same account are deduplicated by account ID.
- The global online count updates on presence sync/join/leave and refreshes its displayed state every 10 seconds.
- Added a total registered-account count using the aggregate-only accra_total_joined_count() RPC. It refreshes every 10 seconds and exposes no email or profile details.
- Shows an em dash when a count cannot be obtained rather than inventing a number.
- Presence tracking starts when a signed-in player enters the game and is removed on logout.

Supabase change applied to project kpyugkfbkzkuumcpkzkb:
- public.accra_total_joined_count() returns only the count of auth.users.
- EXECUTE is granted to anon and authenticated; other function privileges are revoked.

IMPORTANT:
- Upload the contents of this folder to the website host's deployment/root directory together, not just app.js.
- The new header and code are in the supplied source bundle; this does not deploy the Cloudflare Pages site by itself.
- The online count represents signed-in game accounts connected to this same Supabase Realtime channel, not website visits or historical traffic.
