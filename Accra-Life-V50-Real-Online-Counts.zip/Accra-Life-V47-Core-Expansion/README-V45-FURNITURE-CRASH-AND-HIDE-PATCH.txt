ACCRA LIFE V45 — FURNITURE CRASH + TEMPORARY HIDE PATCH

This is still the V45 project package (not a new V46 version). It preserves the existing V43/V44 site files and features.

PATCH CONTENTS
- The furniture shop now filters its catalogue to items with is_active=true.
- Broken/unavailable product images fall back to a product-specific emoji placeholder instead of leaving a broken-image icon.
- Generic JavaScript/runtime errors are logged without replacing the whole page with the generic “game script encountered an error” banner. Startup errors still show a helpful fallback message.
- The game script marks successful initialization so a script that downloads but fails during startup can be detected.
- Temporarily hidden from the shop: Rug, Standing Fan, Microwave, Dining Set, Small Mirror + Stool, Round Wall Mirror, Full-Length Standing Mirror, Simple Metal Bed, Bedside Table, and Plastic Chair + Gaming Table.
- Existing prices are preserved. Products are hidden, not deleted; purchases and player data are untouched.
- Existing home, garage, car, wallet, social, travel, and other included site files are retained.

DATABASE STATUS
The live Supabase database was updated directly during this patch session: is_active was added to public.furniture_items, the ten items above were marked inactive, and their fallback icons were set. The query result verified all ten as inactive. The included SQL is a repeatable record of those changes; it is not necessary to run it again unless you are applying this patch to a different database.

DEPLOYMENT STATUS
The website files have been updated and packaged, but this ZIP has NOT been deployed to Cloudflare. The live site will not receive the JavaScript fallback/filter changes until you deploy these files.

CLOUDFLARE UPLOAD REMINDER
1. Download and extract the ZIP.
2. Upload the extracted contents to the existing Accra Life project using the same deployment method as before. Keep index.html, app.js, styles.css, config.js, _redirects and assets/ at the published root.
3. Do not upload the ZIP as a document and do not create a new project.
4. After deployment, open the existing site and test sign-in, Home, Furniture Shop, Garage, and Homes & Cars.

TESTS RUN
- app.js passed Node.js syntax check.
- Inline JavaScript in index.html passed a syntax check.
- ZIP archive integrity is checked after packaging.
