ACCRA LIFE — V22: VISIBLE 2D CHARACTER SCENES

WHAT'S NEW
- A visible 2D character now appears in the venue scene after the player enters a location.
- The scene has location-specific visual dressing for church, nightclub, gym, beach, campus, cinema, lounge and other venues.
- The player's avatar has a nameplate and a gentle idle animation.
- Church characters animate with raised arms; nightclub/lounge characters dance; gym characters animate workout-style arm movement.
- Other players who are connected to the same live venue appear as separate named characters in the scene.
- Recent visitors may also appear, marked as having visited recently rather than being presented as currently online.
- House-party scenes render the host and joined guests as visible dancing characters in the room, as well as retaining the guest list and messaging actions.
- Existing map, account, activity, XP, travel, settings and other V21 features are retained.

IMPORTANT LIMITS
- This is the first 2D visual pass, not a full 3D game. Character sprites are stylised SVG drawings animated with CSS.
- Live multiplayer characters require the players to use the deployed version of this app and Supabase Realtime Presence to be available. If no other player is in the same venue, your character still appears alone in the scene.
- A house-party scene shows players who joined the event. A player must join the party to appear in that room.
- This package was syntax-checked, but not fully browser-tested against every Supabase policy or on multiple simultaneous accounts.

DEPLOY THE UPDATE TO THE EXISTING NETLIFY SITE
1. Download and unzip this package.
2. Open the extracted folder. It should contain index.html, app.js, styles.css, config.js and this README.txt together.
3. Open your existing Netlify site dashboard: https://app.netlify.com/
4. Deploy the folder containing those files to the existing site's manual deploy area. Do not deploy the ZIP file itself and do not create a new site.
5. Wait for the deploy to finish, then open the existing Accra Life public link and refresh it. If an old version remains cached, refresh again or open the link in a private browser tab.

Keep config.js with the other files. It contains the public Supabase client configuration; never place a Supabase service-role key in a public game package.
